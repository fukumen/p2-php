<?php
/**
 * rep2 - ���X�������݃t�H�[���̋@�\�ǂݍ���
 */

$js = array();

$fake_time = -30; // time ��30�b�O�ɋU��
$time = time();
$time = $time + $fake_time;

$csrfid = P2Util::getCsrfId('post' . $host . $bbs . $key);

$hd['FROM'] = '';
$hd['mail'] = '';
$hd['MESSAGE'] = '';
$hd['subject'] = '';
$hd['beres_checked'] = '';
$hd['proxy_checked'] = '';

$htm['beres'] = '';
$htm['talk_account'] = '';
$htm['sage_cb'] = '';
$htm['maru_post'] = '';
$htm['block_submit'] = '';
$htm['src_fix'] = '';
$htm['options'] = '';
$htm['options_k'] = '';
$htm['subject'] = '';
$htm['resform_ttitle'] = '';
$htm['proxy'] = '';

$htm['disable_js'] = <<<EOP
<script type="text/javascript">
//<![CDATA[
// Thanks naoya <http://d.hatena.ne.jp/naoya/20050804/1123152230>

function isNetFront() {
  var ua = navigator.userAgent;
  if (ua.indexOf("NetFront") != -1 || ua.indexOf("AVEFront/") != -1 || ua.indexOf("AVE-Front/") != -1) {
    return true;
  } else {
    return false;
  }
}

function disableSubmit(form) {

  // 2006/02/15 NetFront�Ƃ͑����������ł܂�炵���̂Ŕ�����
  if (isNetFront()) {
    return;
  }

  var elements = form.elements;
  for (var i = 0; i < elements.length; i++) {
    if (elements[i].type == 'submit') {
      elements[i].disabled = true;
    }
  }
}

function setHiddenValue(button) {

  // 2006/02/15 NetFront�Ƃ͑����������ł܂�炵���̂Ŕ�����
  if (isNetFront()) {
    return;
  }

  if (button.name) {
    var q = document.createElement('input');
    q.type = 'hidden';
    q.name = button.name;
    q.value = button.value;
    button.form.appendChild(q);
  }
}

//]]>
</script>\n
EOP;

// {{{ key.idx���疼�O�ƃ��[����Ǎ���

if ($lines = FileCtl::file_read_lines($key_idx, FILE_IGNORE_NEW_LINES)) {
    $line = explode('<>', $lines[0]);
    $hd['FROM'] = p2h($line[7]);
    $hd['mail'] = p2h($line[8]);
}

// }}}
// {{{ �f�[�^�x�[�X����O���POST���s�f�[�^��beres�̐ݒ��Ǎ���

$post_backup_key = PostDataStore::getKeyForBackup($host, $bbs, $key, !empty($_REQUEST['newthread']));
$post_config_key = PostDataStore::getKeyForConfig($host, $bbs);

// �O���POST���s�f�[�^
if ($post_backup = PostDataStore::get($post_backup_key)) {
    $hd['FROM'] = p2h($post_backup['FROM'] ?? $post_backup['NAME'] ?? '');
    $hd['mail'] = p2h($post_backup['mail'] ?? $post_backup['MAIL'] ?? '');
    $hd['MESSAGE'] = p2h($post_backup['MESSAGE'] ?? '');
    $hd['subject'] = p2h($post_backup['subject'] ?? $post_backup['SUBJECT'] ?? '');
}

// beres
if ($post_config = PostDataStore::get($post_config_key)) {
    if ($post_config['beres']) {
        $hd['beres_checked'] = ' checked';
    }
}

// proxy
if ($_conf['proxy_use']) {
    $hd['proxy_checked'] = ' checked';
}

// }}}
// {{{ ���O�ƃ��[���̍ŏI����

// P2NULL�͋󔒂ɕϊ�
if ($hd['FROM'] === 'P2NULL') {
    $hd['FROM'] = '';
}
if ($hd['mail'] === 'P2NULL') {
    $hd['mail'] = '';
}

// �󔒂̓��[�U�ݒ�l�ɕϊ�
if ($hd['FROM'] === '') {
    $hd['FROM'] = p2h($_conf['my_FROM']);
}
if ($hd['mail'] === '') {
    $hd['mail'] = p2h($_conf['my_mail']);
}

// }}}
// {{{ textarea�̑���

// �Q�l �N���V�b�N COLS='60' ROWS='8'
$mobile = (new Net_UserAgent_Mobile)->singleton();
$wrap_at = ''; // wrap������W3C HTML 4.01�d�l�ɑ��݂��Ȃ�
$name_size_at = '';
$mail_size_at = '';
$msg_cols_at = '';

// PC
if (!$_conf['ktai']) {
    $name_size_at = ' size="19"';
    $mail_size_at = ' size="19"';
    $msg_cols_at = ' cols="' . $STYLE['post_msg_cols'] . '"';
// willcom
} elseif($mobile->isAirHPhone()) {
    $msg_cols_at = ' cols="' . $STYLE['post_msg_cols'] . '"';
// �g��
} else {
    $STYLE['post_msg_rows'] = 5;
    $wrap_at = ' wrap="soft"';
}

// {{{ PC�p sage �`�F�b�N�{�b�N�X

if (!$_conf['ktai']) {
    $on_check_sage = ' onchange="checkSage();"';
    $htm['sage_cb'] = <<<EOP
<input id="sage" type="checkbox" onclick="mailSage()"><label for="sage">sage</label>
EOP;
} else {
    $on_check_sage = '';
}

// }}}
// {{{ ��/Be/Talk �������� �`�F�b�N�{�b�N�X

//  2ch����������
if (P2HostMgr::isHost2chs($host) and file_exists($_conf['sid2ch_php'])) {
    $htm['maru_post'] = '<span title="2ch��ID�̎g�p"><input type="checkbox" id="maru" name="maru" value="1">'
                      . '<label for="maru">��</label></span>';
}

// Be
if (P2HostMgr::isHost2chs($host) and P2Util::isEnableBe2ch()) {
    $htm['beres'] = '<input type="checkbox" id="beres" name="beres" value="1"'. $hd['beres_checked'] . '>'
                  . '<label for="beres">Be�ŏ�������</label>';
}

// Talk �A�J�E���g�A�g
if (P2HostMgr::isHostTalk($host) && file_exists($_conf['sidtalkapi_file'])) {
    require_once P2_LIB_DIR . '/authtalkapi.inc.php';
    if (AuthTalkAPI::is_login()) {
        $htm['talk_account'] = '<input type="checkbox" id="talk_account" name="talk_account" value="1">'
                          . '<label for="talk_account">�A�J�E���g�A�g����</label>';
    }
}

// }}}
// {{{ Proxy �`�F�b�N�{�b�N�X

//  Proxy
if ($_conf['proxy_host']) {
    $htm['proxy'] = '<input type="checkbox" id="proxy" name="proxy" value="1"'. $hd['proxy_checked'] . '>'
                  . '<label for="proxy">�v���L�V�𗘗p('.$_conf['proxy_host'].':'.$_conf['proxy_port'].')</label>';
}

// }}}
// {{{ �������݃u���b�N�p�`�F�b�N�{�b�N�X

if (!$_conf['ktai']) {
    $htm['block_submit'] = <<<EOP
<input type="checkbox" id="block_submit" onclick="switchBlockSubmit(this.checked)"><label for="block_submit">block</label>
EOP;
}

// }}}
// {{{ �\�[�X�R�[�h�␳�p�`�F�b�N�{�b�N�X

if (!$_conf['ktai']) {
    if ($_conf['editor_srcfix'] == 1) {
        $htm['src_fix'] = <<<EOP
<input type="checkbox" id="fix_source" name="fix_source" value="1"><label for="fix_source">src</label>
EOP;
    }
}

// }}}
// {{{ �������݃v���r���[

$htm['dpreview_onoff'] = '';
$htm['dpreview_amona'] = '';
$htm['dpreview']  = '';
$htm['dpreview2'] = '';
if (!$_conf['ktai'] && $_conf['expack.editor.dpreview']) {
    $_dpreview_noname = 'null';
    if (P2HostMgr::isHost2chs($host)) {
        $_dpreview_st = new SettingTxt($host, $bbs);
        $_dpreview_st->setSettingArray();
        if (!empty($_dpreview_st->setting_array['BBS_NONAME_NAME'])) {
            $_dpreview_noname = $_dpreview_st->setting_array['BBS_NONAME_NAME'];
            $_dpreview_noname = '"' . StrCtl::toJavaScript($_dpreview_noname) . '"';
        }
        unset($_dpreview_st);
    }
    $_dpreview_hide = 'false';
    if ($_conf['expack.editor.dpreview'] == 2) {
        if (UA::isSafariGroup() && basename($_SERVER['SCRIPT_NAME']) != 'post_form.php') {
            $_dpreview_hide = 'true';
        }
        $_dpreview_pos = 'dpreview2';
    } else {
        $_dpreview_pos = 'dpreview';
    }
    $htm[$_dpreview_pos] = <<<EOP
<script type="text/javascript" src="js/strutil.js?{$_conf['p2_version_id']}"></script>
<script type="text/javascript" src="js/dpreview.js?{$_conf['p2_version_id']}"></script>
<script type="text/javascript">
//<![CDATA[
var dpreview_use = true;
var dpreview_on = false;
var dpreview_hide = {$_dpreview_hide};
var noname_name = {$_dpreview_noname};
//]]>
</script>
<fieldset id="dpreview" style="display:none;">
<legend>preview</legend>
<div>
    <span class="prvw_resnum">?</span>
    �F<span class="prvw_name"><b id="dp_name"></b><span id="dp_trip"></span></span>
    �F<span id="dp_mail" class="prvw_mail"></span>
    �F<span class="prvw_dateid"><span id="dp_date"></span> ID:<span id="dp_id">???</span></span>
</div>
<div id="dp_msg" class="prvw_msg"></div>
<!-- <div id="dp_empty" class="prvw_msg">(empty)</div> -->
</fieldset>
EOP;
    $htm['dpreview_onoff'] = <<<EOP
<input type="checkbox" id="dp_onoff" onclick="DPShowHide(this.checked)"><label for="dp_onoff">preview</label>
EOP;
    if ($_conf['expack.editor.dpreview_chkaa']) {
        $htm['dpreview_amona'] = <<<EOP
<input type="checkbox" id="dp_mona" disabled><label for="dp_mona">mona</label>
EOP;
    }
}

// }}}
// {{{ �����Ƀ��X

$htm['orig_msg'] = '';
$q_resnum = null;
if ((basename($_SERVER['SCRIPT_NAME']) == 'post_form.php' || !empty($_GET['inyou'])) && !empty($_GET['resnum'])) {
    $q_resnum = $_GET['resnum'];
    $hd['MESSAGE'] = "&gt;&gt;" . $q_resnum . "\r\n";
    if (!empty($_GET['inyou'])) {
        $aThread = new ThreadRead();
        $aThread->setThreadPathInfo($host, $bbs, $key);
        $aThread->readDat($aThread->keydat);
        $q_resar = $aThread->explodeDatLine($aThread->datlines[$q_resnum-1]);
        $q_resar = array_map('trim', $q_resar);
        $q_resar[3] = strip_tags($q_resar[3], '<br>');
        if ($_GET['inyou'] == 1 || $_GET['inyou'] == 3) {
            $hd['MESSAGE'] .= '&gt; ';
            $hd['MESSAGE'] .= preg_replace('/\\s*<br>\\s*/',"\r\n&gt; ", $q_resar[3]);
            $hd['MESSAGE'] .= "\r\n";
        }
        if ($_GET['inyou'] == 2 || $_GET['inyou'] == 3) {
            if (!$_conf['ktai'] || $_conf['iphone']) {
                $htm['orig_msg'] = <<<EOM
<fieldset id="original_msg">
<legend>Original Message:</legend>
    <div>
        <span class="prvw_resnum">{$q_resnum}</span>
        �F<b class="prvw_name">{$q_resar[0]}</b>
        �F<span class="prvw_mail">{$q_resar[1]}</span>
        �F<span class="prvw_dateid">{$q_resar[2]}</span>
    </div>
    <div id="orig_msg" class="prvw_msg">{$q_resar[3]}</div>
</fieldset>
EOM;
            } else {
                $htm['orig_msg'] = <<<EOM
<div><i>Original Message:</i>
[{$q_resnum}]: <b>{$q_resar[0]}</b>: {$q_resar[1]}: {$q_resar[2]}<br>
{$q_resar[3]}</div>
EOM;
            }
        }
    }
}

// }}}
// {{{ �{������̂Ƃ���sage�ĂȂ��Ƃ��ɑ��M���悤�Ƃ���ƒ��ӂ���

$onsubmit_at = '';

if (!$_conf['ktai'] || $_conf['iphone']) {
    if (!preg_match('{NetFront|AVE-?Front/}', $_SERVER['HTTP_USER_AGENT'])) {

        // �������ŏ����Ɛߌ��ɂȂ���`�F�b�N���Čx�����o���B
        $_st = new SettingTxt($host, $bbs);
        $_st->setSettingArray();

        // ���������ߌ�
        $confirmNanashi = array_key_exists("BBS_NONAME_NAME", $_st->setting_array) && str_contains($_st->setting_array['BBS_NONAME_NAME'], "fusianasan");

        // �������ŏ����Ȃ�
        $blockNanashi = ((array_key_exists('BBS_NANASHI_CHECK', $_st->setting_array) && $_st->setting_array['BBS_NANASHI_CHECK'] == '1') || (array_key_exists('NANASHI_CHECK', $_st->setting_array) && $_st->setting_array['NANASHI_CHECK'] == '1'));

        unset($_st);

        $onsubmit_at = sprintf(' onsubmit="if (validateAll(%s,%s) && confirmNanashi(%s) && blockNanashi(%s)) { switchBlockSubmit(true); return true; } else { return false }"',
            (($_conf['expack.editor.check_message']) ? 'true' : 'false'),
            (($_conf['expack.editor.check_sage'])    ? 'true' : 'false'),
            ($confirmNanashi ? 'true' : 'false'), ($blockNanashi ? 'true' : 'false'));
    }
}

// }}}
// {{{ �摜�A�b�v���[�h

$upload_form = '';
$upload_mode = null;

/*
if (!$_conf['ktai'] || $_conf['iphone']) {
    if (file_exists($_conf['dropbox_auth_json'])) {
        $upload_mode = 'dropbox';
    }
}
*/

if (isset($_conf['upload_method'])) {
    switch ($_conf['upload_method']) {
        case 1:
            $upload_mode = 'imgur';
            break;
        case 2:
            $upload_mode = 'imgbb';
            break;
        case 3:
            $upload_mode = 'catbox';
            break;
        case 4:
            $upload_mode = 'litterbox';
            break;
        default:
            $upload_mode = null;
            break;
    }
}

if ($upload_mode !== null) {
    if ($_conf['ktai'] || $_conf['iphone']) {
        $upload_multiple = '';
        $upload_name = 'upload';
    } else {
        $upload_multiple = 'multiple';
        $upload_name = 'upload[]';
    }
    if (!isset($_SESSION['upload_token'])) {
        $_SESSION['upload_token'] = sha1(P2Commun::getP2UA(false,false) . microtime());
    }
    $upload_token = $_SESSION['upload_token'];
        $upload_form = <<<EOP
<input id="fileupload" type="file" name="{$upload_name}" data-url="upload.php?mode={$upload_mode}&amp;token={$upload_token}" {$upload_multiple}>
<script src="js/jquery.ui.widget.js"></script>
<script src="js/jquery.iframe-transport.js"></script>
<script src="js/jquery.fileupload.js"></script>
<script>
$(function () {
    $('#fileupload').fileupload({
        dataType: 'json',
        done: function (e, data) {
            var message = $('#MESSAGE');
            if (typeof data.result.error === 'string' && data.result.error.length) {
                window.alert(data.result.error);
            }
            $.each(data.result.urls, function (index, url) {
                var oldMessage = message.val();
                if (oldMessage.length) {
                    message.val(oldMessage + "\\n" + url);
                } else {
                    message.val(url);
                }
            });
        }
    });
});
</script>
EOP;
}

// }}}

/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
