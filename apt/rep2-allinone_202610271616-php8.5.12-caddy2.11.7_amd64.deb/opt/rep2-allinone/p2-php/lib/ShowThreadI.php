<?php
/**
 * rep2 - �g�їp�ŃX���b�h��\������ �N���X
 */

require_once P2EX_LIB_DIR . '/ExpackLoader.php';

ExpackLoader::loadAAS();
ExpackLoader::loadActiveMona();
ExpackLoader::loadImageCache();

// {{{ ShowThreadI

class ShowThreadI extends ShowThread
{
    // {{{ properties

    static private $_spm_objects = array();

    public $am_autong = false; // ����AA�������邩�ۂ�
    public $am_autodetect = false;
    public $am_side_of_id = false;
    public $am_on_spm = false;

    public $aas_rotate = '90����]'; // AAS ��]�����N������

    public $respopup_at = ' onclick="return iResPopUp(this, event);"';  // ���X�|�b�v�A�b�v�E�C�x���g�n���h��
    public $target_at = ' target="_blank"';    // ���p�A�ȗ��AID�ANG���̃����N�^�[�Q�b�g
    public $check_st = 'check';   // �ȗ��ANG���̃����N������

    public $spmObjName; // �X�}�[�g�|�b�v�A�b�v���j���[�pJavaScript�I�u�W�F�N�g��

    private $_dateIdPattern;    // ���t���������̌����p�^�[��
    private $_dateIdReplace;    // ���t���������̒u��������

    //private $_lineBreaksReplace; // �A��������s�̒u��������

    private $_kushiYakiName = null; // BBQ�ɏĂ���Ă���Ƃ��̖��O�ړ���

    // }}}
    // {{{ constructor

    /**
     * �R���X�g���N�^
     */
    public function __construct(ThreadRead $aThread, $matome = false)
    {
        parent::__construct($aThread, $matome);

        global $_conf, $STYLE;

        $this->_url_handlers = array(
            'plugin_linkThread',
            'plugin_link2chSubject',
        );
        // +Wiki
        if (isset($GLOBALS['linkPluginCtl'])) {
            $this->_url_handlers[] = 'plugin_linkPlugin';
        }
        if (isset($GLOBALS['replaceImageUrlCtl'])) {
            $this->_url_handlers[] = 'plugin_replaceImageUrl';
        } elseif ($_conf['mobile.use_picto']) {
            $this->_url_handlers[] = 'plugin_viewImage';
        }
        $this->_url_handlers[] = 'plugin_linkURL';

        if (!$_conf['mobile.bbs_noname_name']) {
            $this->setBbsNonameName();
        }

        if (P2HostMgr::isHost2chs($aThread->host)) {
            $this->_kushiYakiName = ' </b>[�\{}@{}@{}-]<b> ';
        }

        if ($_conf['mobile.date_zerosuppress']) {
            $this->_dateIdPattern = '~^(?:' . date('Y|y') . ')/(?:0(\\d)|(\\d\\d))?(?:(/)0)?~';
            $this->_dateIdReplace = '$1$2$3';
        } else {
            $this->_dateIdPattern = '~^(?:' . date('Y|y') . ')/~';
            $this->_dateIdReplace = '';
        }

        // �A��������s�̒u���������ݒ�
        /*
        if ($_conf['mobile.strip_linebreaks']) {
            $ngword_color = $GLOBALS['STYLE']['mobile_read_ngword_color'];
            if (strpos($ngword_color, '\\') === false && strpos($ngword_color, '$') === false) {
                $this->_lineBreaksReplace = " <br><s><font color=\"{$ngword_color}\">***</font></s><br> ";
            } else {
                $this->_lineBreaksReplace = ' <br><s>***</s><br> ';
            }
        } else {
            $this->_lineBreaksReplace = null;
        }
        */

        // �T���l�C���\����������ݒ�
        if (!isset($GLOBALS['pre_thumb_unlimited']) || !isset($GLOBALS['expack.ic2.pre_thumb_limit_k'])) {
            if (isset($_conf['expack.ic2.pre_thumb_limit_k']) && $_conf['expack.ic2.pre_thumb_limit_k'] > 0) {
                $GLOBALS['pre_thumb_limit_k'] = $_conf['expack.ic2.pre_thumb_limit_k'];
                $GLOBALS['pre_thumb_unlimited'] = false;
            } else {
                $GLOBALS['pre_thumb_limit_k'] = null;   // �k���l����isset()��false��Ԃ�
                $GLOBALS['pre_thumb_unlimited'] = true;
            }
        }
        $GLOBALS['pre_thumb_ignore_limit'] = false;

        // �A�N�e�B�u���i�[������
        if (P2_ACTIVEMONA_AVAILABLE) {
            ExpackLoader::initActiveMona($this);
        }

        // ImageCache2������
        if (P2_IMAGECACHE_AVAILABLE == 2) {
            ExpackLoader::initImageCache($this);
        }

        // AAS ������
        if (P2_AAS_AVAILABLE) {
            ExpackLoader::initAAS($this);
        }

        // SPM������
        //if ($this->_matome) {
        //    $this->spmObjName = sprintf('t%dspm%u', $this->_matome, crc32($this->thread->keydat));
        //} else {
        $this->spmObjName = sprintf('spm%u', crc32($this->thread->keydat));
        //}
    }

    // }}}
    // {{{ transRes()

    /**
     * Dat���X��HTML���X�ɕϊ�����
     *
     * @param   string $ares dat��1���C��
     * @param   int $i ���X�ԍ�
     * @param   string $pattern �n�C���C�g�p���K�\��
     * @return  string
     */
    public function transRes($ares, $i, $pattern = null)
    {
        global $_conf, $STYLE, $mae_msg, $highlight_msgs, $highlight_chain_nums;

        list($name, $mail, $date_id, $msg) = $this->thread->explodeDatLine($ares);
        if (($id = $this->thread->ids[$i]) !== null) {
            $idstr = 'ID:' . $id;
            $date_id = str_replace($this->thread->idp[$i] . $id, $idstr, $date_id);
        } else {
            $idstr = null;
        }

        // +Wiki:�u�����[�h
        if (isset($GLOBALS['replaceWordCtl'])) {
            $replaceWordCtl = $GLOBALS['replaceWordCtl'];
            $name = $replaceWordCtl->replace('name', $this->thread, $ares, $i);
            $mail = $replaceWordCtl->replace('mail', $this->thread, $ares, $i);
            $date_id = $replaceWordCtl->replace('date', $this->thread, $ares, $i);
            $msg = $replaceWordCtl->replace('msg', $this->thread, $ares, $i);
        }

        // �ǂ񂮂��C�p�̓��t�𒊏o
        $raw_date = null;
        if ($_conf['donguri_use'] && preg_match('/^\d{4}\/\d{2}\/\d{2}\(.+?\) \d{2}:\d{2}:\d{2}(\.\d+)?/', $date_id, $m)) {
            $raw_date = p2h($m[0]);
        }

        $tores = '';
        if ($this->_matome) {
            $res_id = "t{$this->_matome}r{$i}";
        } else {
            $res_id = "r{$i}";
        }

        // NG���ځ[��`�F�b�N
        $nong = !empty($_GET['nong']);
        $ng_type = $this->_ngAbornCheck($i, strip_tags($name), $mail, $date_id, $id, $msg, $nong, $ng_info);
        if ($ng_type == self::ABORN) {
            return $this->_abornedRes($res_id);
        }
        $msg_class = 'message';
        if ($this->am_autodetect && $this->activeMona->detectAA($msg)) {
            $msg_class .= ' ActiveMona';
        }
        if (!$nong && $this->am_autong && $this->activeMona->detectAA($msg)) {
            $is_ng = array_key_exists($i, $this->_ng_nums);
            $ng_type |= $this->_markNgAborn($i, self::NG_AA, true);
            $ng_info[] = 'AA��';
            // AA��A��NG�Ώۂ���O���ꍇ
            if (!$is_ng && $_conf['expack.am.autong_k'] == 2) {
                unset($this->_ng_nums[$i]);
            }
        }
        if ($ng_type != self::NG_NONE) {
            $ngaborns_head_hits = self::$_ngaborns_head_hits;
        }

        // {{{ ���O�Ɠ��t�EID�𒲐�

        // ���Ă��}�[�N��Z�k
        if ($this->_kushiYakiName !== null && strpos($name, $this->_kushiYakiName) === 0) {
            $name = substr($name, strlen($this->_kushiYakiName));
            // �f�t�H���g�̖��O�͏ȗ�
            if ($name === $this->_nanashiName) {
                $name = '[��]';
            } else {
                $name = '[��]' . $name;
            }
            // �f�t�H���g�̖��O�Ɠ����Ȃ�ȗ�
        } elseif ($name === $this->_nanashiName) {
            $name = '';
        }

        // ���݂̔N���͏ȗ��J�b�g����B�����̐擪0���J�b�g�B
        $date_id = preg_replace($this->_dateIdPattern, $this->_dateIdReplace, $date_id);

        // �j���Ǝ��Ԃ̊Ԃ��l�߂�
        $date_id = str_replace(') ', ')', $date_id);

        // �b���J�b�g
        if ($_conf['mobile.clip_time_sec']) {
            $date_id = preg_replace('/(\\d\\d:\\d\\d):\\d\\d(?:\\.\\d\\d)?/', '$1', $date_id);
        }

        // ID
        if ($id !== null) {
            $id_suffix = substr($id, -1);

            if ($_conf['mobile.underline_id'] && $id_suffix == 'O' && strlen($id) % 2) {
                $do_underline_id_suffix = true;
            } else {
                $do_underline_id_suffix = false;
            }

            if ($this->thread->idcount[$id] > 1) {
                if ($_conf['flex_idpopup'] == 1) {
                    $date_id = str_replace($idstr, $this->idFilter($idstr, $id), $date_id);
                }
                if ($do_underline_id_suffix) {
                    $date_id = str_replace($idstr, substr($idstr, 0, -1) . '<u>' . $id_suffix . '</u>', $date_id);
                }
            } else {
                if ($_conf['mobile.clip_unique_id']) {
                    if ($do_underline_id_suffix) {
                        $date_id = str_replace($idstr, 'ID:*<u>' . $id_suffix . '</u>', $date_id);
                    } else {
                        $date_id = str_replace($idstr, 'ID:*' . $id_suffix, $date_id);
                    }
                } else {
                    if ($do_underline_id_suffix) {
                        $date_id = str_replace($idstr, substr($idstr, 0, -1) . '<u>' . $id_suffix . '</u>', $date_id);
                    }
                }
            }
        } else {
            if ($_conf['mobile.clip_unique_id']) {
                $date_id = str_replace('ID:???', 'ID:?', $date_id);
            }
        }

        // }}}

        //=============================================================
        // �܂Ƃ߂ďo��
        //=============================================================

        if ($name) {
            $name = $this->transName($name); // ���OHTML�ϊ�
        }
        $msg = $this->transMsg($msg, $i); // ���b�Z�[�WHTML�ϊ�

        // BE�v���t�@�C�������N�ϊ�
        $date_id = $this->replaceBeId($date_id, $i);
        $date_id = $this->replaceTid($date_id);

        // BE���G�����A�C�R�������N�ϊ�
        $msg = $this->replaceSsspIcon($msg);

        // NG���b�Z�[�W�ϊ�
        if ($ng_type != self::NG_NONE && count($ng_info)) {
            $ng_info = implode(', ', $ng_info);
            if ($ng_type == self::NG_AA) {
                $msg = <<<EOMSG
<a class="button" href="{$_conf['read_php']}?host={$this->thread->host}&amp;bbs={$this->thread->bbs}&amp;key={$this->thread->key}&amp;ls={$i}&amp;k_continue=1&amp;nong=1{$_conf['k_at_a']}"{$this->respopup_at}{$this->target_at}>{$ng_info}</a>
EOMSG;
            } else {
                $msg = <<<EOMSG
<s><font color="{$STYLE['mobile_read_ngword_color']}">{$ng_info}</font></s> <a class="button" href="{$_conf['read_php']}?host={$this->thread->host}&amp;bbs={$this->thread->bbs}&amp;key={$this->thread->key}&amp;ls={$i}&amp;k_continue=1&amp;nong=1{$_conf['k_at_a']}"{$this->respopup_at}{$this->target_at}>{$this->check_st}</a>
EOMSG;
            }

            // AAS
            if (($ng_type & self::NG_AA) && P2_AAS_AVAILABLE) {
                $aas_url = "aas.php?host={$this->thread->host}&amp;bbs={$this->thread->bbs}&amp;key={$this->thread->key}&amp;resnum={$i}";
                if (P2_AAS_AVAILABLE == 2) {
                    $aas_txt = "<img src=\"{$aas_url}{$_conf['k_at_a']}&amp;inline=1\">";
                } else {
                    $aas_txt = "AAS";
                }
                $msg .= " <a class=\"aas limelight\" href=\"{$aas_url}&amp;b=pc\" title=\"&gt;&gt;{$i}\"{$this->target_at}>{$aas_txt}</a>";
            }
        }

        // NG�l�[���ϊ�
        if ($ng_type & self::NG_NAME) {
	        $name = preg_replace("(<b>|</b>)", "", $name);
            $name = <<<EONAME
<s><font color="{$STYLE['mobile_read_ngword_color']}">{$name}</font></s>
EONAME;
        } elseif ($ng_type & self::NG_WATCHOI) {
            if ($_conf['ngaborn_watchoi4']) {
                $pattern = '#\(([^\s()]+\s+)?([0-9A-Za-z./*+]{4}-)([0-9A-Za-z./*+]{4}(?:\s+\[.+])?)\)#';
                $name = preg_replace($pattern, "($1<s><font color=\"{$STYLE['mobile_read_ngword_color']}\">$2</font></s>$3)", $name);
            } else {
                $pattern = '#\(((?:[^\s()]+\s+)?(?:[0-9A-Za-z./*+]{4}-[0-9A-Za-z./*+]{4})(?:\s+\[.+])?)\)#';
                $name = preg_replace($pattern, "(<s><font color=\"{$STYLE['mobile_read_ngword_color']}\">$1</font></s>)", $name);
            }
        }

        // NG���[���ϊ�
        if ($ng_type & self::NG_MAIL) {
            $mail = <<<EOMAIL
<s class="ngword" onmouseover="document.getElementById('ngn{$ngaborns_head_hits}').style.display = 'block';">{$mail}</s>
EOMAIL;
        }

        // NGID�ϊ�
        if ($ng_type & self::NG_ID) {
            $date_id = <<<EOID
<s><font color="{$STYLE['mobile_read_ngword_color']}">{$date_id}</font></s>
EOID;
        }

        // NG���b�Z�[�W�ϊ�(msg)
        if ($ng_type != self::NG_NONE && !empty($ng_info)) {
            // �ϊ��ς�

        // NG�l�[���ϊ�(msg)
        } elseif ($ng_type & (self::NG_NAME | self::NG_WATCHOI)) {
            $msg = <<<EOMSG
<a class="button" href="{$_conf['read_php']}?host={$this->thread->host}&amp;bbs={$this->thread->bbs}&amp;key={$this->thread->key}&amp;ls={$i}&amp;k_continue=1&amp;nong=1{$_conf['k_at_a']}"{$this->respopup_at}{$this->target_at}>{$this->check_st}</a>
EOMSG;

            // NG���[���ϊ�(msg)
        } elseif ($ng_type & self::NG_MAIL) {
            $msg = <<<EOMSG
<div id="ngn{$ngaborns_head_hits}" style="display:none;">{$msg}</div>
EOMSG;

            // NGID�ϊ�(msg)
        } elseif ($ng_type & self::NG_ID) {
            $msg = <<<EOMSG
<a class="button" href="{$_conf['read_php']}?host={$this->thread->host}&amp;bbs={$this->thread->bbs}&amp;key={$this->thread->key}&amp;ls={$i}&amp;k_continue=1&amp;nong=1{$_conf['k_at_a']}"{$this->respopup_at}{$this->target_at}>{$this->check_st}</a>
EOMSG;
        }

		// +live �n�C���C�g���[�h�ϊ�
		include P2_LIB_DIR . '/live/live_highlight_convert.php';

        /*
        //�u��������V���v�摜��}��
        if ($i == $this->thread->readnum +1) {
            $tores .= <<<EOP
                <div><img src="img/image.png" alt="�V�����X" border="0" vspace="4"></div>
EOP;
        }
        */

        $tores .= "<div id=\"{$res_id}\" class=\"res\"><div class=\"res-header\">";

        $no_class = 'no';
        $no_onclick = '';

        // �I���U�t���C��
        if ($this->thread->onthefly) {
            $GLOBALS['newres_to_show_flag'] = true;
            $no_class .= ' onthefly';
            // �V�����X��
        } elseif ($i > $this->thread->readnum) {
            $GLOBALS['newres_to_show_flag'] = true;
            $no_class .= ' newres';
        }

        // SPM
        $msg_id = $res_id . '_msg';
        if (isset($_GET['ajax']) && $_GET['ajax'] == 1 && isset($_GET['respop_id'])) {
            $spm_msg_id = sprintf('_respop%d_', $_GET['respop_id']) . $msg_id;
        } else {
            $spm_msg_id = $msg_id;
        }
        if ($_conf['expack.spm.enabled']) {
            $js_date = $raw_date ? "'$raw_date'" : 'null';
            $has_watchoi = isset($this->thread->watchois[$i]) ? 'true' : 'false';
            $no_onclick = " onclick=\"{$this->spmObjName}.show({$i},'{$spm_msg_id}',event,{$js_date},{$has_watchoi})\"";
        }

        // �ԍ�
        $tores .= "<span class=\"{$no_class}\"{$no_onclick}>{$i}</span>";
        // ���O
        $tores .= " <span class=\"name\">{$name}</span>";
        // ���[��
        $tores .= " <span class=\"mail\">{$mail}</span>";
        // ���t��ID
        $tores .= " <span class=\"date-id\">{$date_id}</span>";
        if ($this->am_side_of_id) {
            $tores .= ' ' . $this->activeMona->getMona($msg_id);
        }
        $tores .= "</div>\n";
        // ���e
        $tores .= "<div id=\"{$msg_id}\" class=\"{$msg_class}\">{$msg}</div>";
        // �탌�X���X�g
        if ($_conf['mobile.backlink_list'] == 1) {
            $linkstr = $this->_quotebackListHtml($i, 2);
            if (strlen($linkstr)) {
                $tores .= $linkstr;
            }
        }
        $tores .= "</div>\n"; // ���e�����

        // �܂Ƃ߂ăt�B���^�F����
        if ($pattern) {
            if (is_string($_conf['k_filter_marker'])) {
                $tores = StrCtl::filterMarking($pattern, $tores, $_conf['k_filter_marker']);
            } else {
                $tores = StrCtl::filterMarking($pattern, $tores);
            }
        }

        // �S�p�p���X�y�[�X�J�i�𔼊p��
        if (!empty($_conf['mobile.save_packet'])) {
            $tores = mb_convert_kana($tores, 'rnsk'); // CP932 ���� ask �� �� �� < �ɕϊ����Ă��܂��悤��
        }

        return array('body' => $tores, 'q' => '');
    }

    // }}}
    // {{{ transName()

    /**
     * ���O��HTML�p�ɕϊ�����
     *
     * @param   string $name ���O
     * @return  string
     */
    public function transName($name)
    {
        global $_conf;

        // ���b�`���C���t�B���^�����O�����N�ɕϊ�
        if (isset($this->thread->watchoicount)) {
            $pattern_watchoi = '#.*\(((?:[^\s()]+\s+)?(?:([0-9A-Za-z./*+]{4}-)[0-9A-Za-z./*+]{4})(?:\s+\[.+])?)\)#';
            if (preg_match($pattern_watchoi, $name, $wm)) {
                $watchoi_full = substr($wm[0], strrpos($wm[0], '('));
                if ($_conf['flex_idpopup'] == 1) {
                    $name = substr_replace($name, $this->watchoiFilter($watchoi_full, $wm[1], $wm[2]), strrpos($name, $watchoi_full), strlen($watchoi_full));
                } else {
                    $name = substr_replace($name, self::addIp2hostMarker($watchoi_full), strrpos($name, $watchoi_full), strlen($watchoi_full));
                }
            }
        }

        $name = strtr($name, array('<b>' => '', '</b>' => ''));

        // �g���b�v��z�X�g�t���Ȃ番������
        if (($pos = strpos($name, '��')) !== false) {
            $trip = substr($name, $pos);
            $name = substr($name, 0, $pos);
        } else {
            $trip = null;
        }

        // ���������p���X�|�b�v�A�b�v�����N��
        if (strlen($name) && $name != $this->_nanashiName) {
            $name = preg_replace_callback(
                self::getAnchorRegex('/(?:^|%prefix%)%nums%/'),
                array($this, '_quoteNameCallback'), $name
            );
        }

        if ($trip) {
            $name .= $trip;
        } elseif ($name) {
            // �����������
            $name = $name . ' ';
            //if (in_array(0xF0 & ord(substr($name, -1)), array(0x80, 0x90, 0xE0))) {
            //    $name .= ' ';
            //}
        }

        return $name;
    }

    // }}}
    // {{{ transMsg()

    /**
     * dat�̃��X���b�Z�[�W��HTML�\���p���b�Z�[�W�ɕϊ�����
     *
     * @param   string $msg ���b�Z�[�W
     * @param   int $mynum ���X�ԍ�
     * @return  string
     */
    public function transMsg($msg, $mynum)
    {
        global $_conf;
        global $pre_thumb_ignore_limit;

        $ryaku = false;

        // 2ch���`����dat
        if ($this->thread->dat_type == '2ch_old') {
            $msg = str_replace('���M', ',', $msg);
            $msg = preg_replace('/&amp(?=[^;])/', '&', $msg);
        }

        // �T���Q�[�g�y�A�̐��l�����Q�Ƃ�ϊ�
        $msg = P2Util::replaceNumericalSurrogatePair($msg);

        // &�␳
        $msg = preg_replace('/&(?!#?\\w+;)/', '&amp;', $msg);

        // >>1�̃����N����������O��
        // <a href="../test/read.cgi/accuse/1001506967/1" target="_blank">&gt;&gt;1</a>
        $msg = preg_replace('{<[Aa] .+?>(&gt;&gt;\\d[\\d\\-]*)</[Aa]>}', '$1', $msg);

        // �傫������
        if (empty($_GET['k_continue']) && strlen($msg) > $_conf['mobile.res_size']) {
            // <br>�ȊO�̃^�O���������A������؂�l�߂�
            $msg = strip_tags($msg, '<br>');
            $msg = mb_strcut($msg, 0, $_conf['mobile.ryaku_size']);
            $msg = preg_replace('/ *<[^>]*$/', '', $msg);

            // >>1, >1, ��1, ����1�����p���X�|�b�v�A�b�v�����N��
            $msg = preg_replace_callback(
                self::getAnchorRegex('/%full%/'),
                array($this, '_quoteResCallback'), $msg
            );

            $msg .= "<a href=\"{$_conf['read_php']}?host={$this->thread->host}&amp;bbs={$this->thread->bbs}&amp;key={$this->thread->key}&amp;ls={$mynum}&amp;k_continue=1&amp;offline=1{$_conf['k_at_a']}\"{$this->respopup_at}{$this->target_at}>��</a>";
            return $msg;
        }

        // �V�����X�̉摜�͕\�������𖳎�����ݒ�Ȃ�
        if ($mynum > $this->thread->readnum && $_conf['expack.ic2.newres_ignore_limit_k']) {
            $pre_thumb_ignore_limit = true;
        }

        // �����̉��s�ƘA��������s������
        if ($_conf['mobile.strip_linebreaks']) {
            $msg = $this->stripLineBreaks($msg /*, $this->_lineBreaksReplace*/);
        }

        // ���p��URL�Ȃǂ������N
        $msg = $this->transLink($msg);

        // Wikipedia�L�@�ւ̎��������N
        if ($_conf['mobile.link_wikipedia']) {
            $msg = $this->_wikipediaFilter($msg);
        }

        return $msg;
    }

    // }}}
    // {{{ _abornedRes()

    /**
     * ���ځ[�񃌃X��HTML���擾����
     *
     * @param  string $res_id
     * @return string
     */
    protected function _abornedRes($res_id)
    {
        global $_conf;

        if ($_conf['ngaborn_purge_aborn']) {
            return '';
        }

        return <<<EOP
<div id="{$res_id}" name="{$res_id}" class="res aborned">&nbsp;</div>\n
EOP;
    }

    // }}}
    // {{{ getSpmObjJs()

    /**
     * �X�}�[�g�|�b�v�A�b�v���j���[�ɕK�v�ȃX���b�h�����i�[����JavaScript�R�[�h���擾
     */
    public function getSpmObjJs($retry = false)
    {
        global $_conf;

        if (isset(self::$_spm_objects[$this->spmObjName])) {
            return $retry ? self::$_spm_objects[$this->spmObjName] : '';
        }

        $ttitle_en = UrlSafeBase64::encode($this->thread->ttitle);

        $motothre_url = $this->thread->getMotoThread();
        $motothre_url = substr($motothre_url, 0, strlen($this->thread->ls) * -1);

        // �G�X�P�[�v
        $_spm_title = StrCtl::toJavaScript($this->thread->ttitle_hc);
        $_spm_url = StrCtl::toJavaScript($motothre_url);
        $_spm_host = StrCtl::toJavaScript($this->thread->host);
        $_spm_bbs = StrCtl::toJavaScript($this->thread->bbs);
        $_spm_key = StrCtl::toJavaScript($this->thread->key);
        $_spm_ls = StrCtl::toJavaScript($this->thread->ls);
        $_spm_rnum_range = (int)$_conf['mobile.rnum_range'];
        $_spm_rref_params = 'rf[field]=' . ResFilter::FIELD_NUMBER .
            '&rf[method]=' . ResFilter::METHOD_JUST .
            '&rf[match]=' . ResFilter::MATCH_ON .
            '&rf[include]=' . ResFilter::INCLUDE_REFERENCED;
        $_spm_ngaborn_popup = ($_conf['expack.spm.ngaborn_confirm']) ? 1 : 2;
        $_spm_ngaborn_bbsonly = ($_conf['expack.spm.ngaborn_bbsonly']) ? 1 : 0;
        $_spm_b = ($_conf['view_forced_by_query']) ? "&b={$_conf['b']}" : '';

        $code = <<<EOJS
<script type="text/javascript">
//<![CDATA[
var {$this->spmObjName} = {
    'objName':'{$this->spmObjName}',
    'query':'&host={$_spm_host}&bbs={$_spm_bbs}&key={$_spm_key}&rescount={$this->thread->rescount}&ttitle_en={$ttitle_en}{$_spm_b}',
    'rc':'{$this->thread->rescount}',
    'title':'{$_spm_title}',
    'ttitle_en':'{$ttitle_en}',
    'url':'{$_spm_url}',
    'host':'{$_spm_host}',
    'bbs':'{$_spm_bbs}',
    'key':'{$_spm_key}',
    'ls':'{$_spm_ls}',
    'rnum_range': '{$_spm_rnum_range}',
    'rref_params': '{$_spm_rref_params}',
    'ngaborn_popup': {$_spm_ngaborn_popup},
    'ngaborn_bbsonly': {$_spm_ngaborn_bbsonly},
    'client':['{$_conf['b']}','{$_conf['client_type']}']
};
{$this->spmObjName}.show = (function(no,id,evt,date,hasWatchoi){SPM.show({$this->spmObjName},no,id,evt,date,hasWatchoi);});
{$this->spmObjName}.hide = SPM.hide; // (function(evt){SPM.hide(evt);});
//]]>
</script>\n
EOJS;

        self::$_spm_objects[$this->spmObjName] = $code;

        return $code;
    }

    // }}}
    // {{{ getSpmElementHtml()

    /**
     * �X�}�[�g�|�b�v�A�b�v���j���[�p��HTML�𐶐�����
     */
    static public function getSpmElementHtml()
    {
        global $_conf;

        $spm = <<<EOP
<div id="spm" class="col-xs-8">
<div id="spm-header" class="spm-section">&gt;&gt;<span id="spm-num">???</span></div>
<div id="spm-menu" class="spm-section">
    <span id="spm-reply-noquote" onclick="SPM.replyTo(false)">����Ƀ��X</span>
    <span id="spm-reply-quote" onclick="SPM.replyTo(true)">���p���ă��X</span>
EOP;
        if ($_conf['expack.am.autodetect_i'] && ($_conf['expack.am.display'] == 1 || $_conf['expack.am.display'] == 2)) {
            $spm .= <<<EOP
    <span id="spm-am" onclick="SPM.open('am')">�A�N�e�B�u���i�[</span>
EOP;
        }
        if ($_conf['expack.aas.enabled']) {
            $spm .= <<<EOP
    <span id="spm-aas" onclick="SPM.open('aas')">AAS</span>
    <span id="spm-aas-rotate" onclick="SPM.open('aas_rotate')">AAS(��])</span>
EOP;
        }
        if ($_conf['donguri_use']) {
            $spm .= <<<EOP
    <span id="spm-donguri" onclick="SPM.donguri()">�ǂ񂮂��C</span>
EOP;
        }
        $spm .= <<<EOP
    <span id="spm-rref" onclick="SPM.open('rref')">�t�Q��</span>
</div>
<div id="spm-action" >
<div class="input-group"> 
<select id="spm-select-target" class=" form-control" style="width:40%;">
    <option value="name">���O</option>
    <option value="mail">���[��</option>
    <option value="msg">�{��</option>
    <option value="id" selected>ID</option>
    <option value="watchoi">���b�`���C</option>
    <option value="be">BE</option>
</select><select id="spm-select-action"class=" form-control" style="width:60%;">
    <option value="aborn" selected>�����ځ[��</option>
    <option value="ng">�� NG</option>
    <option value="highlight">�� �n�C���C�g</option>
<!-- <option value="search">����</option> -->
</select><span class="input-group-btn"><button class="btn" type="button" onclick="SPM.doAction()">OK</button></span>
</div></div>
<div id="spm-color-action" class="input-group" style="display:none;">
<select id="spm-color-target" class="form-control" style="width:50%;">
    <option value="id">ID�J���[</option>
    <option value="watchoi">���b�`���C�J���[</option>
</select>
<select id="spm-color-rate" class="form-control" style="width:50%;">
    <option value="clear">�S�ăN���A</option>
    <option value="top10">�g�b�v10</option>
    <option value="average">���ψȏ�</option>
    <option value="rate">�ݒ�l�ȏ�</option>
    <option value="2">2�ȏ�</option>
</select><span class="input-group-btn"><button id="spm-color-ok" class="btn" type="button">OK</button></span>
</div>
<img id="spm-closer" src="img/iphone/close.png" width="24" height="26" onclick="SPM.hide(event)">
</div>
EOP;
        return $spm;
    }

    // }}}
    // {{{ idFilter()

    /**
     * ID�t�B���^�����O�����N�ϊ�
     *
     * @param   string $idstr ID:xxxxxxxxxx
     * @param   string $id xxxxxxxxxx
     * @return  string
     */
    public function idFilter($idstr, $id)
    {
        global $_conf;

        //$idflag = '';   // �g��/PC���ʎq
        // ID��8���܂���10��(+�g��/PC���ʎq)�Ɖ��肵��
        /*
        if (strlen($id) % 2 == 1) {
            $id = substr($id, 0, -1);
            $idflag = substr($id, -1);
        } elseif (isset($s[2])) {
            $idflag = $s[2];
        }
        */

        $num_ht = '';
        if (isset($this->thread->idcount[$id]) && $this->thread->idcount[$id] > 0) {
            $num = (string) $this->thread->idcount[$id];
            $num_ht = '('.$num.')';
        } else {
            return $idstr;
        }

        // �����W���̂����u:*�v��IPv6�`���p
        if ($_conf['coloredid.enable'] > 0
            && strlen($id) >= 4
            && preg_match("<^(?:ID:|���M��:) ?[0-9A-Za-z/.+:*]+>",$idstr)) {
            if ($_conf['coloredid.click'] > 0) {
                $id_click_evt = ($_conf['coloredid.smartphone.tap']) ? "{type:'dblclick'}" : "event";
                $num_ht = '<a href="javascript:void(0);" class="' . self::cssClassedId($idstr, $id) . '" onClick="idCol.click(\'' . $id . '\', ' . $id_click_evt . '); return false;">' . $num_ht . '</a>';
            }
            $idstr = $this->_coloredIdStr(
                $idstr, $id, $_conf['coloredid.click'] > 0 ? true : false);
        }

        $filter_url = $_conf['read_php'] . '?' . http_build_query(array(
            'host' => $this->thread->host,
            'bbs' => $this->thread->bbs,
            'key' => $this->thread->key,
            'ls' => 'all',
            'offline' => '1',
            'idpopup' => '1',
            'rf' => array(
                'field' => ResFilter::FIELD_ID,
                'method' => ResFilter::METHOD_JUST,
                'match' => ResFilter::MATCH_ON,
                'include' => ResFilter::INCLUDE_NONE,
                'word' => $id,
            ),
        ), '', '&amp;') . $_conf['k_at_a'];

        return "<a href=\"{$filter_url}\"{$this->target_at}>{$idstr}</a>{$num_ht}";
    }

    // }}}
    // {{{ watchoiFilter()

    /**
     * ���b�`���C�t�B���^�����O�����N�ϊ�
     *
     * @param   string  $watchoi_str    ���b�`���C�S�̕�����
     * @param   string  $watchoi_id     ���b�`���C���ʎq
     * @param   string  $watchoi_id4    ���b�`���C��4��
     * @return  string
     */
    public function watchoiFilter($watchoi_str, $watchoi_id, $watchoi_id4)
    {
        global $_conf;

        $wid = $_conf['ngaborn_watchoi4'] ? $watchoi_id4 : $watchoi_id;
        if (!isset($this->thread->watchoicount[$wid]) || $this->thread->watchoicount[$wid] <= 1) {
            return self::addIp2hostMarker($watchoi_str);
        }

        $count = $this->thread->watchoicount[$wid];
        $num_ht = '(' . $count . ')';

        if ($_conf['coloredid.enable'] > 0) {
            $wid32 = substr(md5($wid), 0, 8);

            if ($_conf['coloredid.click'] > 0) {
                $w_click_evt = ($_conf['coloredid.smartphone.tap']) ? "{type:'dblclick'}" : "event";
                $num_ht = '<a href="javascript:void(0);" class="' . self::cssClassedWatchoi($wid32) . '" onClick="watchoiCol.click(\'' . $wid32 . '\', ' . $w_click_evt . '); return false;">' . $num_ht . '</a>';
            }
            $watchoi_str = $this->_coloredWatchoiStr(
                $watchoi_id, $wid, $wid32, $_conf['coloredid.click'] > 0 ? true : false);
        }

        $filter_url = $_conf['read_php'] . '?' . http_build_query(array(
            'host'    => $this->thread->host,
            'bbs'     => $this->thread->bbs,
            'key'     => $this->thread->key,
            'ls'      => 'all',
            'offline' => '1',
            'idpopup' => '1',
            'rf'      => array(
                'field'   => ResFilter::FIELD_NAME,
                'method'  => ($_conf['ngaborn_watchoi4'] ? ResFilter::METHOD_WATCHOI4 : ResFilter::METHOD_JUST),
                'match'   => ResFilter::MATCH_ON,
                'include' => ResFilter::INCLUDE_NONE,
                'word'    => $watchoi_id,
            ),
        ), '', '&amp;') . $_conf['k_at_a'];

        $watchoi_str = self::addIp2hostMarker($watchoi_str);

        return "<a href=\"{$filter_url}\"{$this->target_at}>{$watchoi_str}</a>{$num_ht}";
    }

    // }}}
    // {{{ _linkToWikipeida()

    /**
     * @see ShowThread
     */
    protected function _linkToWikipeida($word)
    {
        global $_conf;

        $link = 'http://ja.wapedia.org/' . rawurlencode($word);
        if ($_conf['through_ime']) {
            $link = P2Util::throughIme($link);
        }

        return "<a href=\"{$link}\">{$word}</a>";
    }

    // }}}
    // {{{ quoteRes()

    /**
     * ���p�ϊ��i�P�Ɓj
     *
     * @param   string $full >>1-100
     * @param   string $qsign >>
     * @param   string $appointed_num 1-100
     * @return string
     */
    public function quoteRes($full, $qsign, $appointed_num)
    {
        global $_conf, $STYLE;

        if ($appointed_num == '-') {
            return $full;
        }

        $appointed_num = mb_convert_kana($appointed_num, 'n');   // �S�p�����𔼊p�����ɕϊ�
        if (preg_match('/\\D/', $appointed_num)) {
            $appointed_num = preg_replace('/\\D+/', '-', $appointed_num);
            return $this->quoteResRange($full, $qsign, $appointed_num);
        }
        if (preg_match('/^0/', $appointed_num)) {
            return $full;
        }
        $qnum = intval($appointed_num);
        if ($qnum < 1 || $qnum > $this->thread->rescount) {
            return $full;
        }

        $read_url = "{$_conf['read_php']}?host={$this->thread->host}&amp;bbs={$this->thread->bbs}&amp;key={$this->thread->key}&amp;offline=1&amp;ls={$appointed_num}";
        return "<a href=\"{$read_url}{$_conf['k_at_a']}\"{$this->respopup_at}{$this->target_at}>"
            . (in_array($qnum, $this->_aborn_nums) ? "<s><font color=\"{$STYLE['mobile_read_ngword_color']}\">{$full}</font></s>" :
                (in_array($qnum, $this->_ng_nums) ? "<s>{$full}</s>" : "{$full}")) . "</a>";
    }

    // }}}
    // {{{ quoteResRange()

    /**
     * ���p�ϊ��i�͈́j
     *
     * @param   string $full >>1-100
     * @param   string $qsign >>
     * @param   string $appointed_num 1-100
     * @return string
     */
    public function quoteResRange($full, $qsign, $appointed_num)
    {
        global $_conf;

        if ($appointed_num == '-') {
            return $full;
        }

        list($from, $to) = explode('-', $appointed_num);
        if (!$from) {
            $from = 1;
        } elseif ($from < 1 || $from > $this->thread->rescount) {
            return $full;
        }
        // read.php�ŕ\���͈͂𔻒肷��̂ŏ璷�ł͂���
        if (!$to) {
            $to = min($from + $_conf['mobile.rnum_range'] - 1, $this->thread->rescount);
        } else {
            $to = min($to, $from + $_conf['mobile.rnum_range'] - 1, $this->thread->rescount);
        }

        $read_url = "{$_conf['read_php']}?host={$this->thread->host}&amp;bbs={$this->thread->bbs}&amp;key={$this->thread->key}&amp;offline=1&amp;ls={$from}-{$to}";

        return "<a href=\"{$read_url}{$_conf['k_at_a']}\"{$this->target_at}>{$full}</a>";
    }

    // }}}
    // {{{ ktaiExtUrl()

    /**
     * �g�їp�O��URL�ϊ�
     *
     * @param   string $full
     * @param   string $url
     * @param   string $str
     * @return  string
     */
    public function ktaiExtUrl($full, $url, $str)
    {
        global $_conf;

        // �ʋ΃u���E�U
        $tsukin_link = '';
        if ($_conf['mobile.use_tsukin']) {
            $tsukin_url = 'http://www.sjk.co.jp/c/w.exe?y=' . rawurlencode($url);
            if ($_conf['through_ime']) {
                $tsukin_url = P2Util::throughIme($tsukin_url);
            }
            $tsukin_link = '<a href="' . $tsukin_url . '">��</a>';
        }

        // jig�u���E�UWEB http://bwXXXX.jig.jp/fweb/?_jig_=
        $jig_link = '';
        /*
        $jig_url = 'http://bwXXXX.jig.jp/fweb/?_jig_=' . rawurlencode($url);
        if ($_conf['through_ime']) {
            $jig_url = P2Util::throughIme($jig_url);
        }
        $jig_link = '<a href="'.$jig_url.'">j</a>';
        */

        if ($tsukin_link || $jig_link) {
            $ext_pre = '(' . $tsukin_link . (($tsukin_link && $jig_link) ? '|' : '') . $jig_link . ')';
        } else {
            $ext_pre = '';
        }

        if ($_conf['through_ime']) {
            $url = P2Util::throughIme($url);
        }
        return $ext_pre . '<a href="' . $url . '">' . $str . '</a>';
    }

    // }}}
    // {{{ ktaiExtUrlCallback()

    /**
     * �g�їp�O��URL�ϊ�
     *
     * @param   array $s ���K�\���Ƀ}�b�`�����v�f�̔z��
     * @return  string
     */
    public function ktaiExtUrlCallback(array $s)
    {
        return $this->ktaiExtUrl($s[0], $s[1], $s[2]);
    }

    // }}}
    // {{{ transLinkDo()����Ăяo�����URL�����������\�b�h
    /**
     * �����̃��\�b�h�͈����������Ώۃp�^�[���ɍ��v���Ȃ���false��Ԃ��A
     * transLinkDo()��false���Ԃ��Ă����$_url_handlers�ɓo�^����Ă��鎟�̊֐�/���\�b�h�ɏ��������悤�Ƃ���B
     */
    // {{{ plugin_linkURL()

    /**
     * URL�����N
     */
    public function plugin_linkURL($url, $purl, $str)
    {
        global $_conf;

        if (isset($purl['scheme'])) {
            // ime
            if ($_conf['through_ime']) {
                $link_url = P2Util::throughIme($purl[0]);
            } else {
                $link_url = $url;
            }
            return "<a href=\"{$link_url}\" target=\"_blank\">{$str}</a>";
        }
        return false;
    }

    // }}}
    // {{{ plugin_link2chSubject()

    /**
     * 2ch bbspink �����N
     */
    public function plugin_link2chSubject($url, $purl, $str)
    {
        global $_conf;

        if (preg_match('{^https?://(.+)/(.+)/$}', $purl[0], $m)) {
            //rep2�ɓo�^����Ă���Ȃ�΃����N����
            if (P2HostMgr::isRegisteredBbs($m[1], $m[2])) {
                $subject_url = "{$_conf['subject_php']}?host={$m[1]}&amp;bbs={$m[2]}";
                return "<a href=\"{$url}\">{$str}</a> [<a href=\"{$subject_url}{$_conf['k_at_a']}\">��p2�ŊJ��</a>]";
            }
        }
        return false;
    }

    // }}}
    // {{{ plugin_linkThread()

    /**
     * �X���b�h�����N
     */
    public function plugin_linkThread($url, $purl, $str)
    {
        global $_conf;

        list($nama_url, $host, $bbs, $key, $ls) = P2Util::detectThread($purl[0]);
        if ($host && $bbs && $key) {
            $read_url = "{$_conf['read_php']}?host={$host}&amp;bbs={$bbs}&amp;key={$key}&amp;ls={$ls}";
            return "<a href=\"{$read_url}{$_conf['k_at_a']}\">{$str}</a>";
        }

        return false;
    }

    // }}}
    // {{{ plugin_viewImage()

    /**
     * �摜�����N�ϊ�
     */
    public function plugin_viewImage($url, $purl, $str)
    {
        global $_conf;

        if (P2HostMgr::isUrlWikipediaJa($url)) {
            return false;
        }

        if (preg_match('{^https?://.+?\\.(jpe?g|gif|png)$}i', $url) && empty($purl['query'])) {
            $picto_url = 'http://pic.to/' . $purl['host'] . $purl['path'];
            $picto_tag = '<a href="' . $picto_url . '">(��)</a> ';
            if ($_conf['through_ime']) {
                $link_url = P2Util::throughIme($purl[0]);
                $picto_url = P2Util::throughIme($picto_url);
            } else {
                $link_url = $url;
            }
            return "{$picto_tag}<a href=\"{$link_url}\">{$str}</a>";
        }

        return false;
    }

    // }}}
    // {{{ plugin_replaceImageUrl()

    public function plugin_replaceImageUrl($url, $purl, $str)
    {
        global $_conf;
        global $pre_thumb_unlimited, $pre_thumb_ignore_limit, $pre_thumb_limit_k;

        if (P2HostMgr::isUrlWikipediaJa($url)) {
            return false;
        }

        // if (preg_match('{^https?://.+?\\.(jpe?g|gif|png)$}i', $url) && empty($purl['query'])) {
        // +Wiki
        global $replaceImageUrlCtl;

        $url = $purl[0];
        $replaced = $replaceImageUrlCtl->replaceImageUrl($url);
        if (!isset($replaced[0]) || !$replaced[0]) {
            return false;
        }

        foreach ($replaced as $v) {
            // �C�����C���v���r���[�̗L������
            if ($pre_thumb_unlimited || $pre_thumb_ignore_limit || $pre_thumb_limit_k > 0) {
                $inline_preview_flag = true;
                $inline_preview_done = false;
            } else {
                $inline_preview_flag = false;
                $inline_preview_done = false;
            }

            // +Wiki
            // $url_en = rawurlencode($url);
            $url_ht = $url;
            $url_en = rawurlencode($v['url']);
            $ref_en = $v['referer'] ? '&amp;ref=' . rawurlencode($v['referer']) : '';
            $img_str = null;
            $img_id = null;

            $icdb = new ImageCache2_DataObject_Images();

            // r=0:�����N;r=1:���_�C���N�g;r=2:PHP�ŕ\��
            // t=0:�I���W�i��;t=1:PC�p�T���l�C��;t=2:�g�їp�T���l�C��;t=3:���ԃC���[�W
            $img_url = 'ic2.php?r=0&amp;t=2&amp;uri=' . $url_en . $ref_en;
            $img_url2 = 'ic2.php?r=0&amp;t=2&amp;id=';
            $src_url = 'ic2.php?r=1&amp;t=0&amp;uri=' . $url_en . $ref_en;
            $src_url2 = 'ic2.php?r=1&amp;t=0&amp;id=';
            $src_exists = false;

            // ���C�ɃX�������摜�����N
            $rank = null;
            if ($_conf['expack.ic2.fav_auto_rank']) {
                $rank = $this->getAutoFavRank();
            }

            // DB�ɉ摜��񂪓o�^����Ă����Ƃ�
            if ($icdb->get($v['url'])) {
                $img_id = $icdb->id;

                // �E�B���X�Ɋ������Ă����t�@�C���̂Ƃ�
                if ($icdb->mime == 'clamscan/infected') {
                    return '[IC2:�E�B���X�x��]';
                }
                // ���ځ[��摜�̂Ƃ�
                if ($icdb->rank < 0) {
                    return '[IC2:���ځ[��摜]';
                }

                // �I���W�i���̗L�����m�F
                if (file_exists($this->thumbnailer->srcPath($icdb->size, $icdb->md5, $icdb->mime))) {
                    $src_exists = true;
                    $img_url = $img_url2 . $icdb->id;
                    $src_url = $this->thumbnailer->srcUrl($icdb->size, $icdb->md5, $icdb->mime);
                } else {
                    $img_url = $this->thumbnailer->thumbUrl($icdb->size, $icdb->md5, $icdb->mime);
                    $src_url = $src_url2 . $icdb->id;
                }

                // �C�����C���v���r���[���L���̂Ƃ�
                $prv_url = null;
                if ($this->thumbnailer->ini['General']['inline'] == 1) {
                    // PC��read_new_k.php�ɃA�N�Z�X�����Ƃ���
                    if (!isset($this->inline_prvw) || !is_object($this->inline_prvw)) {
                        $this->inline_prvw = $this->thumbnailer;
                    }
                    $prv_url = $this->inline_prvw->thumbUrl($icdb->size, $icdb->md5, $icdb->mime);

                    // �T���l�C���\���������ȓ��̂Ƃ�
                    if ($inline_preview_flag) {
                        // �v���r���[�摜������Ă��邩�ǂ�����img�v�f�̑���������
                        if (file_exists($this->inline_prvw->thumbPath($icdb->size, $icdb->md5, $icdb->mime))) {
                            $prvw_size = explode('x', $this->inline_prvw->calc($icdb->width, $icdb->height));
                            $img_str = "<img src=\"{$prv_url}\" width=\"{$prvw_size[0]}\" height=\"{$prvw_size[1]}\">";
                        } else {
                            $r_type = ($this->thumbnailer->ini['General']['redirect'] == 1) ? 1 : 2;
                            if ($src_exists) {
                                $prv_url = "ic2.php?r={$r_type}&amp;t=1&amp;id={$icdb->id}";
                            } else {
                                $prv_url = "ic2.php?r={$r_type}&amp;t=1&amp;uri={$url_en}";
                            }
                            $prv_url .= $this->img_dpr_query;
                            if ($this->img_dpr === 1.5 || $this->img_dpr === 2.0) {
                                $prv_onload = sprintf(' onload="autoAdjustImgSize(this, %f);"', $this->img_dpr);
                            } else {
                                $prv_onload = '';
                            }
                            $prvw_size[0] = $prvw_size[0] ?? '';
                            $prvw_size[1] = $prvw_size[1] ?? '';
                            $img_str = "<img src=\"{$prv_url}\"{$prv_onload} width=\"{$prvw_size[0]}\" height=\"{$prvw_size[1]}\">";
                        }
                        $inline_preview_done = true;
                    } else {
                        $img_str = '[p2:�����摜(�ݸ:' . $icdb->rank . ')]';
                    }
                }

                // �����X���^�C�����@�\��ON�ŃX���^�C���L�^����Ă��Ȃ��Ƃ���DB���X�V
                if (!is_null($this->img_memo) && strpos($icdb->memo, $this->img_memo) === false) {
                    $update = new ImageCache2_DataObject_Images();
                    if (!is_null($icdb->memo) && strlen($icdb->memo) > 0) {
                        $update->memo = $this->img_memo . ' ' . $icdb->memo;
                    } else {
                        $update->memo = $this->img_memo;
                    }
                    $update->whereAddQuoted('uri', '=', $v['url']);
                }

                // expack.ic2.fav_auto_rank_override �̐ݒ�ƃ����N������OK�Ȃ�
                // ���C�ɃX�������摜�����N���㏑���X�V
                if ($rank !== null &&
                    self::isAutoFavRankOverride($icdb->rank, $rank)
                ) {
                    if ($update === null) {
                        $update = new ImageCache2_DataObject_Images();
                        $update->whereAddQuoted('uri', '=', $v['url']);
                    }
                    $update->rank = $rank;

                }
                if (isset($update) && $update !== null) {
                    $update->update();
                }

                // �摜���L���b�V������Ă��Ȃ��Ƃ�
                // �����X���^�C�����@�\��ON�Ȃ�N�G����UTF-8�G���R�[�h�����X���^�C���܂߂�
            } else {
                // �摜���u���b�N���X�gor�G���[���O�ɂ��邩�m�F
                if (false !== ($errcode = $icdb->ic2_isError($v['url']))) {
                    return "<s>[IC2:�װ({$errcode})]</s>";
                }

                // �C�����C���v���r���[���L���ŁA�T���l�C���\���������ȓ��Ȃ�
                if ($this->thumbnailer->ini['General']['inline'] == 1 && $inline_preview_flag) {
                    $rank_str = ($rank !== null) ? '&rank=' . $rank : '';
                    $prvw_size[0] = $prvw_size[0] ?? '';
                    $prvw_size[1] = $prvw_size[1] ?? '';
                    $img_str = "<img src=\"ic2.php?r=2&amp;t=1&amp;uri={$url_en}{$this->img_memo_query}{$rank_str}{$ref_en}\" width=\"{$prvw_size[0]}\" height=\"{$prvw_size[1]}\">";
                    $inline_preview_done = true;
                } else {
                    $img_url .= $this->img_memo_query;
                }
            }

            // �\�����������f�N�������g
            if ($inline_preview_flag && $inline_preview_done) {
                if (!is_null($pre_thumb_limit_k)) $pre_thumb_limit_k--;
            }

            if (!empty($_SERVER['REQUEST_URI'])) {
                $backto = '&amp;from=' . rawurlencode($_SERVER['REQUEST_URI']);
            } else {
                $backto = '';
            }

            $result = "";

            if (is_null($img_str)) {
                $result .= sprintf('<a href="%s%s">[IC2:%s:%s]</a>',
                    $img_url,
                    $backto,
                    p2h($purl['host']),
                    p2h(basename($purl['path']))
                );
            }

            $img_title = p2h($purl['host'])
                . '&#10;'
                . p2h(basename($purl['path']));
            $result .= "<a class=\"limelight\" href=\"{$src_url}\" title=\"{$img_title}\" target=\"_blank\">{$img_str}</a>"
                //. ' <img class="ic2-show-info" src="img/s2a.png" width="16" height="16" onclick="ic2info.show('
                . ' <input type="button" class="ic2-show-info" value="i" onclick="ic2info.show('
                . (($img_id) ? $img_id : "'{$v['url']}'") . ', event)">';
        }

        $linkUrlResult = $this->plugin_linkURL($url, $purl, $str);
        if ($linkUrlResult !== false) {
            $result .= $linkUrlResult;
        }

        return $result;
    }

    // }}}
    // {{{ plugin_linkPlugin()

    /**
     * +Wiki:�����N�v���O�C��
     */
    public function plugin_linkPlugin($url, $purl, $str)
    {
        return $GLOBALS['linkPluginCtl']->replaceLinkToHTML($url, $str);
    }
    // }}}
    // {{{ _quotebackHorizontalListHtml()

    protected function _quotebackHorizontalListHtml($anchors, $resnum)
    {
        global $_conf;

        if ($_GET['showbl']) {
            return '';
        }
        $anchors = array_diff($anchors, array($resnum));
        if (!$anchors) {
            return '';
        }
        $ret = '';

        $plus = array();
        foreach ($anchors as $num) {
            $plus = array_merge($plus, $this->_getQuotebackCount($num));
        }
        $plus = array_unique($plus);
        $plus_cnt = count(array_diff($plus, $anchors));
        $plus_str = count($plus) > 0 ? '+' . ($plus_cnt > 0 ? $plus_cnt : '') : '';

        $url = $_conf['read_php'] . '?' . http_build_query(array(
            'host' => $this->thread->host,
            'bbs' => $this->thread->bbs,
            'key' => $this->thread->key,
            'ls' => $resnum,
            'offline' => '1',
            'showbl' => '1',
        ), '', '&amp;') . $_conf['k_at_a'];

        $suppress = false;
        $n = 0;
        $reslist = array();
        foreach ($anchors as $anchor) {
            if ($anchor == $resnum) continue;
            $n++;
            if ($_conf['mobile.backlink_list.suppress'] > 0
                && $n > $_conf['mobile.backlink_list.suppress']
            ) {
                $suppress = true;
                break;
            }
            $reslist[] = $this->quoteRes('>>' . $anchor, '>>', $anchor);
        }

        $res_navi = '';
        if ($_conf['mobile.backlink_list.openres_navi'] == 1
            || ($_conf['mobile.backlink_list.openres_navi'] == 2
                && $suppress === true)
        ) {
            if (count($anchors) > 1 || $plus_str) {
                $res_navi = "(<a href=\"{$url}\"{$this->target_at}>"
                    . (count($anchors) > 1 ? count($anchors) : '')
                    . $plus_str . '</a>)';
            }
        }

        $res_count = count($reslist);
        if ($res_count === 1 && $suppress === true && $_conf['mobile.backlink_list.suppress'] == 1) {
            $ret .= sprintf('<div>�y�Q��ڽ %s�z</div>', $res_navi);
        } elseif ($res_count === 1 && $suppress === false) {
            $ret .= sprintf('<div>�y�Q��ڽ %s%s�z</div>', $reslist[0], $res_navi);
        } else {
            for ($n = 0; $n < $res_count; $n++) {
                $ret .= '<div>�y�Q��ڽ ' . $reslist[$n] . '�z</div>';
            }
            $ret .= '<div>' . ($suppress ? '��' : '') . $res_navi . '</div>';
        }

        return '<div class="reslist">' . $ret . '</div>';
    }

    // }}}
    // {{{ _getQuotebackCount()

    protected function _getQuotebackCount($num, $checked = null)
    {
        $ret = array();
        if ($checked === null) {
            $checked = array();
        }
        $checked[] = $num;
        $quotes = $this->getQuoteFrom();
        if ($quotes[$num]) {
            $ret = $quotes[$num];
            foreach ($quotes[$num] as $quote_num) {
                if ($quote_num != $num && !in_array($quote_num, $checked)) {
                    $ret = array_merge($ret, $this->_getQuotebackCount($quote_num, array_merge($ret, $checked)));
                }
            }
        }
        return $ret;
    }

    // }}}
}

// }}}

/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
