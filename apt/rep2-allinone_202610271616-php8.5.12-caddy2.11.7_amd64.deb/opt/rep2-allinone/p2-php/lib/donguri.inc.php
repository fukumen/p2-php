<?php
/**
 * rep2 - �ǂ񂮂苤�ʏ���
 */

class Donguri {

    private const COOKIE_HOST = 'www.5ch.net';
    private const COOKIE_NAME = 'acorn';
    private const SID_NAME = 'sid';
    private const BASE_MATCH = '/>(\S+)<\/div><div>(\S+)\[\s*ID:\s*([^\]]+)/';
    private static $instance = null;
    private $base_url = null;
    private $cookie_key = null;
    private $cookies = null;
    private $cookie_sts = null;     // 0:�N�b�L�[�Ȃ��A1:�ǂ񂮂薳���A2:�ǂ񂮂�L��
    private $status_data = null;    // �X�e�[�^�X(�\���p)

    // new�֎~
    private function __construct()
    {
        global $_conf, $_login;

        $this->base_url = P2Util::selectScheme($_conf['2ch_domain']) . '://donguri.' . $_conf['2ch_domain'] . '/';
        $this->cookie_key = $_login->user_u . '/' . self::COOKIE_HOST;
        $this->_read_cookie();
    }

    // �C���X�^���X�擾
    private static function _get_instance()
    {
        if (!self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    // �N���[���֎~
    private function __clone()
    {
    }

    // {{{ _update_cookie_sts()

    /**
     * �N�b�L�[�X�e�[�^�X�X�V
     */
    private function _update_cookie_sts()
    {
        if ($this->cookies == null) {
            $this->cookie_sts = 0; // �N�b�L�[����
        } elseif (!array_key_exists(self::COOKIE_NAME, $this->cookies)) {
            $this->cookie_sts = 1; // �ǂ񂮂薳��
        } else {
            $this->cookie_sts = 2; // �ǂ񂮂�L��
        }
        return;
    }

    // }}}
    // {{{ _read_cookie()

    /**
     * �N�b�L�[�ǂݍ���
     */
    private function _read_cookie()
    {
        $this->cookies = CookieDataStore::loadActive($this->cookie_key);
        if (!$this->cookies) {
            $this->cookies = null;
        }
        $this->_update_cookie_sts();
        return;
    }

    // }}}
    // {{{ _check_base()

    /**
     * �ǂ񂮂��n�m�F(����)
     */
    private function _check_base()
    {
        $detail = null;
        $msg = null;

        $req = P2Commun::createHTTPRequest ($this->base_url, P2CurlRequest::METHOD_GET);
        foreach ($this->cookies as $cname => $c) {
            $req->addCookie($cname, $c['value']);
        }
        $response = P2Commun::getHTTPResponse($req);

        $code = $response->getStatus();
        if ($code == 200) {
            $body = mb_convert_encoding($response->getBody(), 'CP932', 'UTF-8');
            // ���̃p�X�ɗ���̂͐�����z�肵�Ă���
            if (preg_match(self::BASE_MATCH, $body, $matches)) {
                $detail = [$matches[1], $matches[2], $matches[3]];
            } else {
                $msg = self::_make_errmsg($body);
            }
        }
        return [$detail, $msg];
    }

    // }}}
    // {{{ check_base()

    /**
     * �ǂ񂮂��n�m�F
     */
    public static function check_base()
    {
        global $_conf;

        $msg = null;
        $donguri = self::_get_instance();
        try {
            $detail = null;
            if ($donguri->cookie_sts == 2) {
                [$detail, $msg] = $donguri->_check_base();
            }
            $donguri->_update_status($detail);
        } catch (Exception $e) {
        }
        if ($msg) {
            $delimiter = $_conf['iphone'] ? '&nbsp' : '<br>�@';
            return $delimiter . $msg;
        } else {
            return '';
        }
    }

    // }}}
    // {{{ _finish_base()

    /**
     * �ǂ񂮂��n�㏈��
     */
    private function _finish_base($response)
    {
        $detail = null;
        $msg = null;

        // Cookie���擾
        $response_cookies = $response->getCookies();
        if ($response_cookies) {
            if (!$this->cookies) {
                $this->cookies = array();
            }
            CookieDataStore::mergeResponse($this->cookies, $response_cookies);
            // cookie �ۑ�
            if ($this->cookies) {
                CookieDataStore::set($this->cookie_key, $this->cookies);
            } else {
                CookieDataStore::delete($this->cookie_key);
            }
        }

        $this->_update_cookie_sts();
        $code = $response->getStatus();
        if ($code == 302) {
            if ($this->cookie_sts == 2) {
                [$detail, $msg] = $this->_check_base();
            }
        } elseif ($code == 200) {
            $body = mb_convert_encoding($response->getBody(), 'CP932', 'UTF-8');
            // ���̃p�X�ɗ���̂̓G���[��z�肵�Ă��邪�A���̂����O�C���o���Ă����炻�̏��ōX�V����
            if (preg_match(self::BASE_MATCH, $body, $matches)) {
                $detail = [$matches[1], $matches[2], $matches[3]];
            } else {
                $msg = self::_make_errmsg($body);
            }
        }
        return [$detail, $msg];
    }

    // }}}
    // {{{ login_base()

    /**
     * �ǂ񂮂��n���O�C��
     */
    public static function login_base()
    {
        global $_conf;

        $sid = null;
        $msg = null;
        $donguri = self::_get_instance();
        try {
            $detail = null;
            if ($_conf['donguri_method'] == 1) {
                if ($array = P2Util::readIdPw2ch()) {
                    [$user, $pass, $autoLogin, $methodLogin2ch] = $array;
                    if (file_exists($_conf['siduplift_file'])) {
                        require_once P2_LIB_DIR . '/login2ch.inc.php';
                        $data = get_uplift_sid($array);
                        if (isset($data['sid'])) {
                            $sid = $data['sid'];
                        }
                    }
                    if (P2Util::hasInfoHtml()) {
                        // login2ch_uplift�̃G���[���b�Z�[�W���擾
                        $msg = P2Util::getInfoHtml();
                    }
                } else {
                    $msg = '2ch���O�C���Ǘ���UPLIFT�A�J�E���g���o�^����Ă��܂���';
                }
            }
            if (!$msg) {
                $req = P2Commun::createHTTPRequest ($donguri->base_url . 'login', P2CurlRequest::METHOD_POST);
                foreach ($donguri->cookies as $cname => $c) {
                    $req->addCookie($cname, $c['value']);
                }
                if ($sid) {
                    // uplift��sid�͖����ł����O�C���o����悤�����A���O�C�����Ă���Ȃ�t����
                    $req->addCookie($sid['name'], $sid['value']);
                }

                $req->setHeader('Referer', $donguri->base_url);
                $req->setHeader('Origin', rtrim($donguri->base_url, '/'));
                if ($_conf['donguri_method'] == 1) {
                    $req->addPostParameter('email', $user);
                    $req->addPostParameter('pass', $pass);
                } else {
                    $req->addPostParameter('email', $_conf['donguri_user']);
                    $req->addPostParameter('pass', $_conf['donguri_password']);
                }
                $response = P2Commun::getHTTPResponse($req);

                [$detail, $msg] = $donguri->_finish_base($response);
            }
            $donguri->_update_status($detail);
        } catch (Exception $e) {
        }
        if ($msg) {
            $delimiter = $_conf['iphone'] ? '&nbsp' : '<br>�@';
            return $delimiter . $msg;
        } else {
            return '';
        }
    }

    // }}}
    // {{{ logout_base()

    /**
     * �ǂ񂮂��n���O�A�E�g
     */
    public static function logout_base()
    {
        global $_conf;

        $msg = null;
        $donguri = self::_get_instance();
        try {
            $detail = null;
            if ($donguri->cookie_sts == 2) {
                $req = P2Commun::createHTTPRequest ($donguri->base_url . "logout", P2CurlRequest::METHOD_GET);
                foreach ($donguri->cookies as $cname => $c) {
                    $req->addCookie($cname, $c['value']);
                }
                $req->setHeader('Referer', $donguri->base_url);
                $response = P2Commun::getHTTPResponse($req);

                [$detail, $msg] = $donguri->_finish_base($response);
            } else {
                $msg = '�ǂ񂮂肪����܂���';
            }
            $donguri->_update_status($detail);
        } catch (Exception $e) {
        }
        if ($msg) {
            $delimiter = $_conf['iphone'] ? '&nbsp' : '<br>�@';
            return $delimiter . $msg;
        } else {
            return '';
        }
    }

    // }}}
    // {{{ _load_status()

    /**
     * �L���b�V���擾
     */
    private function _load_status()
    {
        global $_conf;

        if ($this->status_data == null && file_exists($_conf['donguri_cache'])) {
            $content = file_get_contents($_conf['donguri_cache']);
            $this->status_data = @unserialize($content);
        }
        if ($this->cookie_sts != 2 && $this->status_data
            && isset($this->status_data['status']) && $this->status_data['status'] >= 2) {
            // �ǂ񂮂肪�����̂ɉߋ��̂ǂ񂮂�L���Ԃ��c���Ă���ꍇ�A�\����␳����
            $this->_update_status(null);
        }
        return $this->status_data;
    }

    // }}}
    // {{{ _update_status()

    /**
     * �X�e�[�^�X�X�V
     */
    private function _update_status($detail)
    {
        global $_conf;

        $data = array();
        if ($this->cookie_sts == 0) {
            $data['status'] = 0; // �N�b�L�[����
        } elseif ($this->cookie_sts == 1) {
            $data['status'] = 1; // �ǂ񂮂薳��
        } elseif ($detail == null) {
            $data['status'] = 2; // �s���Ȃǂ񂮂�
        } else {
            if ($detail[1] == "�x������") {
                $data['status'] = 3; // �x������
            } else {
                $data['status'] = 4; // �x������ or �n���^�[
            }
            $data['name'] = $detail[0];
            $data['job'] = $detail[1];
            $data['id'] = $detail[2];
        }
        $this->status_data = $data;

        // �L���b�V���ۑ�
        $temp_file = $_conf['donguri_cache'] . '.tmp';
        if (FileCtl::file_write_contents($temp_file, serialize($data)) === false) {
            return;
        }
        @chmod($temp_file, 0600);

        if (!rename($temp_file, $_conf['donguri_cache'])) {
            @unlink($temp_file);
        }
    }

    // }}}
    // {{{ getAcornValue()

    /**
     * �ǂ񂮂�̒l���擾
     */
    public static function get_donguri()
    {
        $donguri = self::_get_instance();
        return isset($donguri->cookies[self::COOKIE_NAME]['value'])
            ? $donguri->cookies[self::COOKIE_NAME]['value'] : null;
    }

    // }}}
    // {{{ _make_errmsg()

    /**
     * �G���[���b�Z�[�W�쐬
     */
    private static function _make_errmsg($body)
    {
        if (str_starts_with($body, 'NG<>')) {
            return substr($body, 4);
        } else {
            return '�s���ȃG���[';
        }
    }

    // }}}
    // {{{ get_status_text()

    /**
     * �X�e�[�^�X�\��
     */
    public static function get_status_text()
    {
        global $_conf;

        $donguri = self::_get_instance();
        $data = $donguri->_load_status();
        $is_iphone = $_conf['iphone'] ? '1' : '0';
        $delimiter = $_conf['iphone'] ? '&nbsp' : '<br>�@';
        if ($_conf['donguri_method'] == 1 && file_exists($_conf['idpw2ch_php'])) {
            $login_link = $delimiter . '[<a href="javascript:void(0);" onclick="return loginDonguri(' . $is_iphone . ');">���O�C��</a>]';
        } elseif ($_conf['donguri_user'] && $_conf['donguri_password'] && strlen($_conf['donguri_user']) > 0 && strlen($_conf['donguri_password']) > 0) {
            $login_link = $delimiter . '[<a href="javascript:void(0);" onclick="return loginDonguri(' . $is_iphone . ');">���O�C��</a>]';
        } else {
            $login_link = '';
        }

        if (!$data) {
            $txt = '���m�F [<a href="javascript:void(0);" onclick="return checkDonguri(' . $is_iphone . ');">�m�F</a>]';
        } elseif ($data['status'] == 0) {
            //$txt = '�N�b�L�[����';
            $txt = '�ǂ񂮂薳��';
            $txt .= $login_link;
        } elseif ($data['status'] == 1) {
            $txt = '�ǂ񂮂薳��';
            $txt .= $login_link;
        } elseif ($data['status'] == 2) {
            $txt = '[<a href="javascript:void(0);" onclick="return checkDonguri(' . $is_iphone . ');">�m�F</a>]';
            $txt .= $delimiter . '�s���Ȃǂ񂮂�';
            $txt .= $login_link;
        } elseif ($data['status'] == 3) {
            $txt = '[<a href="dongurictl.php?mode=get_donguri"' . $_conf['ext_win_target_at'] . '>�ǂ񂮂��n</a>]';
            $txt .= $delimiter . $data['name'] . $delimiter . $data['job'] . $delimiter . "ID:" . $data['id'];
            $txt .= $login_link;
        } elseif ($data['status'] == 4) {
            $txt = '[<a href="' . P2Util::throughIme('https://donguri.' . $_conf['2ch_domain'] . '/') . '"' . $_conf['ext_win_target_at'] . '>�ǂ񂮂��n</a>]';
            $txt .= $delimiter . $data['name'] . $delimiter . $data['job'] . $delimiter . "ID:". $data['id'];
            $txt .= $delimiter . '[<a href="javascript:void(0);" onclick="return logoutDonguri(' . $is_iphone . ');">���O�A�E�g</a>]';
        } else {
            $txt = '�G���[';
        }
        return $txt;
    }

    // }}}
    // {{{ check_status()

    /**
     * �X�e�[�^�X�m�F
     */
    public static function check_status()
    {
        global $_conf;

        $donguri = self::_get_instance();
        $data = $donguri->_load_status();
        $is_iphone = $_conf['iphone'] ? '1' : '0';

        if (!$data) {
            echo '<script type="text/javascript">checkDonguri(' . $is_iphone . ');</script>';
        }
    }

    // }}}
    // {{{ need_relogin()

    /**
     * �������ݑO�ɂǂ񂮂��n�ւ̍ă��O�C�����K�v���ǂ�����Ԃ�
     * acorn �������A�܂��͊����؂� 1 ���ԑO�ȍ~�̏ꍇ�� true
     */
    public static function need_relogin()
    {
        $donguri = self::_get_instance();
        if ($donguri->cookie_sts != 2) {
            return true;
        }
        $expires = $donguri->cookies[self::COOKIE_NAME]['expires'] ?? null;
        return ($expires !== null && time() > $expires - 3600);
    }

    // }}}
}

/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:description
