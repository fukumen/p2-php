<?php
/**
 * rep2 - iPhone/iPod Touch��p���j���[ (�viui)
 *
 * @link http://code.google.com/p/iui/
 */

require_once __DIR__ . '/../init.php';
require_once P2_LIB_DIR . '/menu_iphone.inc.php';

$_login->authorize(); //���[�U�F��

if ($_conf['view_forced_by_query'] || isset($_REQUEST['b'])) {
    output_add_rewrite_var('b', $_conf['b']);
}

// {{{ ���X�g (Ajax)

if (isset($_GET['cateid'])) {
    menu_iphone_ajax('menu_iphone_show_board_menu', (int)$_GET['cateid']);
    exit;
}

// }}}
// {{{ ���� (Ajax)

if (isset($_POST['word'])) {
    $word = menu_iphone_unicode_urldecode($_POST['word']);
    if (substr_count($word, '.') == strlen($word)) {
        $word = '';
    }

    if (strlen($word) > 0 && p2_set_filtering_word($word, 'and') !== null) {
        menu_iphone_ajax('menu_iphone_show_matched_boards', $word);
    } else {
        header('Content-Type: application/xml; charset=UTF-8');
        echo mb_convert_encoding('<div class="panel">�����ȃL�[���[�h�ł��B</div>', 'UTF-8', 'CP932');
    }
    exit;
}

// }}}
// {{{ �r���h���

$ver_str = array();
foreach (array('VER_REPO_TYPE', 'VER_REPO_HASH', 'VER_REPO_LOG', 'VER_RUN_ID', 'VER_RUN_NUMBER') as $key) {
    if (($val = getenv($key)) !== false) {
        $ver_str[$key] = $val;
    }
}
if (empty($ver_str['VER_REPO_TYPE'])) {
    $ver_str['VER_REPO_TYPE'] = 'docker-rep2';
}

$current_rep2_hash_en = '';
$fukumen_url = "https://github.com/fukumen/p2-php";
$fukumen_url_r = P2Util::throughIme($fukumen_url);

if (count($ver_str) >= 5) {
    $ver_str['VER_REPO_LOG'] = mb_convert_encoding(base64_decode($ver_str['VER_REPO_LOG']), 'CP932', 'UTF-8');
    $current_rep2_hash_en = rawurlencode($ver_str['VER_REPO_HASH']);
    $htm['ver_str'] = <<<EOT
    <li class="group">�r���h���</li>
    <li><div style="word-break:break-all;">{$ver_str['VER_REPO_TYPE']}: {$ver_str['VER_REPO_LOG']}&nbsp;{$ver_str['VER_REPO_HASH']}</div></li>
    <li><div style="word-break:break-all;">github action: run_id:{$ver_str['VER_RUN_ID']}&nbsp;run_number:{$ver_str['VER_RUN_NUMBER']}</div></li>
EOT;
} else {
    $htm['ver_str'] = '';
}

// }}}
// {{{ HTML�o��
// {{{ �w�b�_
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="ja" xml:lang="ja">
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=Shift_JIS" />
    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=yes" />
    <meta name="ROBOTS" content="NOINDEX, NOFOLLOW" />
    <title>rep2</title>
    <link rel="stylesheet" type="text/css" href="iui/iui.css?<?php echo $_conf['p2_version_id']; ?>" />
    <link rel="stylesheet" type="text/css" href="css/menu_i.css?<?php echo $_conf['p2_version_id']; ?>" />
    <style type="text/css">
        #donguri_content a:link,
        #donguri_content a:visited {
            color: #000;
        }
<?php
    if ($_conf['mobile_dark_mode'] != 1) {
        $dark_prefix = ($_conf['mobile_dark_mode'] == 0) ? "@media (prefers-color-scheme: dark) {\n" : "";
        $dark_suffix = ($_conf['mobile_dark_mode'] == 0) ? "}\n" : "";
        echo <<<EODARK
        {$dark_prefix}
        body { background: #121212 !important; color: #e0e0e0 !important; }
        body > ul > li { border-bottom: 1px solid #333 !important; }
        body > ul > li.group {
            background: #222 !important;
            color: #bbb !important;
            border-top: 1px solid #444 !important;
            border-bottom: 1px solid #111 !important;
            text-shadow: none !important;
        }
        body > .panel { background: #1a1a1a !important; }
        .panel > fieldset { background: #2c2c2c !important; border-color: #444 !important; }
        .panel > h2 { color: #aaa !important; text-shadow: none !important; }
        
        #donguri_content a:link,
        #donguri_content a:visited {
            color: #e0e0e0 !important;
        }
        
        /* Links in List */
        body > ul > li > a:link,
        body > ul > li > a:visited {
            color: #e0e0e0 !important;
        }
        
        /* Toolbar & Buttons */
        body > .toolbar { background: #333 !important; border-bottom: 1px solid #2d3642 !important; }
        .toolbar > h1 { color: #FFFFFF !important; text-shadow: rgba(0, 0, 0, 0.4) 0px -1px 0 !important; }
        .button { background: #444 !important; color: #FFFFFF !important; border: 1px solid #555 !important; border-radius: 5px !important; }
        .button:active { background: #666 !important; }
        {$dark_suffix}
EODARK;
    }
?>
    </style>
    <?php echo $_conf['touch_icon_ht'] ?? ''; ?>
    <script type="text/javascript" src="iui/iui.js?<?php echo $_conf['p2_version_id']; ?>"></script>
    <script type="text/javascript" src="js/json2.js?<?php echo $_conf['p2_version_id']; ?>"></script>
<?php /*if (UA::isAndroidWebKit()) { ?>
    <script type="text/javascript">window.jsxpath = { 'useNative': false };</script>
    <script type="text/javascript" src="js/javascript-xpath.js?<?php echo $_conf['p2_version_id']; ?>"></script>
<?php }*/ ?>
    <script type="text/javascript" src="js/iphone.js?<?php echo $_conf['p2_version_id']; ?>"></script>
    <script type="text/javascript" src="js/menu_i.js?<?php echo $_conf['p2_version_id']; ?>"></script>
<?php
    if ($_conf['donguri_use']) {
    echo <<<EOP
    <script type="text/javascript" src="js/basic.js?{$_conf['p2_version_id']}"></script>
    <script type="text/javascript" src="js/donguri.js?{$_conf['p2_version_id']}"></script>\n
EOP;
    }
?>
<?php
// {{{ �w��T�u���j���[�֎����ňړ�
// $hashes�̎擾���������Ȃ̂ŕ���B
/*
if (isset($hashes) && is_array($hashes) && count($hashes)) {
    $js = '';
    $last = array_pop($hashes);
    while (($hash = array_shift($hashes)) !== null) {
        $hash = trim($hash);
        if ($hash === '') {
            continue;
        }
        $js .= "'" . StrCtl::toJavaScript($hash) . "',";
    }
    $hash = trim($last);
    if ($hash !== '') {
        $js .= "'" . StrCtl::toJavaScript($hash) . "'";
    } else {
        $js .= "'_'";
    }
?>
    <script type="text/javascript">
    // <![CDATA[
    window.addEventListener('load', function(event) {
        window.removeEventListener(event.type, arguments.callee, false);

        window.setTimeout(function(subMenus, contextNode, delayMsec) {
            var id, anchor, child, evt;

            if (!subMenus.length || !contextNode) {
                return;
            }

            id = subMenus.shift();
            anchor = document.evaluate('./li/a[@href="#' + id + '"]',
                                       contextNode,
                                       null,
                                       XPathResult.FIRST_ORDERED_NODE_TYPE,
                                       null).singleNodeValue;
            child = document.getElementById(id);

            if (anchor && child) {
                evt = document.createEvent('MouseEvents');
                evt.initMouseEvent('click', true, true, window,
                                   0, 0, 0, 0, 0,
                                   false, false, false, false, 0, null);
                anchor.dispatchEvent(evt);

                if (subMenus.length) {
                    contextNode = child;
                    window.setTimeout(arguments.callee, delayMsec,
                                      subMenus, child, delayMsec);
                }
            }
        }, 200, [<?php echo $js; ?>], document.getElementById('top'), 200);
    }, false);
    // ]]>
    </script>
<?php
}*/
// }}}
?>
</head>
<body>

<?php
// }}}
// {{{ �c�[���o�[
?>

<div class="toolbar">
    <h1 id="pageTitle"></h1>
    <a id="backButton" class="button" style="z-index:2; padding: 1px 3.5px 0 3.5px;" href="#"></a>
    <a class="button leftButton" style="padding: 1px 10px 0 10px;" href="#boardSearch">��</a>
    <a class="button" href="#threadSearch">�X��</a>
</div>

<?php
// }}}
// {{{ �g�b�v���j���[
?>

<ul id="top" title="rep2" selected="true">
<?php if (P2Util::hasInfoHtml()) { ?>
    <li><a href="#info_msg" class="color-r">�G���[</a></li>
<?php } ?>
    <li class="group">���X�g</li>
<?php if ($_conf['expack.misc.multi_favs']) { ?>
    <li><a href="#fav">���C�ɃX��</a></li>
<?php } else { ?>
    <?php /* <li><a href="subject.php?spmode=fav&amp;sb_view=shinchaku" target="_self">���C�ɃX���̐V��</a></li> */ ?>
    <li><a href="subject.php?spmode=fav<?php echo $_conf['k_at_a']; ?>" target="_self">���C�ɃX��</a></li>
<?php } ?>
    <li><a href="#favita">���C�ɔ�</a></li>
    <li><a href="menu_i.php?cateid=0<?php echo $_conf['k_at_a']; ?>">���X�g</a></li>
    <li><a href="subject.php?spmode=palace&amp;norefresh=1<?php echo $_conf['k_at_a']; ?>" target="_self">�X���̓a��</a></li>

    <li class="group">����</li>
    <?php /* <li><a href="subject.php?spmode=recent&amp;sb_view=shinchaku" target="_self">�ŋߓǂ񂾃X���̐V��</a></li> */ ?>
    <li><a href="subject.php?spmode=recent&amp;norefresh=true<?php echo $_conf['k_at_a']; ?>" target="_self">�ŋߓǂ񂾃X��</a></li>
<?php if ($_conf['res_hist_rec_num']) { ?>
    <li><a href="subject.php?spmode=res_hist<?php echo $_conf['k_at_a']; ?>" target="_self">�������ݗ���</a></li>
<?php if ($_conf['res_write_rec']) { ?>
    <li><a href="read_res_hist.php<?php echo $_conf['k_at_q']; ?>" target="_self">�������ݗ����̓��e</a></li>
<?php } } ?>

    <li class="group">expack</li>
<?php if ($_conf['expack.rss.enabled']) { ?>
    <li><a href="#rss">RSS</a></li>
<?php } ?>
<?php if ($_conf['expack.ic2.enabled'] == 2 || $_conf['expack.ic2.enabled'] == 3) { ?>
    <li><a href="iv2.php?reset_filter=1<?php echo $_conf['k_at_a']; ?>" target="_self">�摜�L���b�V���ꗗ</a></li>
<?php } ?>
    <li><a href="#tgrep">�X���b�h����</a></li>
    <li><a href="first_cont.php<?php echo $_conf['k_at_q']; ?>" target="_self">�X��URL�����</a></li>
    <li class="group">�Ǘ�</li>
    <li><a href="editpref.php<?php echo $_conf['k_at_q']; ?>" target="_self">�ݒ�Ǘ�</a></li>
    <li><a href="setting.php<?php echo $_conf['k_at_q']; ?>" target="_self">���O�C���Ǘ�</a></li>
    <li><a href="#login_info">���O�C�����</a></li>
    <li><a href="#rep2_info">rep2���</a></li>
</ul>

<?php
// }}}
// {{{ �G���[

if (P2Util::hasInfoHtml()) {
    echo '<div id="info_msg" class="panel" title="�G���[">';
    P2Util::printInfoHtml();
    echo '</div>';
}

// }}}
// {{{ �T�u���j���[

if ($_conf['expack.misc.multi_favs']) {
    // {{{ ���C�ɃX��

    $favlist = FavSetManager::getFavSetTitles('m_favlist_set');
    if (!$favlist) {
        $favlist = array();
    }
    $fav_elems = '';
    $fav_new_elems = '';
    $fav_elem_prefix = '';

    for ($no = 0; $no <= $_conf['expack.misc.favset_num']; $no++) {
        if (isset($favlist[$no]) && strlen($favlist[$no]) > 0) {
            $name = $favlist[$no];
        } else {
            $favlist[$no] = $name = ($no ? "���C�ɃX��{$no}" : '���C�ɃX��');
        }
        $fav_url = "subject.php?spmode=fav&amp;m_favlist_set={$no}{$_conf['k_at_a']}";
        $fav_elems .= "<li><a href=\"{$fav_url}\" target=\"_self\">{$name}</a></li>";
        //$fav_new_elems .= "<li><a href=\"{$fav_url}&amp;sb_view=shinchaku\" target=\"_self\">{$name}</a></li>";
    }

    echo '<ul id="fav" title="���C�ɃX��">';
    //echo '<li class="group">�V��</li>';
    //echo $fav_new_elems;
    //echo '<li class="group">�S��</li>';
    echo $fav_elems;
    echo "</ul>\n";

    // }}}
    // {{{ ���C�ɔ�

    $favita = FavSetManager::getFavSetTitles('m_favita_set');
    if (!$favita) {
        $favita = array();
    }

    echo '<ul id="favita" title="���C�ɔ�">';

    for ($no = 0; $no <= $_conf['expack.misc.favset_num']; $no++) {
        if (isset($favita[$no]) && strlen($favita[$no]) > 0) {
            $name = $favita[$no];
        } else {
            $favita[$no] = $name = ($no ? "���C�ɔ�{$no}" : '���C�ɔ�');
        }
        echo "<li><a href=\"#favita{$no}\">{$name}</a></li>";
    }

    echo "</ul>\n";

    $orig_favita_brd = $_conf['favita_brd'];

    foreach ($favita as $no => $name) {
        $_conf['favita_brd'] = $_conf['pref_dir'] . DIRECTORY_SEPARATOR
            . ($no ? "p2_favita{$no}.brd" : 'p2_favita.brd');
        menu_iphone_show_favorite_boards($name, $no);
    }

    $_conf['favita_brd'] = $orig_favita_brd;

    // }}}
    // {{{ RSS

    if ($_conf['expack.rss.enabled']) {
        $rss = FavSetManager::getFavSetTitles('m_rss_set');
        if (!$rss) {
            $rss = array();
        }

        echo '<ul id="rss" title="RSS">';

        for ($no = 0; $no <= $_conf['expack.misc.favset_num']; $no++) {
            if (isset($rss[$no]) && strlen($rss[$no]) > 0) {
                $name = $rss[$no];
            } else {
                $rss[$no] = $name = ($no ? "RSS{$no}" : 'RSS');
            }
            echo "<li><a href=\"#rss{$no}\">{$name}</a></li>";
        }

        echo "</ul>\n";

        $orig_rss_setting_path = $_conf['expack.rss.setting_path'];

        foreach ($rss as $no => $name) {
            $_conf['expack.rss.setting_path'] = $_conf['pref_dir'] . DIRECTORY_SEPARATOR
                    . ($no ? "p2_rss{$no}.txt" : 'p2_rss.txt');
            menu_iphone_show_feed_list($name, $no);
        }

        $_conf['expack.rss.setting_pat'] = $orig_rss_setting_path;
    }

    // }}}
} else {
    menu_iphone_show_favorite_boards('���C�ɔ�');

    if ($_conf['expack.rss.enabled']) {
        menu_iphone_show_feed_list('RSS');
    }
}

// }}}
// {{{ ���O�C�����
?>

<div id="login_info" class="panel" title="���O�C�����">
<h2>�F�؃��[�U</h2>
<p><strong><?php echo $_login->user_u; ?></strong> - <?php echo date('Y/m/d (D) G:i:s'); ?></p>
<?php if ($_conf['login_log_rec'] && $_conf['last_login_log_show']) { ?>
<h2>�O��̃��O�C��</h2>
<pre style="word-wrap:break-word;word-break:break-all"><?php
if (($log = P2Util::getLastAccessLog($_conf['login_log_file'])) !== false) {
    $log_hd = array_map('p2h', $log);
    echo <<<EOP
<strong>DATE:</strong> {$log_hd['date']}
<strong>USER:</strong> {$log_hd['user']}
<strong>  IP:</strong> {$log_hd['ip']}
<strong>HOST:</strong> {$log_hd['host']}
<strong>  UA:</strong> {$log_hd['ua']}
<strong>REFERER:</strong> {$log_hd['referer']}
EOP;
}
?></pre>
<?php } ?>
<?php
if ($_conf['donguri_use']) {
    require_once P2_LIB_DIR . '/donguri.inc.php';
    $donguri = Donguri::get_status_text();
    echo <<<EOP
<h2>�ǂ񂮂�</h2>
    <p><span id="donguri_content">{$donguri}</span></p>
EOP;
    Donguri::check_status();
}
?>
</div>

<ul id="rep2_info" title="rep2���">
    <li class="group">�����N</li>
    <li><a href="<?php echo $fukumen_url_r; ?>"<?php echo $_conf['ext_win_target_at']; ?>><?php echo $fukumen_url; ?></a></li>
    <li><a href="viewmd.php?file=README.md" target="_blank">README.md</a></li>
    <li><a href="viewcommit.php?hash=<?php echo $current_rep2_hash_en; ?>" target="_blank">�ŐV�̃R�~�b�g���m�F����</a></li>
<?php echo $htm['ver_str']; ?>
</ul>

<?php
// }}}
// {{{ �X���b�h����
?>

<ul id="tgrep" title="�X���b�h����">
    <li><a href="#tgrep_info">�X���b�h�����ɂ���</a></li>
    <li class="group">�N�C�b�N�T�[�`</li>
    <?php require_once P2EX_LIB_DIR . '/tgrep/menu_quick.inc.php'; ?>
    <li class="group">��������</li>
    <?php require_once P2EX_LIB_DIR . '/tgrep/menu_recent.inc.php'; ?>
</ul>

<?php
// }}}
// {{{ �X���b�h�����ɂ���
?>

<div id="tgrep_info" class="panel" title="tGrep�ɂ���">
<ul>
    <li>iPhone�ł̓��j���[�E��́u�ځv�{�^�����^�b�v���Č����_�C�A���O���猟�����܂��B</li>
    <li>�L�[���[�h�̓X�y�[�X��؂��3�܂Ŏw��ł��A���ׂĂ��܂ނ��̂����o����܂��B</li>
    <li>2�ڈȍ~�̃L�[���[�h�œ��� - (���p�}�C�i�X) ������ƁA������܂܂Ȃ����̂����o����܂��B</li>
    <li>&quot; �܂��� &#39; �ň͂܂ꂽ�����͈�̃L�[���[�h�Ƃ��Ĉ����܂��B</li>
    <li>�L�[���[�h�̑S�p���p�A�啶���������͖�������܂��B</li>
    <li>�f�[�^�x�[�X�̍X�V��3���Ԃ�1��ŁA���X���Ȃǂ͍X�V���_�ł̒l�ł��B</li>
</ul>
</div>

<?php
// }}}
// {{{ �����_�C�A���O
?>

<form id="boardSearch" class="dialog"
  method="post" action="menu_i.php"
  accept-charset="<?php echo $_conf['accept_charset']; ?>">
<fieldset>
    <h1>����</h1>
    <a class="button leftButton" type="cancel">���</a>
    <a class="button blueButton" type="submit">����</a>
    <label>word:</label>
    <input type="text" name="word" autocorrect="off" autocapitalize="off" />
</fieldset>
</form>

<?php
// }}}
// {{{ �X���b�h�����_�C�A���O
?>

<form id="threadSearch" class="dialog"
  method="post" action="tgrepc.php"
  accept-charset="<?php echo $_conf['accept_charset']; ?>">
<fieldset>
    <h1>�X���b�h����</h1>
    <a class="button leftButton" type="cancel">���</a>
    <a class="button blueButton" type="submit">����</a>
    <label>word:</label>
    <input type="text" name="iq" autocorrect="off" autocapitalize="off" /><br>
    <select name="AndOr">
    <option value="0" selected>AND����</option>
    <option value="1" >OR����</option>
    </select><br>
    �ő�<select name="maxResult">
    <option value="10" >10</option>
    <option value="20" selected>20</option>
    <option value="30" >30</option>
    </select>���\��<br>
    <select name="Sort">
    <option value="0" >�l�C��</option>
    <option value="1" >������</option>
    <option value="2" >���X����</option>
    <option value="4" >�ŐV�X����</option>
    <option value="3" >�ŌÃX����</option>
    <option value="5" selected>�ŐV���e��</option>
    </select>
    924��<select name="924">
    <option value="1" selected>�o��</option>
    <option value="0" >����</option>
    </select>
</fieldset>
</form>

<?php
// }}}
?>

</body>
</html>
<?php
// }}}

/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
