<?php

/**
 * rep2 - �F�؂̌��� (verify)
 *
 * INTENT �~ PASS ���n�̃}�g���N�X (�� = ��ɐݒ�A�� = �����t���Őݒ�A�[ = �ݒ肳��Ȃ�)
 * | effect                    | FORM PASS | FORM_NEW PASS | PASSKEY PASS | STATE PASS�@ | STATE PASS�A | STATE PASS�B | STATE PASS�C | STATE PASS�D |
 * | ------------------------- | --------- | ------------- | ------------ | ------------ | ------------ | ------------ | ------------ | ------------ |
 * | reflect_login             | ��        | �[            | ��           | ��           | ��           | ��           | ��           | ��           |
 * | make_user                 | �[        | ��            | �[           | �[           | �[           | �[           | �[           | �[           |
 * | clear_strengthened        | �[        | �[            | �[           | �[           | ��           | �[           | �[           | �[           |
 * | unsession                 | �[        | �[            | �[           | �[           | �[           | �[           | �[           | ��           |
 * | clear_cookie              | �[        | �[            | �[           | �[           | �[           | �� (��1)     | �[           | ��           |
 * | log_success               | ��        | ��            | ��           | �[           | �[           | �[           | �[           | �[           |
 * | begin_session             | �� (��2)  | �� (��2)      | ��           | �[           | �[           | �[           | �[           | �[           |
 * | update_actime             | �[        | �[            | �[           | �[           | �[           | ��           | ��           | �[           |
 * | update_session_vars       | ��        | ��            | �[           | ��           | ��           | ��           | �[           | �[           |
 * | update_session_passkey    | �[        | �[            | ��           | �[           | �[           | �[           | ��           | �[           |
 * | record_login_microtime    | ��        | ��            | ��           | ��           | �[           | �[           | �[           | �[           |
 * | record_device_pixel_ratio | �� (��3)  | �� (��3)      | �� (��3)     | �� (��4)     | �� (��4)     | �[           | �[           | �[           |
 * | register_cookie           | �� (��5)  | �� (��5)      | �[           | �[           | �[           | �[           | �[           | �[           |
 * | close_session             | �� (��6)  | �� (��6)      | �� (��6)     | �� (��6)     | �� (��6)     | �� (��6)     | �� (��6)     | �[           |
 * | logout_redirect           | �[        | �[            | �[           | �[           | �[           | �[           | �[           | ��           |
 * | redirect                  | �� (��7)  | �[            | �� (��7)     | �[           | �[           | �[           | �[           | �[           |
 * | show_regist_done          | �[        | ��            | �[           | �[           | �[           | �[           | �[           | �[           |
 * | log_failed                | �[        | �[            | �[           | �[           | �[           | �[           | �[           | �[           |
 *
 * STATE PASS�@ CID�F��OK/�ʏ�Z�b�V�����F��NG
 * STATE PASS�A CID�F��OK/�ʏ�Z�b�V�����F��OK
 * STATE PASS�B �����Z�b�V�����F��OK
 * STATE PASS�C �p�X�L�[�Z�b�V�����F��OK
 * STATE PASS�D logout��
 * ��1 CID�L��&&�F��NG��
 * ��2 �N�b�L�[�F�ؖ�����
 * ��3 REQUEST dpr �L�莞
 * ��4 CID dpr�L�莞
 * ��5 �N�b�L�[�F�ؗL�莞
 * ��6 P2_SESSION_CLOSE_AFTER_AUTHENTICATION��`��
 * ��7 REQUEST_URI �L�莞
 */

// {{{ LoginProof

class LoginProof
{
    // {{{ checkGate()

    /**
     * ���ʃQ�[�g�𔻒肷��
     *
     * @param LoginCtx $ctx
     * @return LoginResult|null ���s�Ȃ� FAIL�A�ʉ߂Ȃ� null
     */
    static public function checkGate(LoginCtx $ctx)
    {
        if ($ctx->intent === LoginCtx::INTENT_FORM_NEW) {
            return null;
        }

        if ($ctx->intent === LoginCtx::INTENT_PASSKEY) {
            if ($ctx->recUser === null) {
                return LoginResult::fail(LoginResult::R_IDENTITY_MISMATCH);
            }
            return null;
        }

        if ($ctx->identity === null) {
            return LoginResult::fail(LoginResult::R_NO_IDENTITY);
        }

        if ($ctx->authFileExists && $ctx->identity != $ctx->recUser) {
            $r = LoginResult::fail(LoginResult::R_IDENTITY_MISMATCH);
            $r->effects[] = LoginResult::E_LOG_FAILED;
            return $r;
        }

        if (!$ctx->passX) {
            return LoginResult::fail(LoginResult::R_NO_PASSWORD);
        }

        return null;
    }

    // }}}
    // {{{ verifyForm()

    /**
     * form �o�H�𔻒肷��
     *
     * @param LoginCtx $base
     * @param LoginFormCtx $ctx
     * @return LoginResult
     */
    static public function verifyForm(LoginCtx $base, LoginFormCtx $ctx)
    {
        if ($ctx->lockout) {
            return LoginResult::fail(LoginResult::R_LOCKOUT);
        }

        if (!$ctx->formVerified) {
            $r = LoginResult::fail(LoginResult::R_FORM_REJECTED);
            $r->effects[] = LoginResult::E_LOG_FAILED;
            return $r;
        }

        $r = LoginResult::pass($base->identity, $base->passX, $ctx->devicePixelRatio, $ctx->requestUri);
        $r->effects[] = LoginResult::E_REFLECT_LOGIN;
        $r->effects[] = LoginResult::E_LOG_SUCCESS;
        if (!$ctx->registerCid) {
            $r->effects[] = LoginResult::E_BEGIN_SESSION;
        }
        $r->effects[] = LoginResult::E_UPDATE_SESSION_VARS;
        $r->effects[] = LoginResult::E_RECORD_LOGIN_MICROTIME;
        if ($ctx->devicePixelRatio !== null) {
            $r->effects[] = LoginResult::E_RECORD_DEVICE_PIXEL_RATIO;
        }
        if ($ctx->registerCid) {
            $r->effects[] = LoginResult::E_REGISTER_COOKIE;
        }
        if (P2_SESSION_CLOSE_AFTER_AUTHENTICATION) {
            $r->effects[] = LoginResult::E_CLOSE_SESSION;
        }
        if ($ctx->requestUri !== null) {
            $r->effects[] = LoginResult::E_REDIRECT;
        }
        return $r;
    }

    // }}}
    // {{{ verifyFormNew()

    /**
     * �V�K�o�^�o�H�𔻒肷��
     *
     * @param LoginCtx $base
     * @param LoginRegistCtx $ctx
     * @return LoginResult
     */
    static public function verifyFormNew(LoginCtx $base, LoginRegistCtx $ctx)
    {
        // passX ������Ƃ��͐V�K�o�^�ł��Ȃ� (submit_new �{�^���� auth_user_file �����ݎ��̂ݕ\��)
        if ($base->passX !== null) {
            return LoginResult::fail(LoginResult::R_NO_PROOF);
        }

        // form_login_id / form_login_pass �̗��L�[�� POST �ɂȂ��Ƃ���
        // ���b�Z�[�W�Ȃ��Ń��O�C����ʂ�\������ (�ʏ�̃t�H�[���͋�l�ł����M���邽�ߒʏ�͓��B���Ȃ�)
        if ($ctx->formLoginId === null && $ctx->formLoginPass === null) {
            return LoginResult::fail(LoginResult::R_NO_PROOF);
        }

        if (!$ctx->formLoginId || !$ctx->formLoginPass) {
            return LoginResult::fail(LoginResult::R_NEW_REGIST_INPUT_ERROR);
        }

        if (!preg_match('/^[0-9A-Za-z_]+$/', $ctx->formLoginId) || !preg_match('/^[\\x21-\\x7E]+$/', $ctx->formLoginPass)) {
            return LoginResult::fail(LoginResult::R_NEW_REGIST_PATTERN_ERROR);
        }

        $r = LoginResult::passRegist($ctx->formLoginId, $ctx->formLoginPass, $ctx->devicePixelRatio);
        $r->effects[] = LoginResult::E_MAKE_USER;
        $r->effects[] = LoginResult::E_LOG_SUCCESS;
        if (!$ctx->registerCid) {
            $r->effects[] = LoginResult::E_BEGIN_SESSION;
        }
        $r->effects[] = LoginResult::E_UPDATE_SESSION_VARS;
        $r->effects[] = LoginResult::E_RECORD_LOGIN_MICROTIME;
        if ($ctx->devicePixelRatio !== null) {
            $r->effects[] = LoginResult::E_RECORD_DEVICE_PIXEL_RATIO;
        }
        if ($ctx->registerCid) {
            $r->effects[] = LoginResult::E_REGISTER_COOKIE;
        }
        if (P2_SESSION_CLOSE_AFTER_AUTHENTICATION) {
            $r->effects[] = LoginResult::E_CLOSE_SESSION;
        }
        $r->effects[] = LoginResult::E_SHOW_REGIST_DONE;
        return $r;
    }

    // }}}
    // {{{ verifyPasskey()

    /**
     * passkey �o�H�𔻒肷��
     *
     * @param LoginCtx $base
     * @param LoginPasskeyCtx $ctx
     * @return LoginResult
     */
    static public function verifyPasskey(LoginCtx $base, LoginPasskeyCtx $ctx)
    {
        if ($ctx->lockout) {
            return LoginResult::fail(LoginResult::R_LOCKOUT);
        }

        if (!$ctx->passkeyVerified) {
            $r = LoginResult::fail(LoginResult::R_PASSKEY_REJECTED, $ctx->failMessage);
            $r->effects[] = LoginResult::E_LOG_FAILED;
            return $r;
        }

        $r = LoginResult::pass($base->recUser, null, $ctx->devicePixelRatio, $ctx->requestUri);
        $r->effects[] = LoginResult::E_REFLECT_LOGIN;
        $r->effects[] = LoginResult::E_LOG_SUCCESS;
        $r->effects[] = LoginResult::E_BEGIN_SESSION;
        $r->effects[] = LoginResult::E_UPDATE_SESSION_PASSKEY;
        $r->effects[] = LoginResult::E_RECORD_LOGIN_MICROTIME;
        if ($ctx->devicePixelRatio !== null) {
            $r->effects[] = LoginResult::E_RECORD_DEVICE_PIXEL_RATIO;
        }
        if (P2_SESSION_CLOSE_AFTER_AUTHENTICATION) {
            $r->effects[] = LoginResult::E_CLOSE_SESSION;
        }
        if ($ctx->requestUri !== null) {
            $r->effects[] = LoginResult::E_REDIRECT;
        }
        return $r;
    }

    // }}}
    // {{{ verifyState()

    /**
     * state �o�H�𔻒肷��
     *
     * @param LoginCtx $base
     * @param LoginStateCtx $ctx
     * @return LoginResult
     */
    static public function verifyState(LoginCtx $base, LoginStateCtx $ctx)
    {
        if ($base->cidCookiePresent) {
            if ($ctx->cidVerified) {
                if ($ctx->logout) {
                    $r = LoginResult::pass($base->identity, $base->passX);
                    $r->effects[] = LoginResult::E_REFLECT_LOGIN;
                    $r->effects[] = LoginResult::E_UNSESSION;
                    $r->effects[] = LoginResult::E_CLEAR_COOKIE;
                    $r->effects[] = LoginResult::E_LOGOUT_REDIRECT;
                    return $r;
                }
                $r = LoginResult::pass($base->identity, $base->passX, $ctx->devicePixelRatio);
                $r->effects[] = LoginResult::E_REFLECT_LOGIN;
                if ($ctx->sessionUser !== null) {
                    $r->effects[] = LoginResult::E_CLEAR_STRENGTHENED;
                }
                $r->effects[] = LoginResult::E_UPDATE_SESSION_VARS;
                if ($ctx->sessionUser === null) {
                    $r->effects[] = LoginResult::E_RECORD_LOGIN_MICROTIME;
                }
                if ($ctx->devicePixelRatio !== null) {
                    $r->effects[] = LoginResult::E_RECORD_DEVICE_PIXEL_RATIO;
                }
                if (P2_SESSION_CLOSE_AFTER_AUTHENTICATION) {
                    $r->effects[] = LoginResult::E_CLOSE_SESSION;
                }
                return $r;
            }
        }

        if ($ctx->sessionChecked) {
            if ($ctx->sessionError !== false) {
                $extra = $base->cidExpired
                    ? '�N�b�L�[�F�؂̗L���������؂�܂����B�ēx���O�C�����Ă��������B'
                    : $ctx->sessionError;
                $r = LoginResult::fail(LoginResult::R_SESSION_ERROR, $extra);
                $r->effects[] = LoginResult::E_CLEAR_COOKIE;
                return $r;
            }

            if ($ctx->passkeyAuth) {
                if ($ctx->logout) {
                    $r = LoginResult::pass($base->identity, null);
                    $r->effects[] = LoginResult::E_REFLECT_LOGIN;
                    $r->effects[] = LoginResult::E_UNSESSION;
                    $r->effects[] = LoginResult::E_CLEAR_COOKIE;
                    $r->effects[] = LoginResult::E_LOGOUT_REDIRECT;
                    return $r;
                }
                $r = LoginResult::pass($base->identity, null);
                $r->effects[] = LoginResult::E_REFLECT_LOGIN;
                $r->effects[] = LoginResult::E_UPDATE_ACTIME;
                $r->effects[] = LoginResult::E_UPDATE_SESSION_PASSKEY;
                if (P2_SESSION_CLOSE_AFTER_AUTHENTICATION) {
                    $r->effects[] = LoginResult::E_CLOSE_SESSION;
                }
                return $r;
            }

            if ($ctx->sessionVerified) {
                if ($ctx->logout) {
                    $r = LoginResult::pass($base->identity, $base->passX);
                    $r->effects[] = LoginResult::E_REFLECT_LOGIN;
                    $r->effects[] = LoginResult::E_UNSESSION;
                    $r->effects[] = LoginResult::E_CLEAR_COOKIE;
                    $r->effects[] = LoginResult::E_LOGOUT_REDIRECT;
                    return $r;
                }
                $r = LoginResult::pass($base->identity, $base->passX);
                $r->effects[] = LoginResult::E_REFLECT_LOGIN;
                $r->effects[] = LoginResult::E_UPDATE_ACTIME;
                $r->effects[] = LoginResult::E_UPDATE_SESSION_VARS;
                if (P2_SESSION_CLOSE_AFTER_AUTHENTICATION) {
                    $r->effects[] = LoginResult::E_CLOSE_SESSION;
                }
                return $r;
            }

            // �Z�b�V�����̏�񂪌Â����ߔj������
            $r = LoginResult::fail(LoginResult::R_NO_PROOF);
            $r->effects[] = LoginResult::E_CLEAR_COOKIE;
            return $r;
        }

        $r = LoginResult::fail(LoginResult::R_NO_PROOF);
        $r->effects[] = LoginResult::E_CLEAR_COOKIE;
        return $r;
    }

    // }}}
    // {{{ verifyNone()

    /**
     * none �o�H�𔻒肷��
     *
     * @param LoginCtx $ctx
     * @return LoginResult
     */
    static public function verifyNone(LoginCtx $ctx)
    {
        return LoginResult::fail(LoginResult::R_NO_PROOF);
    }

    // }}}
    // }}}
}

// }}}

/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
