<?php
/**
 * rep2 - �X���b�h��\������ �N���X PC�p
 */

require_once P2EX_LIB_DIR . '/ExpackLoader.php';

ExpackLoader::loadAAS();
ExpackLoader::loadActiveMona();
ExpackLoader::loadImageCache();

// {{{ ShowThreadPc

class ShowThreadPc extends ShowThread
{
	var $BBS_NONAME_NAME = ''; // +live (live.bbs_noname) �p

    // {{{ properties

    static private $_spm_objects = array();

    public $am_autodetect = false; // AA������������邩�ۂ�
    public $am_side_of_id = false; // AA�X�C�b�`��ID�̉��ɕ\������
    public $am_on_spm = false; // AA�X�C�b�`��SPM�ɕ\������

    public $asyncObjName;  // �񓯊��ǂݍ��ݗpJavaScript�I�u�W�F�N�g��
    public $spmObjName; // �X�}�[�g�|�b�v�A�b�v���j���[�pJavaScript�I�u�W�F�N�g��

    // }}}
    // {{{ constructor

    /**
     * �R���X�g���N�^
     */
    public function __construct($aThread, $matome = false)
    {
        parent::__construct($aThread, $matome);

        global $_conf;

        $this->_url_handlers = array(
            'plugin_linkThread',
            'plugin_link2chSubject',
        );

		// +live (live.bbs_noname) �p
		if (array_key_exists('live', $_GET) && $_GET['live']) {
			if (empty($_conf['live.bbs_noname'])) {
				require_once P2_LIB_DIR . '/SettingTxt.php';
				$st = new SettingTxt($this->thread->host, $this->thread->bbs);
				$st->setSettingArray();
				if (!empty($st->setting_array['BBS_NONAME_NAME'])) {
					$this->BBS_NONAME_NAME = $st->setting_array['BBS_NONAME_NAME'];
				}
			}

		}

        // +Wiki
        if (isset($GLOBALS['linkPluginCtl'])) {
            $this->_url_handlers[] = 'plugin_linkPlugin';
        }
        if (isset($GLOBALS['replaceImageUrlCtl'])) {
            $this->_url_handlers[] = 'plugin_replaceImageUrl';
        } elseif ($_conf['preview_thumbnail']) {
            $this->_url_handlers[] = 'plugin_viewImage';
        }
        $this->_url_handlers[] = 'plugin_linkURL';

        // �T���l�C���\����������ݒ�
        if (!isset($GLOBALS['pre_thumb_unlimited']) || !isset($GLOBALS['pre_thumb_limit'])) {
            if (isset($_conf['pre_thumb_limit']) && $_conf['pre_thumb_limit'] > 0) {
                $GLOBALS['pre_thumb_limit'] = $_conf['pre_thumb_limit'];
                $GLOBALS['pre_thumb_unlimited'] = false;
            } else {
                $GLOBALS['pre_thumb_limit'] = null; // �k���l����isset()��false��Ԃ�
                $GLOBALS['pre_thumb_unlimited'] = true;
            }
        }
        $GLOBALS['pre_thumb_ignore_limit'] = false;

        // �A�N�e�B�u���i�[������
        if (P2_ACTIVEMONA_AVAILABLE) {
            ExpackLoader::initActiveMona($this);
        }

        // ImageCache2������
        if (P2_IMAGECACHE_AVAILABLE == 2) {
            ExpackLoader::initImageCache($this);
        }

        // �񓯊����X�|�b�v�A�b�v�ESPM������
        $js_id = sprintf('%u', crc32($this->thread->keydat));
        if ($this->_matome) {
            $this->asyncObjName = "t{$this->_matome}asp{$js_id}";
            $this->spmObjName = "t{$this->_matome}spm{$js_id}";
        } else {
            $this->asyncObjName = "asp{$js_id}";
            $this->spmObjName = "spm{$js_id}";
        }

        // ������������
        $this->setBbsNonameName();
    }

    // }}}
    // {{{ transRes()

    /**
     * Dat���X��HTML���X�ɕϊ�����
     *
     * @param   string  $ares       dat��1���C��
     * @param   int     $i          ���X�ԍ�
     * @param   string  $pattern    �n�C���C�g�p���K�\��
     * @return  string
     */
    public function transRes($ares, $i, $pattern = null)
    {
        global $_conf, $STYLE, $mae_msg, $highlight_msgs, $highlight_chain_nums;

        // +Wiki:�u�����[�h
        if (isset($GLOBALS['replaceWordCtl'])) {
            $replaceWordCtl = $GLOBALS['replaceWordCtl'];
            $name    = $replaceWordCtl->replace('name', $this->thread, $ares, $i);
            $mail    = $replaceWordCtl->replace('mail', $this->thread, $ares, $i);
            $date_id = $replaceWordCtl->replace('date', $this->thread, $ares, $i);
            $msg     = $replaceWordCtl->replace('msg',  $this->thread, $ares, $i);
        } else {
            list($name, $mail, $date_id, $msg) = $this->thread->explodeDatLine($ares);
        }

        // �ǂ񂮂��C�p�̓��t�𒊏o
        $raw_date = null;
        if ($_conf['donguri_use'] && preg_match('/^\d{4}\/\d{2}\/\d{2}\(.+?\) \d{2}:\d{2}:\d{2}(\.\d+)?/', $date_id, $m)) {
            $raw_date = StrCtl::toJavaScript($m[0]);
        }

        if (($id = $this->thread->ids[$i]) !== null) {
            if (str_starts_with($this->thread->idp[$i], 'ID:')) {
                $idstr = 'ID:' . $id;
            } else {
                $idstr = '���M��:' . $id;
            }
            $date_id = str_replace($this->thread->idp[$i] . $id, $idstr, $date_id);
        } else {
            $idstr = null;
        }

		// +live (live.bbs_noname) �p
		if (!empty($this->BBS_NONAME_NAME) and $this->BBS_NONAME_NAME == $name) {
			$name = '';
		}

        $tores = '';
        $rpop = '';
        if ($this->_matome) {
            $res_id = "t{$this->_matome}r{$i}";
            $msg_id = "t{$this->_matome}m{$i}";
        } else {
            $res_id = "r{$i}";
            $msg_id = "m{$i}";
        }
        $msg_class = 'message';

        // NG���ځ[��`�F�b�N
        $ng_type = $this->_ngAbornCheck($i, strip_tags($name), $mail, $date_id, $id, $msg, false, $ng_info);
        if ($ng_type == self::ABORN) {
            return $this->_abornedRes($res_id);
        }
        if ($ng_type != self::NG_NONE) {
            $ngaborns_head_hits = self::$_ngaborns_head_hits;
        }

        // AA����
        if ($this->am_autodetect && $this->activeMona->detectAA($msg)) {
            $msg_class .= ' ActiveMona';
        }

        //=============================================================
        // ���X���|�b�v�A�b�v�\��
        //=============================================================
        if ($_conf['quote_res_view']) {
            $quote_res_nums = $this->checkQuoteResNums($i, $name, $msg);

            foreach ($quote_res_nums as $rnv) {
                if (!isset($this->_quote_res_nums_done[$rnv])) {
                    $this->_quote_res_nums_done[$rnv] = true;
                    if (isset($this->thread->datlines[$rnv-1])) {
                        if ($this->_matome) {
                            $qres_id = "t{$this->_matome}qr{$rnv}";
                        } else {
                            $qres_id = "qr{$rnv}";
                        }
                        $ds = $this->qRes($this->thread->datlines[$rnv-1], $rnv);
                        $onPopUp_at = " onmouseover=\"showResPopUp('{$qres_id}',event)\" onmouseout=\"hideResPopUp('{$qres_id}')\"";
                        $rpop .= "<div id=\"{$qres_id}\" class=\"respopup\"{$onPopUp_at}>\n{$ds}</div>\n";
                    }
                }
            }
        }

        //=============================================================
        // �܂Ƃ߂ďo��
        //=============================================================

        $name = $this->transName($name); // ���OHTML�ϊ�
        $msg = $this->transMsg($msg, $i); // ���b�Z�[�WHTML�ϊ�


        // BE�v���t�@�C�������N�ϊ�
        $date_id = $this->replaceBeId($date_id, $i);
        $date_id = $this->replaceTid($date_id);

        // BE���G�����A�C�R�������N�ϊ�
        $msg = $this->replaceSsspIcon($msg);

        // HTML�|�b�v�A�b�v
        if ($_conf['iframe_popup']) {
            $date_id = preg_replace_callback("{<a href=\"(http://[-_.!~*()0-9A-Za-z;/?:@&=+\$,%#]+)\"({$_conf['ext_win_target_at']})>((\?#*)|(Lv\.\d+))</a>}", array($this, 'iframePopupCallback'), $date_id);
        }

        $ng_badges = array();
        // NG���b�Z�[�W�ϊ�
        if ($ng_type != self::NG_NONE && count($ng_info)) {
            $ng_info = implode(', ', $ng_info);
            $msg = <<<EOMSG
<span class="ngword">{$ng_info}</span>
<div id="ngn{$ngaborns_head_hits}" class="ngmsg ngmsg-by-msg">{$msg}</div>
EOMSG;
            $ng_badges[] = '�{��';
        }

        // NG�l�[���ϊ�
        if ($ng_type & self::NG_NAME) {
	        $name = preg_replace("(<b>|</b>)", "", $name);
            $name = <<<EONAME
</b><span class="ngword">{$name}</span><b>
EONAME;
            $ng_badges[] = '���O';
        } elseif ($ng_type & self::NG_WATCHOI) {
            if ($_conf['ngaborn_watchoi4']) {
                $pattern = '#\(([^\s()]+\s+)?([0-9A-Za-z./*+]{4}-)([0-9A-Za-z./*+]{4}(?:\s+\[.+])?)\)#';
                $name = preg_replace($pattern, "($1<span class=\"ngword\">$2</span>$3)", $name);
            } else {
                $pattern = '#\(((?:[^\s()]+\s+)?(?:[0-9A-Za-z./*+]{4}-[0-9A-Za-z./*+]{4})(?:\s+\[.+])?)\)#';
                $name = preg_replace($pattern, "(<span class=\"ngword\">$1</span>)", $name);
            }
            $ng_badges[] = '���b�`���C';
        }

        // NG���[���ϊ�
        if ($ng_type & self::NG_MAIL) {
            $mail = <<<EOMAIL
<span class="ngword">{$mail}</span>
EOMAIL;
            $ng_badges[] ='���[��';
        }

        // NGID�ϊ�
        if ($ng_type & self::NG_ID) {
            $date_id = <<<EOID
<span class="ngword">{$date_id}</span>
EOID;
            $ng_badges[] = 'ID';
        }

        // NG���b�Z�[�W�ϊ�(msg)
        if ($ng_type != self::NG_NONE && !empty($ng_info)) {
            // �ϊ��ς�

        // NG�l�[���ϊ�(msg)
        } elseif ($ng_type & (self::NG_NAME | self::NG_WATCHOI)) {
            $msg = <<<EOMSG
<div id="ngn{$ngaborns_head_hits}" class="ngmsg ngmsg-by-name">{$msg}</div>
EOMSG;

        // NG���[���ϊ�(msg)
        } elseif ($ng_type & self::NG_MAIL) {
            $msg = <<<EOMSG
<div id="ngn{$ngaborns_head_hits}" class="ngmsg ngmsg-by-mail">{$msg}</div>
EOMSG;

        // NGID�ϊ�(msg)
        } elseif ($ng_type & self::NG_ID) {
            $msg = <<<EOMSG
<div id="ngn{$ngaborns_head_hits}" class="ngmsg ngmsg-by-id">{$msg}</div>
EOMSG;

        }

         // NG�J�o�b�W
       $ng_badge_html = '';
        if (!empty($ng_badges)) {
            $reason = implode(', ', $ng_badges);
            $ng_badge_html = <<<EOBADGE
 <span style="cursor:pointer; margin-left:0.5em;" onclick="show_ng_message('ngn{$ngaborns_head_hits}');">[NG: {$reason}]</span>
EOBADGE;
        }

		// +live �n�C���C�g���[�h�ϊ�
		include P2_LIB_DIR . '/live/live_highlight_convert.php';

        /*
        //�u��������V���v�摜��}��
        if ($i == $this->thread->readnum +1) {
            $tores .= <<<EOP
                <div><img src="img/image.png" alt="�V�����X" border="0" vspace="4"></div>
EOP;
        }
        */

        // SPM
        if ($_conf['expack.spm.enabled']) {
            $js_date = $raw_date ? "'$raw_date'" : 'null';
            $has_watchoi = isset($this->thread->watchois[$i]) ? 'true' : 'false';
            $spmeh = " onmouseover=\"{$this->spmObjName}.show({$i},'{$msg_id}',event,{$js_date},{$has_watchoi})\"";
            $spmeh .= " onmouseout=\"{$this->spmObjName}.hide(event)\"";
        } else {
            $spmeh = '';
        }

		// +live �X���b�h���e�\���ؑ�
		include P2_LIB_DIR . '/live/live_view_ctl.inc.php';

        /*if ($_conf['expack.am.enabled'] == 2) {
            $tores .= <<<EOJS
<script type="text/javascript">
//<![CDATA[
detectAA("{$msg_id}");
//]]>
</script>\n
EOJS;
        }*/

        // �܂Ƃ߂ăt�B���^�F����
        if ($pattern) {
            $tores = StrCtl::filterMarking($pattern, $tores);
        }

        return array('body' => $tores, 'q' => $rpop);
    }

    // }}}
    // {{{ quoteOne()

    /**
     * >>1 ��\������ (���p�|�b�v�A�b�v�p)
     */
    public function quoteOne()
    {
        global $_conf;

        if (!$_conf['quote_res_view']) {
            return array('body' => '', 'q' => '');
        }

        $rpop = '';
        $quote_res_nums = $this->checkQuoteResNums(0, '1', '');
        if (array_search(1, $quote_res_nums) === false) {
            $quote_res_nums[] = 1;
        }

        foreach ($quote_res_nums as $rnv) {
            if (!isset($this->_quote_res_nums_done[$rnv])) {
                $this->_quote_res_nums_done[$rnv] = true;
                if (isset($this->thread->datlines[$rnv-1])) {
                    if ($this->_matome) {
                        $qres_id = "t{$this->_matome}qr{$rnv}";
                    } else {
                        $qres_id = "qr{$rnv}";
                    }
                    $ds = $this->qRes($this->thread->datlines[$rnv-1], $rnv);
                    $onPopUp_at = " onmouseover=\"showResPopUp('{$qres_id}',event)\" onmouseout=\"hideResPopUp('{$qres_id}')\"";
                    $rpop .= "<div id=\"{$qres_id}\" class=\"respopup\"{$onPopUp_at}>\n{$ds}</div>\n";
                }
            }
        }

        $res1['q'] = $rpop;
        $res1['body'] = $this->transMsg('&gt;&gt;1', 1);

        return $res1;
    }

    // }}}
    // {{{ qRes()

    /**
     * ���X���pHTML
     */
    public function qRes($ares, $i)
    {
        global $_conf;

        // +Wiki:�u�����[�h
        if (isset($GLOBALS['replaceWordCtl'])) {
            $replaceWordCtl = $GLOBALS['replaceWordCtl'];
            $name    = $replaceWordCtl->replace('name', $this->thread, $ares, $i);
            $mail    = $replaceWordCtl->replace('mail', $this->thread, $ares, $i);
            $date_id = $replaceWordCtl->replace('date', $this->thread, $ares, $i);
            $msg     = $replaceWordCtl->replace('msg',  $this->thread, $ares, $i);
        } else {
            list($name, $mail, $date_id, $msg) = $this->thread->explodeDatLine($ares);
        }

        // �ǂ񂮂��C�p�̓��t�𒊏o
        $raw_date = null;
        if ($_conf['donguri_use'] && preg_match('/^\d{4}\/\d{2}\/\d{2}\(.+?\) \d{2}:\d{2}:\d{2}(\.\d+)?/', $date_id, $m)) {
            $raw_date = p2h($m[0]);
        }

        if (($id = $this->thread->ids[$i]) !== null) {
            if (str_starts_with($this->thread->idp[$i], 'ID:')) {
                $idstr = 'ID:' . $id;
            } else {
                $idstr = '���M��:' . $id;
            }
            $date_id = str_replace($this->thread->idp[$i] . $id, $idstr, $date_id);
        } else {
            $idstr = null;
        }

        $name = $this->transName($name); // ���OHTML�ϊ�
        $msg = $this->transMsg($msg, $i); // ���b�Z�[�WHTML�ϊ�

        $tores = '';

        if ($this->_matome) {
            $qmsg_id = "t{$this->_matome}qm{$i}";
        } else {
            $qmsg_id = "qm{$i}";
        }

        // >>1
        if ($i == 1) {
            $tores = "<h4 class=\"thread_title\">{$this->thread->ttitle_hd}</h4>";
        }

        // BE�v���t�@�C�������N�ϊ�
        $date_id = $this->replaceBeId($date_id, $i);
        $date_id = $this->replaceTid($date_id);

        // BE���G�����A�C�R�������N�ϊ�
        $msg = $this->replaceSsspIcon($msg);

        // HTML�|�b�v�A�b�v
        if ($_conf['iframe_popup']) {
            $date_id = preg_replace_callback("{<a href=\"(http://[-_.!~*()0-9A-Za-z;/?:@&=+\$,%#]+)\"({$_conf['ext_win_target_at']})>((\?#*)|(Lv\.\d+))</a>}", array($this, 'iframePopupCallback'), $date_id);
        }
        //

        // ID�t�B���^
        if ($_conf['flex_idpopup'] == 1 && $id && $this->thread->idcount[$id] > 1) {
            $date_id = str_replace($idstr, $this->idFilter($idstr, $id), $date_id);
        }

        $msg_class = 'message';

        // AA ����
        if ($this->am_autodetect && $this->activeMona->detectAA($msg)) {
            $msg_class .= ' ActiveMona';
        }

        // SPM
        if ($_conf['expack.spm.enabled']) {
            $js_date = $raw_date ? "'$raw_date'" : 'null';
            $has_watchoi = isset($this->thread->watchois[$i]) ? 'true' : 'false';
            $spmeh = " onmouseover=\"{$this->spmObjName}.show({$i},'{$qmsg_id}',event,{$js_date},{$has_watchoi})\"";
            $spmeh .= " onmouseout=\"{$this->spmObjName}.hide(event)\"";
        } else {
            $spmeh = '';
        }

        // $tores�ɂ܂Ƃ߂ďo��
        $tores .= '<div class="res-header">';
        $tores .= "<span class=\"spmSW\"{$spmeh}>{$i}</span> : "; // �ԍ�
        $tores .= preg_replace('{<b>[ ]*</b>}i', '', "<b class=\"name\">{$name}</b> : ");
        if ($mail) {
            // ���[��
			if (preg_match ("(^[\\s�@]*sage[\\s�@]*$)", $mail)) {
				$tores .= "<span class=\"sage\">$mail</span>"." �F";
			} else {
				$tores .= "<span class=\"mail\">$mail</span>"." �F";
			}
        }
        $tores .= $date_id; // ���t��ID
        if ($this->am_side_of_id) {
            $tores .= ' ' . $this->activeMona->getMona($qmsg_id);
        }
        $tores .= "</div>\n";

        // �탌�X���X�g(�c�`��)
        if ($_conf['backlink_list'] == 1 || $_conf['backlink_list'] > 2) {
            $tores .= $this->_quotebackListHtml($i, 1);
        }

        $tores .= "<div id=\"{$qmsg_id}\" class=\"{$msg_class}\">{$msg}</div>\n"; // ���e
        // �탌�X���X�g(���`��)
        if ($_conf['backlink_list'] == 2 || $_conf['backlink_list'] > 2) {
            $tores .= $this->_quotebackListHtml($i, 2);
        }

        // ��Q�ƃu���b�N�p�f�[�^
        if ($_conf['backlink_block'] > 0) {
            $tores .= $this->_getBacklinkComment($i);
        }

        return $tores;
    }

    // }}}
    // {{{ _getBacklinkComment()

    protected function _getBacklinkComment($i)
    {
        $backlinks = $this->_quotebackListHtml($i, 3);
        if (strlen($backlinks)) {
            return '<!-- backlinks:' . $backlinks . ' -->';
        }
        return '';
    }

    // }}}
    // {{{ transName()

    /**
     * ���O��HTML�p�ɕϊ�����
     *
     * @param   string  $name   ���O
     * @return  string
     */
    public function transName($name)
    {
        global $_conf;

        // ���b�`���C���t�B���^�����O�����N�ɕϊ�
        if ($_conf['flex_idpopup'] == 1 && isset($this->thread->watchoicount)) {
            $pattern_watchoi = '#.*\(((?:[^\s()]+\s+)?(?:([0-9A-Za-z./*+]{4}-)[0-9A-Za-z./*+]{4})(?:\s+\[.+])?)\)#';
            if (preg_match($pattern_watchoi, $name, $wm)) {
                $watchoi_full = substr($wm[0], strrpos($wm[0], '('));
                $name = substr_replace($name, $this->watchoiFilter($watchoi_full, $wm[1], $wm[2]), strrpos($name, $watchoi_full), strlen($watchoi_full));
            }
        }

        // �g���b�v��z�X�g�t���Ȃ番������
        if (($pos = strpos($name, '��')) !== false) {
            $trip = substr($name, $pos);
            $name = substr($name, 0, $pos);
        } else {
            $trip = null;
        }

        // ���������p���X�|�b�v�A�b�v�����N��
        if ($_conf['quote_res_view']) {
            if (strlen($name) && $name != $this->_nanashiName) {
                $name = preg_replace_callback(
                    self::getAnchorRegex('/(?:^|%prefix%)(%nums%)/'),
                    array($this, '_quoteNameCallback'), $name
                );
            }
        }

        if ($trip) {
            $name .= $trip;
        } elseif ($name) {
            // �����������
            $name = $name . ' ';
            //if (in_array(0xF0 & ord(substr($name, -1)), array(0x80, 0x90, 0xE0))) {
            //    $name .= ' ';
            //}
        }

        return $name;
    }

    // }}}
    // {{{ transMsg()

    /**
     * dat�̃��X���b�Z�[�W��HTML�\���p���b�Z�[�W�ɕϊ�����
     *
     * @param   string  $msg    ���b�Z�[�W
     * @param   int     $mynum  ���X�ԍ�
     * @return  string
     */
    public function transMsg($msg, $mynum)
    {
        global $_conf;
        global $pre_thumb_ignore_limit;

        // 2ch���`����dat
        if ($this->thread->dat_type == '2ch_old') {
            $msg = str_replace('���M', ',', $msg);
            $msg = preg_replace('/&amp(?=[^;])/', '&', $msg);
        }

		// �T���Q�[�g�y�A�̐��l�����Q�Ƃ�ϊ�
        $msg = P2Util::replaceNumericalSurrogatePair($msg);
		
        // &�␳
        $msg = preg_replace('/&(?!#?\\w+;)/', '&amp;', $msg);

        // Safari���瓊�e���ꂽ�����N���`���_�̕��������␳
        //$msg = preg_replace('{(h?t?tp://[\w\.\-]+/)�`([\w\.\-%]+/?)}', '$1~$2', $msg);

        // >>1�̃����N����������O��
        // <a href="../test/read.cgi/accuse/1001506967/1" target="_blank">&gt;&gt;1</a>
        $msg = preg_replace('{<[Aa] .+?>(&gt;&gt;\\d[\\d\\-]*)</[Aa]>}', '$1', $msg);

        // �{����2ch��DAT���_�łȂ���Ă��Ȃ��ƃG�X�P�[�v�̐����������Ȃ��C������B�iURL�����N�̃}�b�`�ŕ���p���o�Ă��܂��j
        //$msg = str_replace(array('"', "'"), array('&quot;', '&#039;'), $msg);

        // 2006/05/06 �m�[�g���̌딽���΍� body onload=window()
        $msg = str_replace('onload=window()', '<i>onload=window</i>()', $msg);

        // �V�����X�̉摜�͕\�������𖳎�����ݒ�Ȃ�
        if ($mynum > $this->thread->readnum && $_conf['expack.ic2.newres_ignore_limit']) {
            $pre_thumb_ignore_limit = true;
        }

        // �����̉��s�ƘA��������s������
        if ($_conf['strip_linebreaks']) {
            $msg = $this->stripLineBreaks($msg /*, ' <br><span class="stripped">***</span><br> '*/);
        }

        // ���p��URL�Ȃǂ������N
        $msg = $this->transLink($msg);

        // Wikipedia�L�@�ւ̎��������N
        if ($_conf['link_wikipedia']) {
            $msg = $this->_wikipediaFilter($msg);
        }

        return $msg;
    }

    // }}}
    // {{{ _abornedRes()

    /**
     * ���ځ[�񃌃X��HTML���擾����
     *
     * @param  string $res_id
     * @return string
     */
    protected function _abornedRes($res_id)
    {
        global $_conf;

        if ($_conf['ngaborn_purge_aborn']) {
            return '';
        }

        return <<<EOP
<div id="{$res_id}" class="res aborned">
<div class="res-header">&nbsp;</div>
<div class="message">&nbsp;</div>
</div>\n
EOP;
    }

    // }}}
    // {{{ idFilter()

    /**
     * ID�t�B���^�����O�|�b�v�A�b�v�ϊ�
     *
     * @param   string  $idstr  ID:xxxxxxxxxx
     * @param   string  $id        xxxxxxxxxx
     * @return  string
     */
    public function idFilter($idstr, $id)
    {
        global $_conf;

        // ID��8���܂���10��(+�g��/PC���ʎq)�Ɖ��肵��
        /*
        if (strlen($id) % 2 == 1) {
            $id = substr($id, 0, -1);
        }
        */
        $num_ht = '';
        if (isset($this->thread->idcount[$id]) && $this->thread->idcount[$id] > 0) {
            $num = (string) $this->thread->idcount[$id];
            if ($_conf['iframe_popup'] == 3) {
                $num_ht = ' <img src="img/ida.png" width="2" height="12" alt="">';
                $num_ht .= preg_replace('/\\d/', '<img src="img/id\\0.png" height="12" alt="">', $num);
                $num_ht .= '<img src="img/idz.png" width="2" height="12" alt=""> ';
            } else {
                $num_ht = '('.$num.')';
            }
        } else {
            return $idstr;
        }

        // �����W���̂����u:*�v��IPv6�`���p
        if ($_conf['coloredid.enable'] > 0
            && strlen($id) >= 4
            && preg_match("<^(?:ID:|���M��:) ?[0-9A-Za-z/.+:*]+>",$idstr)) {
            if ($_conf['coloredid.click'] > 0) {
                $num_ht = '<a href="javascript:void(0);" class="' . self::cssClassedId($idstr, $id) . '" onClick="idCol.click(\'' . $id . '\', event); return false;" onDblClick="this.onclick(event); return false;">' . $num_ht . '</a>';
            }
            $idstr = $this->_coloredIdStr(
                $idstr, $id, $_conf['coloredid.click'] > 0 ? true : false);
        }

        $filter_url = $_conf['read_php'] . '?' . http_build_query(array(
            'host' => $this->thread->host,
            'bbs'  => $this->thread->bbs,
            'key'  => $this->thread->key,
            'ls'   => 'all',
            'offline' => '1',
            'idpopup' => '1',
            'rf' => array(
                'field'   => ResFilter::FIELD_ID,
                'method'  => ResFilter::METHOD_JUST,
                'match'   => ResFilter::MATCH_ON,
                'include' => ResFilter::INCLUDE_NONE,
                'word'    => $id,
            ),
        ), '', '&amp;') . $_conf['k_at_a'];

        if ($_conf['iframe_popup']) {
            return self::iframePopup($filter_url, $idstr, $_conf['bbs_win_target_at']) . $num_ht;
        }
        return "<a href=\"{$filter_url}\"{$_conf['bbs_win_target_at']}>{$idstr}</a>{$num_ht}";
    }

    // }}}
    // {{{ watchoiFilter()

    /**
     * ���b�`���C�t�B���^�����O�����N�ϊ�
     *
     * @param   string  $watchoi_str    ���b�`���C�S�̕�����
     * @param   string  $watchoi_id     ���b�`���C���ʎq
     * @param   string  $watchoi_id4    ���b�`���C��4��
     * @return  string
     */
    public function watchoiFilter($watchoi_str, $watchoi_id, $watchoi_id4)
    {
        global $_conf;

        $wid = $_conf['ngaborn_watchoi4'] ? $watchoi_id4 : $watchoi_id;
        if (!isset($this->thread->watchoicount[$wid]) || $this->thread->watchoicount[$wid] <= 1) {
            return $watchoi_str;
        }

        $count = $this->thread->watchoicount[$wid];
        $num_ht = '';
        if ($_conf['iframe_popup'] == 3) {
            $num_str = (string) $count;
            $num_ht = ' <img src="img/ida.png" width="2" height="12" alt="">';
            $num_ht .= preg_replace('/\\d/', '<img src="img/id\\0.png" height="12" alt="">', $num_str);
            $num_ht .= '<img src="img/idz.png" width="2" height="12" alt=""> ';
        } else {
            $num_ht = '(' . $count . ')';
        }

        if ($_conf['coloredid.enable'] > 0) {
            $wid32 = substr(md5($wid), 0, 8);

            if ($_conf['coloredid.click'] > 0) {
                $num_ht = '<a href="javascript:void(0);" class="' . self::cssClassedWatchoi($wid32) . '" onClick="watchoiCol.click(\'' . $wid32 . '\', event); return false;" onDblClick="this.onclick(event); return false;">' . $num_ht . '</a>';
            }
            $watchoi_str = $this->_coloredWatchoiStr(
                $watchoi_id, $wid, $wid32, $_conf['coloredid.click'] > 0 ? true : false);
        }

        $filter_url = $_conf['read_php'] . '?' . http_build_query(array(
            'host'    => $this->thread->host,
            'bbs'     => $this->thread->bbs,
            'key'     => $this->thread->key,
            'ls'      => 'all',
            'offline' => '1',
            'idpopup' => '1',
            'rf'      => array(
                'field'   => ResFilter::FIELD_NAME,
                'method'  => ($_conf['ngaborn_watchoi4'] ? ResFilter::METHOD_WATCHOI4 : ResFilter::METHOD_JUST),
                'match'   => ResFilter::MATCH_ON,
                'include' => ResFilter::INCLUDE_NONE,
                'word'    => $watchoi_id,
            ),
        ), '', '&amp;') . $_conf['k_at_a'];

        if ($_conf['iframe_popup']) {
            return self::iframePopup($filter_url, $watchoi_str, $_conf['bbs_win_target_at']) . $num_ht;
        }
        return "<a href=\"{$filter_url}\"{$_conf['bbs_win_target_at']}>{$watchoi_str}</a>{$num_ht}";
    }

    // }}}
    // {{{ _linkToWikipeida()

    /**
     * @see ShowThread
     */
    protected function _linkToWikipeida($word)
    {
        global $_conf;

        $link = 'http://ja.wikipedia.org/wiki/' . rawurlencode($word);
        if ($_conf['through_ime']) {
            $link = P2Util::throughIme($link);
        }

        return "<a href=\"{$link}\"{$_conf['ext_win_target_at']}>{$word}</a>";
    }

    // }}}
    // {{{ quoteRes()

    /**
     * ���p�ϊ��i�P�Ɓj
     *
     * @param   string  $full           >>1-100
     * @param   string  $qsign          >>
     * @param   string  $appointed_num    1-100
     * @param   bool    $anchor_jump
     * @return  string
     */
    public function quoteRes($full, $qsign, $appointed_num, $anchor_jump = false)
    {
        global $_conf;

        $appointed_num = mb_convert_kana($appointed_num, 'n');   // �S�p�����𔼊p�����ɕϊ�
        if (preg_match('/\\D/', $appointed_num)) {
            $appointed_num = preg_replace('/\\D+/', '-', $appointed_num);
            return $this->quoteResRange($full, $qsign, $appointed_num);
        }
        if (preg_match('/^0/', $appointed_num)) {
            return $full;
        }

        $qnum = intval($appointed_num);
        if ($qnum < 1 || $qnum > sizeof($this->thread->datlines)) {
            return $full;
        }

        // ���ځ[�񃌃X�ւ̃A���J�[
        if ($_conf['quote_res_view_aborn'] == 0 &&
                in_array($qnum, $this->_aborn_nums)) {
            return '<span class="abornanchor" title="���ځ[��">' . "{$full}</span>";
        }

        if ($anchor_jump && $qnum >= $this->thread->resrange['start'] && $qnum <= $this->thread->resrange['to']) {
            $read_url = '#' . ($this->_matome ? "t{$this->_matome}" : '') . "r{$qnum}";
        } else {
            $read_url = "{$_conf['read_php']}?host={$this->thread->host}&amp;bbs={$this->thread->bbs}&amp;key={$this->thread->key}&amp;offline=1&amp;ls={$appointed_num}";
        }
        $attributes = $_conf['bbs_win_target_at'];
        if ($_conf['quote_res_view'] && ($_conf['quote_res_view_ng'] != 0 ||
                !in_array($qnum, $this->_ng_nums))) {
            if ($this->_matome) {
                $qres_id = "t{$this->_matome}qr{$qnum}";
            } else {
                $qres_id = "qr{$qnum}";
            }
            $attributes .= " onmouseover=\"showResPopUp('{$qres_id}',event)\"";
            $attributes .= " onmouseout=\"hideResPopUp('{$qres_id}')\"";
        }
        return "<a href=\"{$read_url}\"{$attributes}"
            . (in_array($qnum, $this->_aborn_nums) ? ' class="abornanchor"' :
                (in_array($qnum, $this->_ng_nums) ? ' class="nganchor"' : ''))
            . ">{$full}</a>";
    }

    // }}}
    // {{{ quoteResRange()

    /**
     * ���p�ϊ��i�͈́j
     *
     * @param   string  $full           >>1-100
     * @param   string  $qsign          >>
     * @param   string  $appointed_num    1-100
     * @return  string
     */
    public function quoteResRange($full, $qsign, $appointed_num)
    {
        global $_conf;

        if ($appointed_num == '-') {
            return $full;
        }

        $read_url = "{$_conf['read_php']}?host={$this->thread->host}&amp;bbs={$this->thread->bbs}&amp;key={$this->thread->key}&amp;offline=1&amp;ls={$appointed_num}n";

        if ($_conf['iframe_popup']) {
            $pop_url = $read_url . "&amp;renzokupop=true";
            return self::iframePopup(array($read_url, $pop_url), $full, $_conf['bbs_win_target_at'], 1);
        }

        // ���ʂɃ����N
        return "<a href=\"{$read_url}\"{$_conf['bbs_win_target_at']}>{$full}</a>";

        // 1�ڂ����p���X�|�b�v�A�b�v
        /*
        $qnums = explode('-', $appointed_num);
        $qlink = $this->quoteRes($qsign . $qnum[0], $qsign, $qnum[0]) . '-';
        if (isset($qnums[1])) {
            $qlink .= $qnums[1];
        }
        return $qlink;
        */
    }

    // }}}
    // {{{ iframePopup()

    /**
     * HTML�|�b�v�A�b�v�ϊ�
     *
     * @param   string|array    $url
     * @param   string|array    $str
     * @param   string          $attr
     * @param   int|null        $mode
     * @param   bool            $marker
     * @return  string
     */
    static public function iframePopup($url, $str, $attr = '', $mode = null, $marker = false, $extra = '')
    {
        global $_conf;

        // �����N�pURL�ƃ|�b�v�A�b�v�pURL
        if (is_array($url)) {
            $link_url = $url[0];
            $pop_url = $url[1];
        } else {
            $link_url = $url;
            $pop_url = $url;
        }

        // �����N������ƃ|�b�v�A�b�v�̈�
        if (is_array($str)) {
            $link_str = $str[0];
            $pop_str = $str[1];
        } else {
            $link_str = $str;
            $pop_str = null;
        }

        // �����N�̑���
        if (is_array($attr)) {
            $_attr = $attr;
            $attr = '';
            foreach ($_attr as $key => $value) {
                $attr .= ' ' . $key . '="' . p2h($value) . '"';
            }
        } elseif ($attr !== '' && substr($attr, 0, 1) != ' ') {
            $attr = ' ' . $attr;
        }

        // �����N�̑�����HTML�|�b�v�A�b�v�p�̃C�x���g�n���h����������
        $pop_attr = $attr;
        if ($_conf['iframe_popup_event'] == 1) {
            if ($extra !== '') {
                $pop_attr .= " onclick=\"{$extra}; stophide=true; showHtmlPopUp('{$pop_url}',event,0" . ($marker ? ' ,this' : '') . "); return false;\"";
            } else {
                $pop_attr .= " onclick=\"stophide=true; showHtmlPopUp('{$pop_url}',event,0" . ($marker ? ' ,this' : '') . "); return false;\"";
            }
        } else {
            if ($extra !== '') {
                $pop_attr .= " onmouseover=\"{$extra}; showHtmlPopUp('{$pop_url}',event,{$_conf['iframe_popup_delay']}" . ($marker ? ' ,this' : '') . ")\"";
            } else {
                $pop_attr .= " onmouseover=\"showHtmlPopUp('{$pop_url}',event,{$_conf['iframe_popup_delay']}" . ($marker ? ' ,this' : '') . ")\"";
            }
        }
        $pop_attr .= " onmouseout=\"offHtmlPopUp()\"";

        // �ŏI����
        if (is_null($mode)) {
            $mode = $_conf['iframe_popup'];
        }
        if ($mode == 2 && !is_null($pop_str)) {
            $mode = 3;
        } elseif ($mode == 3 && is_null($pop_str)) {
            global $skin, $STYLE;

            $custom_pop_img = "skin/{$skin}/pop.png";
            if (file_exists($custom_pop_img)) {
                $pop_img = p2h($custom_pop_img);
                $x = $STYLE['iframe_popup_mark_width'];
                $y = $STYLE['iframe_popup_mark_height'];
            } else {
                $pop_img = 'img/pop.png';
                $y = $x = 12;
            }
            $pop_str = "<img src=\"{$pop_img}\" width=\"{$x}\" height=\"{$y}\" hspace=\"2\" vspace=\"0\" border=\"0\" align=\"top\" alt=\"\">";
        }

        // rep2��HTTPS�̂Ƃ��A�O��URL��HTML�|�b�v�A�b�v�̃t���[�����ɕ\���ł��Ȃ����ߒʏ탊���N�ɂ���
        if (P2_HTTPS_CONNECTION && P2Util::isExternalUrl($pop_url)) {
            if ($mode == 3) {
                return "<a href=\"{$link_url}\"{$attr}>{$pop_str}{$link_str}</a>";
            }
            return "<a href=\"{$link_url}\"{$attr}>{$link_str}</a>";
        }

        // �����N�쐬
        switch ($mode) {
        // �}�[�N����
        case 1:
            return "<a href=\"{$link_url}\"{$pop_attr}>{$link_str}</a>";
        // (p)�}�[�N
        case 2:
            return "(<a href=\"{$link_url}\"{$pop_attr}>p</a>)<a href=\"{$link_url}\"{$attr}>{$link_str}</a>";
        // [p]�摜�A�T���l�C���Ȃ�
        case 3:
            return "<a href=\"{$link_url}\"{$pop_attr}>{$pop_str}</a><a href=\"{$link_url}\"{$attr}>{$link_str}</a>";
        // �|�b�v�A�b�v���Ȃ�
        default:
            return "<a href=\"{$link_url}\"{$attr}>{$link_str}</a>";
        }
    }

    // }}}
    // {{{ iframePopupCallback()

    /**
     * HTML�|�b�v�A�b�v�ϊ��i�R�[���o�b�N�p�C���^�[�t�F�[�X�j
     *
     * @param   array   $s  ���K�\���Ƀ}�b�`�����v�f�̔z��
     * @return  string
     */
    public function iframePopupCallback($s)
    {
        return self::iframePopup(p2h($s[1], false), p2h($s[3], false), $s[2]);
    }

    // }}}
    // {{{ ���[�e�B���e�B���\�b�h
    // {{{ imageHtmlPopup()

    /**
     * �摜��HTML�|�b�v�A�b�v&�|�b�v�A�b�v�E�C���h�E�T�C�Y�ɍ��킹��
     */
    public function imageHtmlPopup($img_url, $img_tag, $link_str, $extra = '')
    {
        global $_conf;

        if ($_conf['expack.ic2.enabled'] && $_conf['expack.ic2.fitimage']) {
            $popup_url = 'ic2_fitimage.php?url=' . rawurlencode(str_replace('&amp;', '&', $img_url));
        } else {
            $popup_url = $img_url;
        }

        $pops = ($_conf['iframe_popup'] == 1) ? $img_tag . $link_str : array($link_str, $img_tag);
        return self::iframePopup(array($img_url, $popup_url), $pops, $_conf['ext_win_target_at'], null, true, $extra);
    }

    // }}}
    // {{{ respopToAsync()

    /**
     * ���X�|�b�v�A�b�v��񓯊����[�h�ɉ��H����
     */
    public function respopToAsync($str)
    {
        $respop_regex = '/(onmouseover)=\"(showResPopUp\(\'(q(\d+)of\d+)\',event\).*?)\"/';
        $respop_replace = '$1="loadResPopUp(' . $this->asyncObjName . ', $4);$2"';
        return preg_replace($respop_regex, $respop_replace, $str);
    }

    // }}}
    // {{{ getASyncObjJs()

    /**
     * �񓯊��ǂݍ��݂ŗ��p����JavaScript�I�u�W�F�N�g�𐶐�����
     */
    public function getASyncObjJs()
    {
        global $_conf;
        static $done = array();

        if (isset($done[$this->asyncObjName])) {
            return;
        }
        $done[$this->asyncObjName] = true;

        $code = <<<EOJS
<script type="text/javascript">
//<![CDATA[
var {$this->asyncObjName} = {
    host:"{$this->thread->host}", bbs:"{$this->thread->bbs}", key:"{$this->thread->key}",
    readPhp:"{$_conf['read_php']}", readTarget:"{$_conf['bbs_win_target']}"
};
//]]>
</script>\n
EOJS;
        return $code;
    }

    // }}}
    // {{{ getSpmObjJs()

    /**
     * �X�}�[�g�|�b�v�A�b�v���j���[�𐶐�����JavaScript�R�[�h�𐶐�����
     */
    public function getSpmObjJs($retry = false)
    {
        global $_conf, $STYLE;

        if (isset(self::$_spm_objects[$this->spmObjName])) {
            return $retry ? self::$_spm_objects[$this->spmObjName] : '';
        }

        $ttitle_en = UrlSafeBase64::encode($this->thread->ttitle);

        if ($_conf['expack.spm.filter_target'] == '' || $_conf['expack.spm.filter_target'] == 'read') {
            $_conf['expack.spm.filter_target'] = '_self';
        }

        $motothre_url = $this->thread->getMotoThread();
        $motothre_url = substr($motothre_url, 0, strlen($this->thread->ls) * -1);

        $_spmOptions = array(
            'null',
            ((!$_conf['disable_res'] && $_conf['expack.spm.kokores']) ? (($_conf['expack.spm.kokores_orig']) ? '2' : '1') : '0'),
            (($_conf['expack.spm.ngaborn']) ? (($_conf['expack.spm.ngaborn_confirm']) ? '2' : '1') : '0'),
            (($_conf['expack.spm.filter']) ? '1' : '0'),
            (($this->am_on_spm) ? '1' : '0'),
            (($_conf['expack.aas.enabled']) ? '1' : '0'),
            (($_conf['donguri_use']) ? '1' : '0'),
            (($_conf['expack.spm.ngaborn_bbsonly']) ? '1' : '0'),
        );
        $spmOptions = implode(',', $_spmOptions);

        // �G�X�P�[�v
        $_spm_title = StrCtl::toJavaScript($this->thread->ttitle_hc);
        $_spm_url = StrCtl::toJavaScript($motothre_url);
        $_spm_host = StrCtl::toJavaScript($this->thread->host);
        $_spm_bbs = StrCtl::toJavaScript($this->thread->bbs);
        $_spm_key = StrCtl::toJavaScript($this->thread->key);
        $_spm_ls = StrCtl::toJavaScript($this->thread->ls);

        $code = <<<EOJS
<script type="text/javascript">
//<![CDATA[\n
EOJS;

        if (!count(self::$_spm_objects)) {
            $code .= sprintf("spmFlexTarget = '%s';\n", StrCtl::toJavaScript($_conf['expack.spm.filter_target']));
            if ($_conf['expack.aas.enabled']) {
                $code .= sprintf("var aas_popup_width = %d;\n", $_conf['expack.aas.default.width'] + 10);
                $code .= sprintf("var aas_popup_height = %d;\n", $_conf['expack.aas.default.height'] + 10);
            }
        }

        $code .= <<<EOJS
var {$this->spmObjName} = {
    'objName':'{$this->spmObjName}',
    'rc':'{$this->thread->rescount}',
    'title':'{$_spm_title}',
    'ttitle_en':'{$ttitle_en}',
    'url':'{$_spm_url}',
    'host':'{$_spm_host}',
    'bbs':'{$_spm_bbs}',
    'key':'{$_spm_key}',
    'ls':'{$_spm_ls}',
    'spmOption':[{$spmOptions}]
};
SPM.init({$this->spmObjName});
//]]>
</script>\n
EOJS;

        self::$_spm_objects[$this->spmObjName] = $code;

        return $code;
    }

    // }}}
    // }}}
    // {{{ transLinkDo()����Ăяo�����URL�����������\�b�h
    /**
     * �����̃��\�b�h�͈����������Ώۃp�^�[���ɍ��v���Ȃ���false��Ԃ��A
     * transLinkDo()��false���Ԃ��Ă����$_url_handlers�ɓo�^����Ă��鎟�̊֐�/���\�b�h�ɏ��������悤�Ƃ���B
     */
    // {{{ plugin_linkURL()

    /**
     * URL�����N
     *
     * @param   string $url
     * @param   array $purl
     * @param   string $str
     * @return  string|false
     */
    public function plugin_linkURL($url, $purl, $str)
    {
        global $_conf;

        if (isset($purl['scheme'])) {
            // ime
            if ($_conf['through_ime']) {
                $link_url = P2Util::throughIme($purl[0]);
            } else {
                $link_url = $url;
            }

            $is_http = ($purl['scheme'] == 'http' || $purl['scheme'] == 'https');

            // HTML�|�b�v�A�b�v
            if ($_conf['iframe_popup'] && $is_http) {
                // *pm �w��̏ꍇ�̂݁A���ʂɎ蓮�]���w���ǉ�����
                if (substr($_conf['through_ime'], -2) == 'pm') {
                    $pop_url = P2Util::throughIme($purl[0], -1);
                } else {
                    $pop_url = $link_url;
                }
                $link = self::iframePopup(array($link_url, $pop_url), $str, $_conf['ext_win_target_at']);
            } else {
                $link = "<a href=\"{$link_url}\"{$_conf['ext_win_target_at']}>{$str}</a>";
            }

            // �u���N���`�F�b�J
            if ($_conf['brocra_checker_use'] && $_conf['brocra_checker_url'] && $is_http) {
                if (strlen($_conf['brocra_checker_query'])) {
                    $brocra_checker_url = $_conf['brocra_checker_url'] . '?' . $_conf['brocra_checker_query'] . '=' . rawurlencode($purl[0]);
                } else {
                    $brocra_checker_url = rtrim($_conf['brocra_checker_url'], '/') . '/' . $url;
                }
                $brocra_checker_url_orig = $brocra_checker_url;
                // �u���N���`�F�b�J�Eime
                if ($_conf['through_ime']) {
                    $brocra_checker_url = P2Util::throughIme($brocra_checker_url);
                }
                $check_mark = '�`�F�b�N';
                $check_mark_prefix = '[';
                $check_mark_suffix = ']';
                // �u���N���`�F�b�J�EHTML�|�b�v�A�b�v
                if ($_conf['iframe_popup']) {
                    // *pm �w��̏ꍇ�̂݁A���ʂɎ蓮�]���w���ǉ�����
                    if (substr($_conf['through_ime'], -2) == 'pm') {
                        $brocra_checker_url = P2Util::throughIme($brocra_checker_url_orig, -1);
                    } else {
                        $brocra_pop_url = $brocra_checker_url;
                    }
                    if ($_conf['iframe_popup'] == 3) {
                        $check_mark = '<img src="img/check.png" width="33" height="12" alt="">';
                        $check_mark_prefix = '';
                        $check_mark_suffix = '';
                    }
                    $brocra_checker_link = self::iframePopup(array($brocra_checker_url, $brocra_pop_url), $check_mark, $_conf['ext_win_target_at']);
                } else {
                    $brocra_checker_link = "<a href=\"{$brocra_checker_url}\"{$_conf['ext_win_target_at']}>{$check_mark}</a>";
                }
                $link .= $check_mark_prefix . $brocra_checker_link . $check_mark_suffix;
            }

            return $link;
        }
        return false;
    }

    // }}}
    // {{{ plugin_link2chSubject()

    /**
     * 2ch bbspink    �����N
     *
     * @param   string $url
     * @param   array $purl
     * @param   string $str
     * @return  string|false
     */
    public function plugin_link2chSubject($url, $purl, $str)
    {
        global $_conf;

        if (preg_match('{^https?://(.+)/(.+)/$}', $purl[0], $m)) {
            //rep2�ɓo�^����Ă���Ȃ�΃����N����
            if (P2HostMgr::isRegisteredBbs($m[1],$m[2])) {
                $subject_url = "{$_conf['subject_php']}?host={$m[1]}&amp;bbs={$m[2]}";
                return "<a href=\"{$url}\" target=\"subject\">{$str}</a> [<a href=\"{$subject_url}{$_conf['k_at_a']}\" target=\"subject\">��p2�ŊJ��</a>]";
            }
        }
        return false;
    }

    // }}}
    // {{{ plugin_linkThread()

    /**
     * �X���b�h�����N
     *
     * @param   string $url
     * @param   array $purl
     * @param   string $str
     * @return  string|false
     */
    public function plugin_linkThread($url, $purl, $str)
    {
        global $_conf;

        list($nama_url, $host, $bbs, $key, $ls) = P2Util::detectThread($purl[0]);
        if ($host && $bbs && $key) {
            $read_url = "{$_conf['read_php']}?host={$host}&amp;bbs={$bbs}&amp;key={$key}&amp;ls={$ls}{$_conf['k_at_a']}";
            if ($_conf['iframe_popup']) {
                if ($ls && preg_match('/^[0-9\\-n]+$/', $ls)) {
                    $pop_url = $read_url;
                } else {
                    $pop_url = $read_url . '&amp;one=true';
                }
                return self::iframePopup(array($read_url, $pop_url), $str, $_conf['bbs_win_target_at']);
            }
            return "<a href=\"{$read_url}{$_conf['bbs_win_target_at']}\">{$str}</a>";
        }

        return false;
    }

    // }}}
    // {{{ plugin_viewImage()

    /**
     * �摜�|�b�v�A�b�v�ϊ�
     *
     * @param   string $url
     * @param   array $purl
     * @param   string $str
     * @return  string|false
     */
    public function plugin_viewImage($url, $purl, $str)
    {
        global $_conf;
        global $pre_thumb_unlimited, $pre_thumb_limit;

        if (P2HostMgr::isUrlWikipediaJa($url)) {
            return false;
        }

        // �\������
        if (!$pre_thumb_unlimited && empty($pre_thumb_limit)) {
            return false;
        }

        if (preg_match('{^https?://.+?\\.(jpe?g|gif|png)$}i', $purl[0]) && empty($purl['query'])) {
            $pre_thumb_limit--; // �\�������J�E���^��������
            $img_tag = "<img class=\"thumbnail\" src=\"{$url}\" height=\"{$_conf['pre_thumb_height']}\" width=\"{$_conf['pre_thumb_width']}\" hspace=\"4\" vspace=\"4\" align=\"middle\">";

            if ($_conf['iframe_popup']) {
                $view_img = $this->imageHtmlPopup($url, $img_tag, $str);
            } else {
                $view_img = "<a href=\"{$url}\"{$_conf['ext_win_target_at']}>{$img_tag}{$str}</a>";
            }

            // �u���N���`�F�b�J �i�v���r���[�Ƃ͑��e��Ȃ��̂ŃR�����g�A�E�g�j
            /*if ($_conf['brocra_checker_use']) {
                $link_url_en = rawurlencode($url);
                if ($_conf['iframe_popup'] == 3) {
                    $check_mark = '<img src="img/check.png" width="33" height="12" alt="">';
                    $check_mark_prefix = '';
                    $check_mark_suffix = '';
                } else {
                    $check_mark = '�`�F�b�N';
                    $check_mark_prefix = '[';
                    $check_mark_suffix = ']';
                }
                $view_img .= $check_mark_prefix . "<a href=\"{$_conf['brocra_checker_url']}?{$_conf['brocra_checker_query']}={$link_url_en}\"{$_conf['ext_win_target_at']}>{$check_mark}</a>" . $check_mark_suffix;
            }*/

            return $view_img;
        }

        return false;
    }

    // }}}
    // {{{ plugin_replaceImageUrl()

    /**
     * �u���摜URL+ImageCache2
     */
    public function plugin_replaceImageUrl($url, $purl, $str)
    {
        static $serial = 0;

        global $_conf;
        global $pre_thumb_unlimited, $pre_thumb_ignore_limit, $pre_thumb_limit;

        // +Wiki
        global $replaceImageUrlCtl;

        $url = $purl[0];
        $replaced = $replaceImageUrlCtl->replaceImageUrl($url);
        if (count($replaced) === 0) {
            return false;
        }

        foreach ($replaced as $v) {
            $url_en = rawurlencode($v['url']);
            $url_ht = p2h($v['url']);
            $ref_en = $v['referer'] ? '&amp;ref=' . rawurlencode($v['referer']) : '';

            // ����
            $serial++;
            $thumb_id = 'thumbs' . $serial . $this->thumb_id_suffix;
            $tmp_thumb = './img/ic_load.png';
            $result = '';

            $icdb = new ImageCache2_DataObject_Images();

            // r=0:�����N;r=1:���_�C���N�g;r=2:PHP�ŕ\��
            // t=0:�I���W�i��;t=1:PC�p�T���l�C��;t=2:�g�їp�T���l�C��;t=3:���ԃC���[�W
            // +Wiki
            $img_url = 'ic2.php?r=1&amp;uri=' . $url_en . $ref_en;
            $thumb_url = 'ic2.php?r=1&amp;t=1&amp;uri=' . $url_en . $ref_en;
            // ���C�ɃX�������摜�����N
            $rank = null;
            if ($_conf['expack.ic2.fav_auto_rank']) {
                $rank = $this->getAutoFavRank();
                if ($rank !== null) $thumb_url .= '&rank=' . $rank;
            }

            // DB�ɉ摜��񂪓o�^����Ă����Ƃ�
            if ($icdb->get($v['url'])) {

                // �E�B���X�Ɋ������Ă����t�@�C���̂Ƃ�
                if ($icdb->mime == 'clamscan/infected') {
                    $result .= "<img class=\"thumbnail\" src=\"./img/x04.png\" width=\"32\" height=\"32\" hspace=\"4\" vspace=\"4\" align=\"middle\">";
                    continue;
                }
                // ���ځ[��摜�̂Ƃ�
                if ($icdb->rank < 0) {
                    $result .= "<img class=\"thumbnail\" src=\"./img/x01.png\" width=\"32\" height=\"32\" hspace=\"4\" vspace=\"4\" align=\"middle\">";
                    continue;
                }

                // �I���W�i�����L���b�V������Ă���Ƃ��͉摜�𒼐ړǂݍ���
                if (file_exists($this->thumbnailer->srcPath($icdb->size, $icdb->md5, $icdb->mime))) {
                    $img_url = $this->thumbnailer->srcUrl($icdb->size, $icdb->md5, $icdb->mime);
                    $cached = true;
                } else {
                    $cached = false;
                }

                // �T���l�C�����쐬����Ă��Ă���Ƃ��͉摜�𒼐ړǂݍ���
                if (file_exists($this->thumbnailer->thumbPath($icdb->size, $icdb->md5, $icdb->mime))) {
                    $thumb_url = $this->thumbnailer->thumbUrl($icdb->size, $icdb->md5, $icdb->mime);
                    $update = null;

                    // �����X���^�C�����@�\��ON�ŃX���^�C���L�^����Ă��Ȃ��Ƃ���DB���X�V
                    if (!is_null($this->img_memo) && strpos($icdb->memo, $this->img_memo) === false){
                        $update = new ImageCache2_DataObject_Images();
                        if (!is_null($icdb->memo) && strlen($icdb->memo) > 0) {
                            $update->memo = $this->img_memo . ' ' . $icdb->memo;
                        } else {
                            $update->memo = $this->img_memo;
                        }
                        $update->whereAddQuoted('uri', '=', $v['url']);
                    }

                    // expack.ic2.fav_auto_rank_override �̐ݒ�ƃ����N������OK�Ȃ�
                    // ���C�ɃX�������摜�����N���㏑���X�V
                    if ($rank !== null &&
                            self::isAutoFavRankOverride($icdb->rank, $rank)) {
                        if ($update === null) {
                            $update = new ImageCache2_DataObject_Images();
                            $update->whereAddQuoted('uri', '=', $v['url']);
                        }
                        $update->rank = $rank;
                    }

                    if ($update !== null) {
                        $update->update();
                    }
                }

                // �T���l�C���̉摜�T�C�Y
                $thumb_size = $this->thumbnailer->calc($icdb->width, $icdb->height);
                $thumb_size = preg_replace('/(\d+)x(\d+)/', 'width="$1" height="$2"', $thumb_size);
                $tmp_thumb = './img/ic_load1.png';

                $orig_img_url   = $img_url;
                $orig_thumb_url = $thumb_url;

            // �摜���L���b�V������Ă��Ȃ��Ƃ�
            // �����X���^�C�����@�\��ON�Ȃ�N�G����UTF-8�G���R�[�h�����X���^�C���܂߂�
            } else {
                // �摜���u���b�N���X�gor�G���[���O�ɂ��邩�m�F
                if (false !== ($errcode = $icdb->ic2_isError($v['url']))) {
                    $result .= "<img class=\"thumbnail\" src=\"./img/{$errcode}.png\" width=\"32\" height=\"32\" hspace=\"4\" vspace=\"4\" align=\"middle\">";
                    continue;
                }

                $cached = false;

                $orig_img_url   = $img_url;
                $orig_thumb_url = $thumb_url;
                $img_url .= $this->img_memo_query;
                $thumb_url .= $this->img_memo_query;
                $thumb_size = '';
                $tmp_thumb = './img/ic_load2.png';
            }

            // �L���b�V������Ă��炸�A�\�����������L���̂Ƃ�
            if (!$cached && !$pre_thumb_unlimited && !$pre_thumb_ignore_limit) {
                // �\�������𒴂��Ă�����A�\�����Ȃ�
                // �\�������𒴂��Ă��Ȃ���΁A�\�������J�E���^��������
                if ($pre_thumb_limit <= 0) {
                    $show_thumb = false;
                } else {
                    $show_thumb = true;
                    $pre_thumb_limit--;
                }
            } else {
                $show_thumb = true;
            }

            // �\�����[�h
            $img_src = $show_thumb ? $thumb_url : $tmp_thumb;
            $img_size = $show_thumb ? $thumb_size : 'width="32" height="32"';
            $img_tag = "<img id=\"{$thumb_id}\" class=\"thumbnail\" src=\"{$img_src}\" {$img_size} hspace=\"4\" vspace=\"4\" align=\"middle\">";
            if ($_conf['iframe_popup']) {
                $extra = $show_thumb ? '' : "loadThumb('{$thumb_url}','{$thumb_id}')";
                $view_img = $this->imageHtmlPopup($img_url, $img_tag, '', $extra);
            } elseif ($show_thumb) {
                $view_img = "<a href=\"{$img_url}\"{$_conf['ext_win_target_at']}>{$img_tag}</a>";
            } else {
                $view_img = "<a href=\"{$img_url}\" onclick=\"return loadThumb('{$thumb_url}','{$thumb_id}')\"{$_conf['ext_win_target_at']}>{$img_tag}</a>";
            }

            $view_img .= '<img class="ic2-info-opener" src="img/s2a.png" width="16" height="16" onclick="ic2info.show('
                    //. "'{$url_ht}', '{$orig_img_url}', '{$_conf['ext_win_target']}', '{$orig_thumb_url}', event)\">";
                      . "'{$url_ht}', event)\">";

            $result .= $view_img;
        }
        // �\�[�X�ւ̃����N��ime�t���ŕ\��
        $ime_url = P2Util::throughIme($url);
        $result .= "<a class=\"img_through_ime\" href=\"{$ime_url}\"{$_conf['ext_win_target_at']}>{$str}</a>";
        return $result;
    }

    /**
     * +Wiki:�����N�v���O�C��
     */
    public function plugin_linkPlugin($url, $purl, $str)
    {
        return $GLOBALS['linkPluginCtl']->replaceLinkToHTML($url, $str);
    }

    // }}}
    // {{{ getQuotebacksJson()

    public function getQuotebacksJson()
    {
        $ret = array();
        foreach ($this->getQuoteFrom() as $resnum => $quote_from) {
            if (!$quote_from) {
                continue;
            }
            if ($resnum != 1 && ($resnum < $this->thread->resrange['start'] || $resnum > $this->thread->resrange['to'])) {
                continue;
            }
            $tmp = array();
            foreach ($quote_from as $quote) {
                if ($quote != 1 && ($quote < $this->thread->resrange['start'] || $quote > $this->thread->resrange['to'])) {
                    continue;
                }
                $tmp[] = $quote;
            }
            if ($tmp) $ret[] = "{$resnum}:[" . join(',', $tmp) . "]";
        }
        return '{' . join(',', $ret) . '}';
    }

    // }}}
    // {{{ getResColorJs()

    public function getResColorJs()
    {
        global $_conf, $STYLE;

        $fontstyle_bold = empty($STYLE['fontstyle_bold']) ? 'normal' : $STYLE['fontstyle_bold'];
        $fontweight_bold = empty($STYLE['fontweight_bold']) ? 'normal' : $STYLE['fontweight_bold'];
        $fontfamily_bold = $STYLE['fontfamily_bold'];
        $backlinks = $this->getQuotebacksJson();
        $colors = array();
        $backlink_colors = join(',',
            array_map(function ($x) {
                return "'{$x}'";
            },
                explode(',', $_conf['backlink_coloring_track_colors']))
        );
        $prefix = $this->_matome ? "t{$this->_matome}" : '';
        return <<<EOJS
<script type="text/javascript">
if (typeof rescolObjs == 'undefined') rescolObjs = [];
rescolObjs.push((function() {
    var obj = new BacklinkColor('{$prefix}');
    obj.colors = [{$backlink_colors}];
    obj.highlightStyle = {fontStyle :'{$fontstyle_bold}', fontWeight : '{$fontweight_bold}', fontFamily : '{$fontfamily_bold}'};
    obj.backlinks = {$backlinks};
    return obj;
})());
</script>
EOJS;
    }

    // }}}
}

// }}}

/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
