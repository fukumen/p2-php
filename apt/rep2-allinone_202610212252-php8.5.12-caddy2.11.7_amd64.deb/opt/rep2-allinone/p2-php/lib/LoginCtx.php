<?php

/**
 * rep2 - �F�،��؂̓��� (collect)
 *
 */

// {{{ LoginCtx

class LoginCtx
{
    const INTENT_FORM = 'form';
    const INTENT_FORM_NEW = 'form_new';
    const INTENT_STATE = 'state';
    const INTENT_NONE = 'none';

    public $intent;
    public $identity = null;
    public $authFileExists = false;
    public $recUser = null;
    public $passX = null;
    public $cidCookiePresent = false;
    public $cidInfo = false;
    public $cidExpired = false;

    /**
     * ���ʃQ�[�g�̓��͂� intent ���W�߂�
     *
     * @param Login $login
     * @return LoginCtx
     */
    static public function collect(Login $login)
    {
        global $_conf;

        $ctx = new self();
        $cookie = $login->getCookie();

        $ctx->cidCookiePresent = $cookie->hasCid();
        $ctx->cidInfo = $cookie->getCidInfo();

        // �L�������`�F�b�N (����p�Ȃ�)
        if ($ctx->cidInfo !== false) {
            $ctx->cidExpired = $cookie->isExpiredCid($ctx->cidInfo);
        }

        // ���[�U������̗D�揇�ʂɉ�����
        $pattern = "/^[0-9A-Za-z_]+\$/";

        // ���O�C���t�H�[������̎w��
        if (isset($_REQUEST['form_login_id']) && preg_match($pattern, $_REQUEST['form_login_id'])) {
            $ctx->identity = $_REQUEST['form_login_id'];

        // GET�����ł̎w��
        } elseif (isset($_REQUEST['user']) && preg_match($pattern, $_REQUEST['user'])) {
            $ctx->identity = $_REQUEST['user'];

        // Cookie�Ŏw��
        } elseif ($ctx->cidInfo !== false && !$ctx->cidExpired && preg_match($pattern, $ctx->cidInfo[0])) {
            $ctx->identity = $ctx->cidInfo[0];

        // Session�Ŏw��
        } elseif (isset($_SESSION['login_user']) && preg_match($pattern, $_SESSION['login_user'])) {
            $ctx->identity = $_SESSION['login_user'];

        // �O���F�؂Ŏw��
        } elseif (!empty($_conf['external_authentication']) && isset($_SERVER['REMOTE_USER']) && preg_match($pattern, $_SERVER['REMOTE_USER'])) {
            $ctx->identity = $_SERVER['REMOTE_USER'];
        }

        if ($ctx->identity !== null) {
            $login->checkAuthUserFile();
            $ctx->authFileExists = file_exists($_conf['auth_user_file']);
            $rec_pass_x = null;
            if ($ctx->authFileExists) {
                include $_conf['auth_user_file'];
                $ctx->recUser = $rec_login_user_u;
                if (isset($rec_login_pass_x) && strlen($rec_login_pass_x) > 0) {
                    $rec_pass_x = $rec_login_pass_x;
                }
            }
            $ctx->passX = $rec_pass_x;
        }

        if (!empty($_POST['submit_member'])) {
            $ctx->intent = self::INTENT_FORM;
        } elseif (!empty($_POST['submit_new'])) {
            $ctx->intent = self::INTENT_FORM_NEW;
        } elseif ($ctx->cidCookiePresent || (isset($_SESSION['login_user']) && isset($_SESSION['login_pass_x']))) {
            $ctx->intent = self::INTENT_STATE;
        } else {
            $ctx->intent = self::INTENT_NONE;
        }

        return $ctx;
    }
}

// }}}
// {{{ LoginFormCtx

class LoginFormCtx
{
    public $requestUri = null;
    public $devicePixelRatio = null;
    public $registerCid = false;
    public $lockout = false;
    public $formVerified = false;

    /**
     * form �o�H�p�̓��͂��W�߂�
     *
     * @param Login $login
     * @param LoginCtx $ctx
     * @return LoginFormCtx
     */
    static public function collect(Login $login, LoginCtx $ctx)
    {
        $ctx2 = new self();
        $ctx2->requestUri = $_SERVER['REQUEST_URI'] ?? null;
        $ctx2->devicePixelRatio = $login->normalizeDevicePixelRatio($_REQUEST['device_pixel_ratio'] ?? null);
        $ctx2->registerCid = !empty($_REQUEST['ctl_keep_login']) && !empty($_REQUEST['keep_login']);
        $ctx2->lockout = $login->checkLockout();    // �A�N�Z�X���O�̓ǂݍ��݂݂̂ŕ���p�Ȃ�

        $formLoginPass = $_POST['form_login_pass'] ?? null;
        $formLoginId = $_POST['form_login_id'] ?? null;

        // P2Hash �͕���p�Ȃ�
        if ($formLoginId == $ctx->identity) {
            $ctx2->formVerified = $login->getHash()->password_verify($formLoginPass, $ctx->passX);
        }

        return $ctx2;
    }
}

// }}}
// {{{ LoginRegistCtx

class LoginRegistCtx
{
    public $formLoginId = null;
    public $formLoginPass = null;
    public $devicePixelRatio = null;
    public $registerCid = false;

    /**
     * form_new �o�H�p�̓��͂��W�߂�
     *
     * @param Login $login
     * @param LoginCtx $ctx
     * @return LoginRegistCtx
     */
    static public function collect(Login $login, LoginCtx $ctx)
    {
        $ctx2 = new self();
        $ctx2->formLoginId = $_POST['form_login_id'] ?? null;
        $ctx2->formLoginPass = $_POST['form_login_pass'] ?? null;
        $ctx2->devicePixelRatio = $login->normalizeDevicePixelRatio($_REQUEST['device_pixel_ratio'] ?? null);
        $ctx2->registerCid = !empty($_REQUEST['ctl_keep_login']) && !empty($_REQUEST['keep_login']);

        return $ctx2;
    }
}

// }}}
// {{{ LoginStateCtx

class LoginStateCtx
{
    public $devicePixelRatio = null;
    public $cidVerified = false;
    public $sessionChecked = false;
    public $sessionError = false;
    public $sessionVerified = false;
    public $logout = false;
    public $sessionUser = null;

    /**
     * state �o�H�p�̓��͂��W�߂�
     *
     * @param Login $login
     * @param LoginCtx $ctx
     * @return LoginStateCtx
     */
    static public function collect(Login $login, LoginCtx $ctx)
    {
        global $_p2session;

        $ctx2 = new self();

        $ctx2->logout = !empty($_REQUEST['logout']);

        $cookie = $login->getCookie();

        if ($ctx->cidInfo !== false && !$ctx->cidExpired && count($ctx->cidInfo) === 4) {
            $ctx2->devicePixelRatio = $ctx->cidInfo[3];
        }

        // cid �ƍ� (����p�Ȃ�)
        if ($ctx->cidCookiePresent && $ctx->cidInfo !== false && !$ctx->cidExpired) {
            $ctx2->cidVerified = $cookie->compareUserPw($ctx->cidInfo, $ctx->identity, $ctx->passX);
        }

        $sessionUser = $_SESSION['login_user'] ?? null;
        $sessionPassX = $_SESSION['login_pass_x'] ?? null;

        // �Z�b�V�������� (checkSessionErrors �͕���p�Ȃ�)�Bcid �Ő��������ꍇ�͔��肵�Ȃ��B
        if (!$ctx2->cidVerified && $sessionUser !== null && $sessionPassX !== null) {
            $ctx2->sessionChecked = true;
            $ctx2->sessionError = $_p2session->checkSessionErrors();
        }

        // P2Hash::hash�͕���p����
        $ctx2->sessionVerified = ($sessionUser == $ctx->identity && $sessionPassX == P2Hash::hash($ctx->passX));

        $ctx2->sessionUser = $sessionUser;

        return $ctx2;
    }
}

// }}}

/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
