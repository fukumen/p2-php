<?php
/**
 * ImageCache2 - �摜�L���b�V���ꗗ
 */

// {{{ p2��{�ݒ�ǂݍ���&�F��

define('P2_SESSION_CLOSE_AFTER_AUTHENTICATION', 0);
define('P2_OUTPUT_XHTML', 1);

require_once __DIR__ . '/../init.php';

$_login->authorize();

if (!$_conf['expack.ic2.enabled']) {
    p2die('ImageCache2�͖����ł��B', 'conf/conf_admin_ex.inc.php �̐ݒ��ς��Ă��������B');
}

$enable_zip = false;
/*
if (!$_conf['iphone'] && $_conf['expack.ic2.zip']) {
    if (!extension_loaded('zip')) {
        p2die('zip �g�����W���[�������[�h����Ă��܂���B');
    }
    $enable_zip = true;
}
*/

if ($_conf['iphone']) {
    $_conf['extra_headers_ht'] .= <<<EOP
\n<link rel="stylesheet" type="text/css" href="css/ic2_iphone.css?{$_conf['p2_version_id']}">
<link rel="stylesheet" type="text/css" href="css/iv2_iphone.css?{$_conf['p2_version_id']}">
<script type="text/javascript" src="js/jquery.skOuterClick.js"></script>
<script type="text/javascript" src="js/json2.js?{$_conf['p2_version_id']}"></script>
<script type="text/javascript" src="js/ic2_iphone.js?{$_conf['p2_version_id']}"></script>
<script type="text/javascript" src="js/iv2_iphone.js?{$_conf['p2_version_id']}"></script>\n
EOP;
    $_conf['extra_headers_xht'] .= <<<EOP
\n<link rel="stylesheet" type="text/css" href="css/ic2_iphone.css?{$_conf['p2_version_id']}" />
<link rel="stylesheet" type="text/css" href="css/iv2_iphone.css?{$_conf['p2_version_id']}" />
<script type="text/javascript" src="js/jquery.skOuterClick.js"></script>
<script type="text/javascript" src="js/json2.js?{$_conf['p2_version_id']}"></script>
<script type="text/javascript" src="js/ic2_iphone.js?{$_conf['p2_version_id']}"></script>
<script type="text/javascript" src="js/iv2_iphone.js?{$_conf['p2_version_id']}"></script>\n
EOP;
}

// �r���[����p�̉B���v�f

if ($_conf['view_forced_by_query']) {
    output_add_rewrite_var('b', $_conf['b']);
}

// }}}
// {{{ ������

// ���C�u�����ǂݍ���
require_once P2EX_LIB_DIR . '/ImageCache2/bootstrap.php';
require_once P2EX_LIB_DIR . '/ImageCache2/QuickForm/Rules.php';

// }}}
// {{{ config

// �ݒ�t�@�C���ǂݍ���
$ini = ic2_loadconfig();

// Exif�\�����L�����H
$show_exif = ($ini['Viewer']['exif'] && extension_loaded('exif'));

$_default_mode = (int)$_conf['expack.ic2.viewer_default_mode'];
if ($_default_mode < 0 || $_default_mode > 3) {
    $_default_mode = 0;
}

// �t�H�[���̃f�t�H���g�l
$_defaults = array(
    'page'  => 1,
    'cols'  => $ini['Viewer']['cols'],
    'rows'  => $ini['Viewer']['rows'],
    'inum'  => $ini['Viewer']['inum'],
    'order' => $ini['Viewer']['order'],
    'sort'  => $ini['Viewer']['sort'],
    'field' => $ini['Viewer']['field'],
    'keyword'   => '',
    'threshold' => $ini['Viewer']['threshold'],
    'compare' => $ini['Viewer']['compare'],
    'mode' => $_default_mode,
    'thumbtype' => ImageCache2_Thumbnailer::SIZE_DEFAULT,
);

// �t�H�[���̌Œ�l
$_constants = array(
    'start'   => '<<',
    'prev'    => '<',
    'next'    => '>',
    'end'     => '>>',
    'jump'    => 'Go',
    'search'  => '����',
    'cngmode' => '�ύX',
    '_hint'   => $_conf['detect_hint'],
);

// 臒l��r���@
$_compare = array(
    '>=' => '&gt;=',
    '='  => '=',
    '<=' => '&lt;=',
);

// 臒l
$_threshold = array(
    '-1' => '-1',
    '0' => '0',
    '1' => '1',
    '2' => '2',
    '3' => '3',
    '4' => '4',
    '5' => '5',
);

// �\�[�g�
$_order = array(
    'time' => '�擾����',
    'uri'  => 'URL',
    'date_uri' => '���t+URL',
    'date_uri2' => '���t+URL(2)',
    'name' => '�t�@�C����',
    'size' => '�t�@�C���T�C�Y',
    'width' => '����',
    'height' => '����',
    'pixels' => '�s�N�Z����',
    'id' => 'ID',
);

// �\�[�g����
$_sort = array(
    'ASC'  => '����',
    'DESC' => '�~��',
);

// �����t�B�[���h
$_field = array(
    'uri'   => 'URL',
    'name'  => '�t�@�C����',
    'memo'  => '����',
    'md5'  => 'md5',
);

// ���[�h
$_mode = array(
    '3' => '��Ȳق���',
    '0' => '�ꗗ',
    '1' => '�ꊇ�ύX',
    '2' => '�ʊǗ�',
);

// �T���l�C���^�C�v
$_thumbtype = array(
    '1' => $ini['Thumb1']['name'],
    '2' => $ini['Thumb2']['name'],
    '3' => $ini['Thumb3']['name'],
);

// �g�їp�ɕϊ��i�t�H�[�����p�P�b�g�ߖ�̑ΏۊO�Ƃ��邽�߁j
if ($_conf['iphone']) {
    foreach ($_order as $_k => $_v) {
        $_order[$_k] = mb_convert_kana($_v, 'ask');
    }
    foreach ($_field as $_k => $_v) {
        $_field[$_k] = mb_convert_kana($_v, 'ask');
    }
}

// }}}
// {{{ prepare (DB & Cache)

// DB_DataObject���p������DAO
$icdb = new ImageCache2_DataObject_Images();
$db = $icdb->PDO();
$db_class = $icdb->db_class;

if ($ini['Viewer']['cache']) {
    $kvs = P2KeyValueStore::getStore($_conf['iv2_cache_db_path'],
                                     P2KeyValueStore::CODEC_SERIALIZING);
    $cache_lifetime = (int)$ini['Viewer']['cache_lifetime'];
    if (array_key_exists('cache_clean', $_REQUEST)) {
        $cache_clear = $_REQUEST['cache_clean'];
    } else {
        $cache_clear = false;
    }
    $optimize_db = false;

    if ($cache_clear == 'all') {
        $kvs->clear();
        $optimize_db = true;
    } elseif ($cache_clear == 'gc') {
        $kvs->gc($cache_lifetime);
        $optimize_db = true;
    }

    if ($optimize_db) {
        // �L���b�V����VACUUM,REINDEX
        $kvs->optimize();

        // SQLite�Ȃ�VACUUM�����s
        if ($db_class == 'sqlite') {
            $result = $db->query('VACUUM');
        }
    }

    $cache = new P2KeyValueStore_FunctionCache($kvs, $cache_lifetime);
    $imageInfo_getExtraInfo = $cache->createProxy('ImageCache2_ImageInfo::getExtraInfo');
    $imageInfo_getExifData = $cache->createProxy('ImageCache2_ImageInfo::getExifData');
    $editForm_imgManager = $cache->createProxy('ImageCache2_EditForm::imgManager');

    $use_cache = true;
} else {
    $use_cache = false;
}

// }}}
// {{{ prepare (Form & Template)

// �y�[�W�J�ڗp�t�H�[����ݒ�
// �y�[�W�J�ڂ�GET�ōs�����A�摜���̍X�V��POST�ōs���̂łǂ���ł��󂯓����悤�ɂ���
// �i�����_�����O�O�� $qf->updateAttributes(array('method' => 'get')); �Ƃ���j
$_attribures = array('accept-charset' => $_conf['accept_charset']);
$_method = ($_SERVER['REQUEST_METHOD'] == 'GET') ? 'get' : 'post';
$qf = new HTML_QuickForm('go', $_method, $_SERVER['SCRIPT_NAME'], '_self', $_attribures);
$qf->registerRule('numberInRange',  null, 'ImageCache2_QuickForm_Rule_NumberInRange');
$qf->registerRule('inArray',        null, 'ImageCache2_QuickForm_Rule_InArray');
$qf->registerRule('arrayKeyExists', null, 'ImageCache2_QuickForm_ArrayKeyExists');
$qf->setDefaults($_defaults);
$qf->setConstants($_constants);
$qfe = array();

// �t�H�[���v�f�̒�`

// �y�[�W�ړ��̂��߂�submit�v�f
$qfe['start'] = $qf->addElement('button', 'start');
$qfe['prev']  = $qf->addElement('button', 'prev');
$qfe['next']  = $qf->addElement('button', 'next');
$qfe['end']   = $qf->addElement('button', 'end');
$qfe['jump']  = $qf->addElement('button', 'jump');

// �\�����@�Ȃǂ��w�肷��input�v�f
$qfe['page']      = $qf->addElement('text', 'page', '�y�[�W�ԍ����w��', array('size' => 3));
$qfe['cols']      = $qf->addElement('text', 'cols', '��', array('size' => 3, 'maxsize' => 2));
$qfe['rows']      = $qf->addElement('text', 'rows', '�c', array('size' => 3, 'maxsize' => 2));
$qfe['order']     = $qf->addElement('select', 'order', '���я�', $_order);
$qfe['sort']      = $qf->addElement('select', 'sort', '����', $_sort);
$qfe['field']     = $qf->addElement('select', 'field', '�t�B�[���h', $_field);
$qfe['keyword']   = $qf->addElement('text', 'keyword', '�L�[���[�h', array('size' => 20));
$qfe['compare']   = $qf->addElement('select', 'compare', '��r���@', $_compare);
$qfe['threshold'] = $qf->addElement('select', 'threshold', '�������l', $_threshold);
$qfe['thumbtype'] = $qf->addElement('select', 'thumbtype', '�T���l�C���^�C�v', $_thumbtype);

// �����R�[�h����̃q���g�ɂ���B���v�f
$qfe['_hint'] = $qf->addElement('hidden', '_hint');

// ���������s����submit�v�f
$qfe['search'] = $qf->addElement('submit', 'search');

// ���[�h�ύX������select�v�f
$qfe['mode'] = $qf->addElement('select', 'mode', '���[�h', $_mode);

// ���[�h�ύX���m�肷��submit�v�f
$qfe['cngmode'] = $qf->addElement('submit', 'cngmode');

// �t�H�[���̃��[��
$qf->addRule('cols', '1 to 20',  'numberInRange', array('min' => 1, 'max' => 20),  'client', true);
$qf->addRule('rows', '1 to 100', 'numberInRange', array('min' => 1, 'max' => 100), 'client', true);
$qf->addRule('order', 'invalid order.', 'arrayKeyExists', $_order);
$qf->addRule('sort',  'invalid sort.',  'arrayKeyExists', $_sort);
$qf->addRule('field', 'invalid field.', 'arrayKeyExists', $_field);
$qf->addRule('threshold', '-1 to 5', 'numberInRange', array('min' => -1, 'max' => 5));
$qf->addRule('compare', 'invalid compare.', 'arrayKeyExists', $_compare);
$qf->addRule('mode', 'invalid mode.', 'arrayKeyExists', $_mode);
$qf->addRule('thumbtype', 'invalid thumbtype.', 'arrayKeyExists', $_thumbtype);

// Flexy
$_flexy_options = &PEAR::getStaticProperty('HTML_Template_Flexy', 'options');
$_flexy_options = array(
    'locale' => 'ja',
    'charset' => 'Shift_JIS',
    'compileDir' => $_conf['compile_dir'] . DIRECTORY_SEPARATOR . 'iv2',
    'templateDir' => P2EX_LIB_DIR . '/ImageCache2/templates',
    'numberFormat' => '', // ",0,'.',','" �Ɠ���
    'plugins' => array('P2Util' => P2_LIB_DIR . '/P2Util.php')
);

if (!is_dir($_conf['compile_dir'])) {
    FileCtl::mkdirRecursive($_conf['compile_dir']);
}

$flexy = new HTML_Template_Flexy;

$flexy->setData('php_self', $_SERVER['SCRIPT_NAME']);
$flexy->setData('base_dir', dirname($_SERVER['SCRIPT_NAME']));
$flexy->setData('p2vid', P2_VERSION_ID);
$flexy->setData('_hint', $_conf['detect_hint']);
if ($_conf['iphone']) {
    $flexy->setData('top_url', 'index.php');
} else {
    $flexy->setData('skin', str_replace('&amp;', '&', $skin_en));
}
$flexy->setData('pc', !$_conf['iphone']);
$flexy->setData('iphone', $_conf['iphone']);
$flexy->setData('doctype', $_conf['doctype']);
$flexy->setData('extra_headers',   $_conf['extra_headers_ht']);
$flexy->setData('extra_headers_x', $_conf['extra_headers_xht']);

// }}}
// {{{ validate

// ����
$qf->validate();
$sv = $qf->getSubmitValues();
$page      = ImageCache2_ParameterUtility::getValidValue('page',   $_defaults['page'], 'intval');
$cols      = ImageCache2_ParameterUtility::getValidValue('cols',   $_defaults['cols'], 'intval');
$rows      = ImageCache2_ParameterUtility::getValidValue('rows',   $_defaults['rows'], 'intval');
$order     = ImageCache2_ParameterUtility::getValidValue('order',  $_defaults['order']);
$sort      = ImageCache2_ParameterUtility::getValidValue('sort',   $_defaults['sort'] );
$field     = ImageCache2_ParameterUtility::getValidValue('field',  $_defaults['field']);
$keyword   = ImageCache2_ParameterUtility::getValidValue('keyword',   $_defaults['keyword']);
$threshold = ImageCache2_ParameterUtility::getValidValue('threshold', $_defaults['threshold'], 'intval');
$compare   = ImageCache2_ParameterUtility::getValidValue('compare',   $_defaults['compare']);
$mode      = ImageCache2_ParameterUtility::getValidValue('mode',      $_defaults['mode'], 'intval');
$thumbtype = ImageCache2_ParameterUtility::getValidValue('thumbtype', $_defaults['thumbtype'], 'intval');

// �T���l�C���쐬�N���X
$thumbsize = $thumbtype;
if (!empty($_SESSION['device_pixel_ratio'])) {
    $dpr = $_SESSION['device_pixel_ratio'];
    if ($dpr === 1.5) {
        $thumbsize |= ImageCache2_Thumbnailer::DPR_1_5;
    } elseif ($dpr === 2.0) {
        $thumbsize |= ImageCache2_Thumbnailer::DPR_2_0;
    } else {
        $dpr = 1.0;
    }
} else {
    $dpr = 1.0;
}
$thumb = new ImageCache2_Thumbnailer($thumbsize);

// �g�їp�ɒ���
if ($_conf['iphone']) {
    $lightbox = false;
    $mode = 1;
    $inum = (int) $ini['Viewer']['inum'];
    $overwritable_params = array('order', 'sort', 'field', 'keyword', 'threshold', 'compare');

    // �G������ǂݍ���
    require_once P2_LIB_DIR . '/emoji.inc.php';
    $emj = p2_get_emoji();
    $flexy->setData('e', $emj);

    // �t�B���^�����O�p�t�H�[����\��
    if (!empty($_GET['show_iv2_kfilter'])) {
        !defined('P2_NO_SAVE_PACKET') && define('P2_NO_SAVE_PACKET', true);
        $r = new HTML_QuickForm_Renderer_ObjectFlexy($flexy);
        $qfe['keyword']->removeAttribute('size');
        $qf->updateAttributes(array('method' => 'get'));
        $qf->accept($r);
        $qfObj = $r->toObject();
        $flexy->setData('page', $page);
        $flexy->setData('move', $qfObj);
        P2Util::header_nocache();
        $flexy->compile('iv2if.tpl.html');
        $flexy->output();
        exit;
    }
    // �t�B���^�����Z�b�g
    elseif (!empty($_GET['reset_filter'])) {
        unset($_SESSION['iv2i_filter']);
        session_write_close();
    }
    // �t�B���^��ݒ�
    elseif (!empty($_GET['session_no_close'])) {
        foreach ($overwritable_params as $ow_key) {
            if (isset($$ow_key)) {
                $_SESSION['iv2i_filter'][$ow_key] = $$ow_key;
            }
        }
        session_write_close();
    }
    // �t�B���^�����O�p�ϐ����X�V
    elseif (!empty($_SESSION['iv2i_filter'])) {
        foreach ($overwritable_params as $ow_key) {
            if (isset($_SESSION['iv2i_filter'][$ow_key])) {
                $$ow_key = $_SESSION['iv2i_filter'][$ow_key];
            }
        }
    }
} else {
    //$lightbox = ($mode == 0 || $mode == 3) ? $ini['Viewer']['lightbox'] : false;
    $lightbox = $ini['Viewer']['lightbox'];
}

// }}}
// {{{ query

$removed_files = array();

// 臒l�Ńt�B���^�����O
if (!($threshold == -1 && $compare == '>=')) {
    $icdb->whereAddQuoted('rank', $compare, $threshold);
}

// �L�[���[�h����������Ƃ�
if ($keyword !== '') {
    $keywords = explode(' ', $icdb->uniform($keyword, 'CP932', $field == 'memo'));
    foreach ($keywords as $k) {
        $operator = 'LIKE';
        $wildcard = '%';
        $not = false;
        if ($k[0] == '-' && strlen($k) > 1) {
            $not = true;
            $k = substr($k, 1);
        }
        if (strpos($k, '%') !== false || strpos($k, '_') !== false) {
            // SQLite2��LIKE���Z�q�̉E�ӂŃo�b�N�X���b�V���ɂ��G�X�P�[�v��
            // ESCAPE�ŃG�X�P�[�v�������w�肷�邱�Ƃ��ł��Ȃ��̂�GLOB���Z�q���g��
            if ($db_class == 'sqlite') {
                if (strpos($k, '*') !== false || strpos($k, '?') !== false) {
                    p2die('ImageCache2 Warning', '�u%�܂���_�v�Ɓu*�܂���?�v�����݂���L�[���[�h�͎g���܂���B');
                } else {
                    $operator = 'GLOB';
                    $wildcard = '*';
                }
            } else {
                $k = preg_replace('/[%_]/', '\\\\$0', $k);
            }
        }
        $expr = $wildcard . $k . $wildcard;
        if ($not) {
            $operator = 'NOT ' . $operator;
        }
        $icdb->whereAddQuoted($field, $operator, $expr);
    }
    $qfe['keyword']->setValue($keyword);
}

// �d���摜���X�L�b�v����Ƃ�
if ($ini['Viewer']['unique'] == 1) {
    $_find_unique = true;
} elseif ($ini['Viewer']['unique'] == 2 &&
          in_array($order, array('size', 'width', 'height', 'pixels'))) {
    $_find_unique = true;
} else {
    $_find_unique = false;
}
$_find_duplicated = 0; // �����I�p�����[�^�A�o�^���R�[�h��������ȏ�̉摜�݂̂𒊏o
if ($_find_unique || $_find_duplicated > 1) {
    $subq = 'SELECT ' . (($sort == 'ASC') ? 'MIN' : 'MAX') . '(id) FROM ';
    $subq .= $icdb->quoteIdentifier($ini['General']['table']);
    if (isset($keywords)) {
        // �T�u�N�G�����Ńt�B���^�����O����̂Őe�N�G����WHERE����p�N���Ă��ă��Z�b�g
        $subq .= $icdb->_query['condition'];
        $icdb->whereAdd();
    }
    // md5�����ŃO���[�v�����Ă��\���Ƃ͎v�����ǁA�ꉞ�B
    $subq .= ' GROUP BY size, md5, mime';
    if ($_find_duplicated > 1) {
        $subq .= sprintf(' HAVING COUNT(*) > %d', $_find_duplicated - 1);
    }
    // echo '<!--', mb_convert_encoding($subq, 'CP932', 'UTF-8'), '-->';
    $icdb->whereAdd("id IN ($subq)");
}

// �f�[�^�x�[�X���X�V����Ƃ�
if (isset($_POST['edit_submit']) && !empty($_POST['change'])) {

    $target = array_unique(array_map('intval', $_POST['change']));

    switch ($mode) {

    // �ꊇ�Ńp�����[�^�ύX
    case 1:
        // �����N��ύX
        $newrank = ImageCache2_ParameterUtility::intoRange($_POST['setrank'], -1, 5);
        ImageCache2_DatabaseManager::setRank($target, $newrank);
        // ������ǉ�
        if (!empty($_POST['addmemo'])) {
            $newmemo = $_POST['addmemo'];
            $newmemo = $icdb->uniform($newmemo, 'CP932');
            if ($newmemo !== '') {
                 ImageCache2_DatabaseManager::addMemo($target, $newmemo);
            }
        }
        break;

    // �ʂɃp�����[�^�ύX
    case 2:
        // �X�V�p�̃f�[�^���܂Ƃ߂�
        $updated = array();
        $removed = array();
        $to_blacklist = false;
        $no_blacklist = false;

        foreach ($target as $id) {
            if (!empty($_POST['img'][$id]['remove'])) {
                if (!empty($_POST['img'][$id]['black'])) {
                    $to_blacklist = true;
                    $removed[$id] = true;
                } else {
                    $no_blacklist = true;
                    $removed[$id] = false;
                }
            } else {
                $newmemo = $_POST['img'][$id]['memo'];
                $data = array(
                    'rank' => intval($_POST['img'][$id]['rank']),
                    'memo' => $icdb->uniform($newmemo, 'CP932')
                );
                if (0 < $id && -1 <= $data['rank'] && $data['rank'] <= 5) {
                    $updated[$id] = $data;
                }
            }
        }

        // �����X�V
        if (count($updated) > 0) {
            ImageCache2_DatabaseManager::update($updated);
        }

        // �폜�i���u���b�N���X�g����j
        if (count($removed) > 0) {
            foreach ($removed as $id => $to_blacklist) {
                $removed_files = array_merge($removed_files,
                                             ImageCache2_DatabaseManager::remove(array($id), $to_blacklist));
            }
            if ($to_blacklist) {
                if ($no_blacklist) {
                    $flexy->setData('toBlackListAll', false);
                    $flexy->setData('toBlackListPartial', true);
                } else {
                    $flexy->setData('toBlackListAll', true);
                    $flexy->setData('toBlackListPartial', false);
                }
            } else {
                $flexy->setData('toBlackListAll', false);
                $flexy->setData('toBlackListPartial', false);
            }
        }
        break;

    } // endswitch

// �ꊇ�ŉ摜���폜����Ƃ�
} elseif ($mode == 1 && isset($_POST['edit_remove']) && !empty($_POST['change'])) {
    $target = array_unique(array_map('intval', $_POST['change']));
    $to_blacklist = !empty($_POST['edit_toblack']);
    $removed_files = array_merge($removed_files,
                                 ImageCache2_DatabaseManager::remove($target, $to_blacklist));
    $flexy->setData('toBlackList', $to_blacklist);
}

// }}}
// {{{ build

// �����R�[�h���𐔂���
//$db->setFetchMode(DB_FETCHMODE_ORDERED);
//$all = (int)$icdb->count('*', true);
//$db->setFetchMode(DB_FETCHMODE_ASSOC);
$all = $icdb->count('*');

// �}�b�`���郌�R�[�h���Ȃ�������G���[��\���A���R�[�h������Ε\���p�I�u�W�F�N�g�ɒl����
if ($all === 0) {

    // ���R�[�h�Ȃ�
    $flexy->setData('nomatch', true);
    $flexy->setData('current_page', '');
    $flexy->setData('last', 0);
    $flexy->setData('all', 0);
    $flexy->setData('from', 0);
    $flexy->setData('to', 0);
    $flexy->setData('popup', false);
    $flexy->setData('reset', $_SERVER['SCRIPT_NAME']);
    if ($_conf['iphone']) {
        $flexy->setData('kfilter', !empty($_SESSION['iv2i_filter']));
    }
    $qfe['start']->updateAttributes('disabled');
    $qfe['prev']->updateAttributes('disabled');
    $qfe['next']->updateAttributes('disabled');
    $qfe['end']->updateAttributes('disabled');
    $qfe['page']->updateAttributes('disabled');
    $qfe['jump']->updateAttributes('disabled');

} else {

    // ���R�[�h����
    $flexy->setData('nomatch', false);

    // �\���͈͂�ݒ�
    $ipp = $_conf['iphone'] ? $inum : $cols * $rows; // images per page
    $last_page = ceil($all / $ipp);

    // �y�[�W�J�ڗp�p�����[�^������
    if (isset($sv['search']) || isset($sv['cngmode'])) {
        $page = 1;
    } elseif (isset($sv['page'])) {
        $page = max(1, min((int)$sv['page'], $last_page));
    } else {
        $page = 1;
    }
    $prev_page = max(1, $page - 1);
    $next_page = min($page + 1, $last_page);

    // �y�[�W�J�ڗp�����N�iiPhone�j�𐶐�
    if ($_conf['iphone']) {
        $pg_base = p2h($_SERVER['SCRIPT_NAME']);
        $pager = '';
        if ($page != 1) {
            $pager .= sprintf('<a href="%s?page=%d">%s</a> ', $pg_base,          1, $emj['lt2']);
            $pager .= sprintf('<a href="%s?page=%d">%s</a> ', $pg_base, $prev_page, $emj['lt1']);
        }
        $pager .= sprintf('%d/%d', $page, $last_page);
        if ($page != $last_page) {
            $pager .= sprintf(' <a href="%s?page=%d">%s</a>', $pg_base, $next_page, $emj['rt1']);
            $pager .= sprintf(' <a href="%s?page=%d">%s</a>', $pg_base, $last_page, $emj['rt2']);
        }
        $flexy->setData('pager', $pager);

    // �y�[�W�J�ڗp�t�H�[���iPC�j�𐶐�
    } else {
        $mf_hiddens = array(
            '_hint' => $_conf['detect_hint'], 'mode' => $mode,
            'page' => $page, 'cols' => $cols, 'rows' => $rows,
            'order' => $order, 'sort' => $sort,
            'field' => $field, 'keyword' => $keyword,
            'compare' => $compare, 'threshold' => $threshold,
            'thumbtype' => $thumbtype
        );
        $pager_q = $mf_hiddens;
        mb_convert_variables('UTF-8', 'CP932', $pager_q);

        // �y�[�W�ԍ����X�V
        $qfe['page']->setValue($page);
        $qf->addRule('page', "1 to {$last_page}", 'numberInRange', array('min' => 1, 'max' => $last_page), 'client', true);

        // �ꎞ�I�Ƀp�����[�^��؂蕶���� & �ɂ��Č��݂̃y�[�W��URL�𐶐�
        $pager_separator = ini_get('arg_separator.output');
        ini_set('arg_separator.output', '&');
        $flexy->setData('current_page', $_SERVER['SCRIPT_NAME'] . '?' . http_build_query($pager_q));
        ini_set('arg_separator.output', $pager_separator);
        unset($pager_q, $pager_separator);

        // �y�[�W����ړ��{�^���̑������X�V
        if ($page == 1) {
            $qfe['start']->updateAttributes('disabled');
            $qfe['prev']->updateAttributes('disabled');
        } else {
            $qfe['start']->updateAttributes(array('onclick' => "pageJump(1)"));
            $qfe['prev']->updateAttributes(array('onclick' => "pageJump({$prev_page})"));
        }

        // �y�[�W�O���ړ��{�^���̑������X�V
        if ($page == $last_page) {
            $qfe['next']->updateAttributes('disabled');
            $qfe['end']->updateAttributes('disabled');
        } else {
            $qfe['next']->updateAttributes(array('onclick' => "pageJump({$next_page})"));
            $qfe['end']->updateAttributes(array('onclick' => "pageJump({$last_page})"));
        }

        // �y�[�W�w��ړ��p�{�^���̑������X�V
        if ($last_page == 1) {
            $qfe['jump']->updateAttributes('disabled');
        } else {
            $qfe['jump']->updateAttributes(array('onclick' => "if(validate_go(this.form))pageJump(this.form.page.value)"));
        }
    }

    // �ҏW���[�h�p�t�H�[���𐶐�
    if ($mode == 1 || $mode == 2) {
        $flexy->setData('editFormHeader', ImageCache2_EditForm::header((isset($mf_hiddens) ? $mf_hiddens : array()), $mode));
        if ($mode == 1) {
            $flexy->setData('editFormCheckAllOn', ImageCache2_EditForm::checkAllOn());
            $flexy->setData('editFormCheckAllOff', ImageCache2_EditForm::checkAllOff());
            $flexy->setData('editFormCheckAllReverse', ImageCache2_EditForm::checkAllReverse());
            $flexy->setData('editFormSelect', ImageCache2_EditForm::selectRank($_threshold));
            $flexy->setData('editFormText', ImageCache2_EditForm::textMemo());
            $flexy->setData('editFormSubmit', ImageCache2_EditForm::submit());
            $flexy->setData('editFormReset', ImageCache2_EditForm::reset());
            $flexy->setData('editFormRemove', ImageCache2_EditForm::remove());
            $flexy->setData('editFormBlackList', ImageCache2_EditForm::toblack());
        } elseif ($mode == 2) {
            $flexy->setData('editForm', new ImageCache2_EditForm_Object);
        }
    }

    // DB����擾����͈͂�ݒ肵�Č���
    $from = ($page - 1) * $ipp;
    if ($order == 'pixels') {
        if (preg_match('/^(my|pg)sql:/', $ini['General']['dsn'])) {
            $orderBy = '(CAST(width AS INTEGER) * CAST(height AS INTEGER)) ' . $sort;
        } else {
            $orderBy = '(width * height) ' . $sort;
        }
    } elseif ($order == 'date_uri' || $order == 'date_uri2') {
        if ($db_class == 'sqlite') {
            /*
            function iv2_sqlite_unix2date($ts)
            {
                return date('Ymd', (int)$ts);
            }
            sqlite_create_function($db->connection, 'unix2date', 'iv2_sqlite_unix2date', 1);
            $time2date = 'unix2date("time")';
            */
            $time2date = 'php(\'date\', \'Ymd\', "time")';
        } else {
            // 32400 = 9*60*60 (�����␳)
            $time2date = sprintf('floor((%s + 32400) / 86400)', $icdb->quoteIdentifier('time'));
        }
        $orderBy = sprintf('%s %s, %s ', $time2date, $sort, $icdb->quoteIdentifier('uri'));
        if ($order == 'date_uri') {
            $orderBy .= $sort;
        } else {
            $orderBy .= ($sort == 'ASC') ? 'DESC' : 'ASC';
        }
    } else {
        $orderBy = $icdb->quoteIdentifier($order) . ' ' . $sort;
    }
    $orderBy .= ' , id ' . $sort;
    $icdb->orderBy($orderBy);
    $icdb->limit($from, $ipp);
    $found = $icdb->find();

    // �e�[�u���̃u���b�N�ɕ\������l���擾&�I�u�W�F�N�g�ɑ��
    $flexy->setData('all',  $all);
    $flexy->setData('cols', $cols);
    $flexy->setData('last', $last_page);
    $flexy->setData('from', $from + 1);
    $flexy->setData('to',   $from + $found);
    $flexy->setData('submit', array());
    $flexy->setData('reset', array());

    if ($_conf['iphone']) {
        $show_exif = false;
        $popup = false;
        $r_type = ($ini['General']['redirect'] == 1) ? 1 : 2;
    } else {
        switch ($mode) {
            case 3:
                $show_exif = false;
            case 2:
                $popup = false;
                break;
            default:
                $popup = true;
        }
        $r_type = 1;
    }
    $items = array();

    while ($icdb->fetch()) {
        // �������ʂ�z��ɂ��A�����_�����O�p�̗v�f��t��
        // �z��ǂ����Ȃ�+���Z�q�ŗv�f��ǉ��ł���
        // �i�L�[�̏d������l���㏑���������Ƃ���array_merge()���g���j
        $img = $icdb->toArray();
        mb_convert_variables('CP932', 'UTF-8', $img);
        // �����N�E�����͕ύX����邱�Ƃ������A�ꗗ�p�̃f�[�^�L���b�V���ɉe����^���Ȃ��悤�ɕʂɏ�������
        $status = array();
        $status['rank'] = $img['rank'];
        $status['rank_f'] = ($img['rank'] == -1) ? '���ځ[��' : $img['rank'];
        if ($img['rank'] == -1) {
            $status['rank_i'] = '<img src="img/sn1a.png" width="16" height="16">';
        } elseif ($img['rank'] > 0 && $img['rank'] <= 5) {
            $status['rank_i'] = str_repeat('<img src="img/s1a.png" width="16" height="16">', $img['rank']);
        } else {
            $status['rank_i'] = '';
        }
        // ���l�����Q��(NCR)��&amp;��&�ɖ߂�
        $status['memo'] = preg_replace('/&amp;(#\d+;|#x[0-9a-fA-F]+;)/', '&$1', p2h($img['memo']));
        unset($img['rank'], $img['memo']);

        // �\���p�ϐ���ݒ�
        if ($use_cache) {
            $add = $imageInfo_getExtraInfo->invoke($img);
            if ($mode == 1) {
                $chk = ImageCache2_EditForm::imgChecker($img); // ��r�I�y���̂ŃL���b�V�����Ȃ�
                $add += $chk;
            } elseif ($mode == 2) {
                $mng = $editForm_imgManager->invoke($img, $status);
                $add += $mng;
            }
        } else {
            $add = ImageCache2_ImageInfo::getExtraInfo($img);
            if ($mode == 1) {
                $chk = ImageCache2_EditForm::imgChecker($img);
                $add += $chk;
            } elseif ($mode == 2) {
                $mng = ImageCache2_EditForm::imgManager($img, $status);
                $add += $mng;
            }
        }
        // �I���W�i���摜�����݂��Ȃ����R�[�h�������ō폜
        if ($ini['Viewer']['delete_src_not_exists'] && !file_exists($add['src'])) {
            $add['thumb'] = 'img/ic_removed.png';
            $add['t_width'] = $add['t_height'] = 32;
            $to_blacklist = false;
            $removed_files = array_merge($removed_files,
                                         ImageCache2_DatabaseManager::remove(array($img['id'], $to_blacklist)));
            $flexy->setData('toBlackList', $to_blacklist);
        } else {
            // �T���l�C���̃p�X�̂�devicePixelRatio���e������̂ōĎ擾
            $add['thumb'] = $thumb->thumbUrl($icdb->size, $icdb->md5, $icdb->mime);
            if (!file_exists($add['thumb'])) {
                // �����_�����O���Ɏ�����htmlspecialchars()�����̂�&amp;�ɂ��Ȃ�
                $add['thumb'] = 'ic2.php?r=' . $r_type . "&t={$thumb->mode}";
                if (file_exists($add['src'])) {
                    $add['thumb'] .= '&id=' . $img['id'];
                } else {
                    $add['thumb'] .= '&uri=' . rawurlencode($img['uri']);
                }
                if ($dpr === 1.5 || $dpr === 2.0) {
                    $add['thumb'] .= '&d=' . $dpr;
                }
            }
        }
        $item = array_merge($img, $add, $status);

        // Exif�����擾
        if ($show_exif && file_exists($add['src']) && $img['mime'] == 'image/jpeg') {
            if ($use_cache) {
                $item['exif'] = $imageInfo_getExifData->invoke($add['src']);
            } else {
                $item['exif'] = ImageCache2_ImageInfo::getExifData($add['src']);
            }
        } else {
            $item['exif'] = null;
        }

        // Lightbox Plus �p�p�����[�^��ݒ�
        if ($lightbox) {
            $item['lightbox_attrs'] = ' rel="lightbox[iv2]" class="ineffectable"';
            $item['lightbox_attrs'] .= ' title="' . p2h($item['memo']) . '"';
        } else {
            $item['lightbox_attrs'] = '';
        }

        $items[] = $item;
    }

    $i = count($items); // == $found
    // �e�[�u���̗]���𖄂߂邽�߂�null��}��
    if (!$_conf['iphone'] && $i > $cols && ($j = $i % $cols) > 0) {
        for ($k = 0; $k < $cols - $j; $k++) {
            $items[] = null;
            $i++;
        }
    }
    // ���̎��_�� $i == $cols * ���R��

    $flexy->setData('items', $items);
    $flexy->setData('popup', $popup);
    $flexy->setData('matrix', new ImageCache2_Matrix($cols, $rows, $i));
}

$flexy->setData('removedFiles', $removed_files);

// }}}
// {{{ output

// ���[�h�ʂ̍ŏI����
if ($_conf['iphone']) {
    $title = str_replace('ImageCache2', 'IC2', $ini['Viewer']['title']);
    $list_template = 'iv2ip.tpl.html';
} else {
    switch ($mode) {
        case 2:
            $title = $ini['Manager']['title'];
            $list_template = 'iv2m.tpl.html';
            break;
        case 1:
            $title = $ini['Viewer']['title'];
            $list_template = 'iv2a.tpl.html';
            break;
        default:
            $title = $ini['Viewer']['title'];
            $list_template = 'iv2.tpl.html';
    }
}

// �t�H�[�����ŏI�������A�e���v���[�g�p�I�u�W�F�N�g�ɕϊ�
$r = new HTML_QuickForm_Renderer_ObjectFlexy($flexy);
//$r->setLabelTemplate('_label.tpl.html');
//$r->setHtmlTemplate('_html.tpl.html');
$qf->updateAttributes(array('method' => 'get')); // ���N�G�X�g��POST�ł��󂯓���邽�߁A�����ŕύX
$qf->accept($r);
$qfObj = $r->toObject();

// �ϐ���Assign
$js = $qf->getValidationScript() . <<<EOJS
\n<script type="text/javascript">
// <![CDATA[
var ic2_cols = {$cols};
var ic2_rows = {$rows};
var ic2_lightbox_options = {
    no_loop: false,
    no_updown: false
};
// ]]>
</script>\n
EOJS;
$flexy->setData('title', $title);
$flexy->setData('mode', $mode);
$flexy->setData('js', $js);
$flexy->setData('page', $page);
$flexy->setData('move', $qfObj);
$flexy->setData('lightbox', $lightbox);
    $flexy->setData('jquery', $_conf['jquery_version']);
    $flexy->setData('jquery', null);

// �y�[�W��\��
P2Util::header_nocache();
$flexy->compile($list_template);
if ($list_template == 'iv2ip.tpl.html') {
    if (!isset($prev_page)) {
        $prev_page = $page;
    }
    if (!isset($next_page)) {
        $next_page = $page;
    }
    $ll_autoactivate = empty($_GET['ll_autoactivate']) ? 'false' : 'true';
    $limelight_header = <<<EOP
<link rel="stylesheet" type="text/css" href="css/limelight.css?{$_conf['p2_version_id']}">
<script type="text/javascript" src="js/jquery-{$_conf['jquery_version']}.min.js"></script>
<script type="text/javascript" src="js/limelight.js?{$_conf['p2_version_id']}"></script>
<script type="text/javascript">
// <![CDATA[
document.addEventListener('DOMContentLoaded', function(event) {
    var limelight, slide;

    document.removeEventListener(event.type, arguments.callee, false);

    limelight = new Limelight({ 'savable': true });
    slide = limelight.bind();

    if ({$page} != {$prev_page}) {
        slide.onNoPrev = function(limelight, slide) {
            limelight.deactivate();
            window.location.href = 'iv2.php?page={$prev_page}&ll_autoactivate=1#bottom';
       };
    }

    if ({$page} != {$next_page}) {
        slide.onNoNext = function(limelight, slide) {
            limelight.deactivate();
            window.location.href = 'iv2.php?page={$next_page}&ll_autoactivate=1#top';
       };
    }

    if ({$ll_autoactivate}) {
        window.setTimeout(function(cursor) {
            limelight.activateSlide(slide, cursor);
        }, 100, (window.location.hash == '#bottom') ? -1 : 0);
    }
}, false);
// ]]>
</script>\n
EOP;
    $thumb_width = (int)$ini['Thumb1']['width'];
    $thumb_height = (int)$ini['Thumb1']['height'];
    $flexy->setData('thumb_width', $thumb_width);
    $flexy->setData('thumb_height', $thumb_height);
    $flexy->setData('info_vertical', $thumb_width > 80);
    $flexy->setData('limelight_header', $limelight_header);
    $flexy->output();
} else {
    $flexy->output();
}

// }}}

/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
